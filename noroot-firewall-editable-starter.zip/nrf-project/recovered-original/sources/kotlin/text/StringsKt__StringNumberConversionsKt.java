package kotlin.text;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: compiled from: StringNumberConversions.kt */
/* JADX INFO: loaded from: classes.dex */
public class StringsKt__StringNumberConversionsKt extends StringsKt__StringNumberConversionsJVMKt {
    public static Integer toIntOrNull(String toIntOrNull) {
        Intrinsics.checkParameterIsNotNull(toIntOrNull, "$this$toIntOrNull");
        return toIntOrNull(toIntOrNull, 10);
    }

    /* JADX WARN: Code duplicated, block: B:20:0x0037 A[LOOP:0: B:20:0x0037->B:30:0x004f, LOOP_START, PHI: r2 r3
      0x0037: PHI (r2v2 int) = (r2v0 int), (r2v4 int) binds: [B:19:0x0035, B:30:0x004f] A[DONT_GENERATE, DONT_INLINE]
      0x0037: PHI (r3v4 int) = (r3v3 int), (r3v5 int) binds: [B:19:0x0035, B:30:0x004f] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Code duplicated, block: B:30:0x004f A[LOOP:0: B:20:0x0037->B:30:0x004f, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:32:0x0054  */
    /* JADX WARN: Code duplicated, block: B:33:0x0059  */
    /* JADX WARN: Code duplicated, block: B:38:0x0052 A[SYNTHETIC] */
    public static final Integer toIntOrNull(String toIntOrNull, int i) {
        int i2;
        boolean z;
        int i3;
        int iDigitOf;
        int i4;
        Intrinsics.checkParameterIsNotNull(toIntOrNull, "$this$toIntOrNull");
        CharsKt__CharJVMKt.checkRadix(i);
        int length = toIntOrNull.length();
        if (length == 0) {
            return null;
        }
        int i5 = 0;
        char cCharAt = toIntOrNull.charAt(0);
        int i6 = -2147483647;
        if (cCharAt < '0') {
            if (length == 1) {
                return null;
            }
            if (cCharAt == '-') {
                i6 = Integer.MIN_VALUE;
                i2 = 1;
                z = true;
            } else {
                if (cCharAt != '+') {
                    return null;
                }
                i2 = 1;
            }
            int i7 = i6 / i;
            i3 = length - 1;
            if (i2 <= i3) {
                while (true) {
                    iDigitOf = CharsKt__CharJVMKt.digitOf(toIntOrNull.charAt(i2), i);
                    if (iDigitOf >= 0 || i5 < i7 || (i4 = i5 * i) < i6 + iDigitOf) {
                        return null;
                    }
                    i5 = i4 - iDigitOf;
                    if (i2 != i3) {
                        i2++;
                    }
                }
            }
            return z ? Integer.valueOf(i5) : Integer.valueOf(-i5);
        }
        i2 = 0;
        z = false;
        int i8 = i6 / i;
        i3 = length - 1;
        if (i2 <= i3) {
            while (true) {
                iDigitOf = CharsKt__CharJVMKt.digitOf(toIntOrNull.charAt(i2), i);
                if (iDigitOf >= 0) {
                    return null;
                }
                i5 = i4 - iDigitOf;
                if (i2 != i3) {
                    i2++;
                }
            }
        }
        if (z) {
        }
    }

    public static Long toLongOrNull(String toLongOrNull) {
        Intrinsics.checkParameterIsNotNull(toLongOrNull, "$this$toLongOrNull");
        return toLongOrNull(toLongOrNull, 10);
    }

    public static final Long toLongOrNull(String toLongOrNull, int i) {
        boolean z;
        Intrinsics.checkParameterIsNotNull(toLongOrNull, "$this$toLongOrNull");
        CharsKt__CharJVMKt.checkRadix(i);
        int length = toLongOrNull.length();
        Long l = null;
        if (length == 0) {
            return null;
        }
        int i2 = 0;
        char cCharAt = toLongOrNull.charAt(0);
        long j = -9223372036854775807L;
        if (cCharAt >= '0') {
            z = false;
        } else {
            if (length == 1) {
                return null;
            }
            if (cCharAt == '-') {
                j = Long.MIN_VALUE;
                i2 = 1;
                z = true;
            } else {
                if (cCharAt != '+') {
                    return null;
                }
                i2 = 1;
                z = false;
            }
        }
        long j2 = i;
        long j3 = j / j2;
        long j4 = 0;
        int i3 = length - 1;
        if (i2 <= i3) {
            while (true) {
                int iDigitOf = CharsKt__CharJVMKt.digitOf(toLongOrNull.charAt(i2), i);
                if (iDigitOf < 0 || j4 < j3) {
                    return l;
                }
                long j5 = j4 * j2;
                int i4 = i2;
                long j6 = iDigitOf;
                if (j5 < j + j6) {
                    return null;
                }
                j4 = j5 - j6;
                if (i4 != i3) {
                    i2 = i4 + 1;
                    l = null;
                }
            }
        }
        return z ? Long.valueOf(j4) : Long.valueOf(-j4);
    }
}
