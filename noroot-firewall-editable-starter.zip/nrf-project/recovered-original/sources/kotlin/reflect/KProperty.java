package kotlin.reflect;

/* JADX INFO: compiled from: KProperty.kt */
/* JADX INFO: loaded from: classes.dex */
public interface KProperty<R> extends KCallable<R> {

    /* JADX INFO: compiled from: KProperty.kt */
    public interface Accessor<R> {
    }

    /* JADX INFO: compiled from: KProperty.kt */
    public interface Getter<R> extends Accessor<R>, KFunction<R> {
    }
}
