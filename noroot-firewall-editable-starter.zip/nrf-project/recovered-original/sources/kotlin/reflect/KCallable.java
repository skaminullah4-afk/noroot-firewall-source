package kotlin.reflect;

/* JADX INFO: compiled from: KCallable.kt */
/* JADX INFO: loaded from: classes.dex */
public interface KCallable<R> extends KAnnotatedElement {
    R call(Object... objArr);
}
