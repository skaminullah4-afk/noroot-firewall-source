package kotlin.reflect;

/* JADX INFO: compiled from: KAnnotatedElement.kt */
/* JADX INFO: loaded from: classes.dex */
public interface KAnnotatedElement {
}
