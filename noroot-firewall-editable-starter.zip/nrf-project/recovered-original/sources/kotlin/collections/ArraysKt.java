package kotlin.collections;

/* JADX INFO: loaded from: classes.dex */
public final class ArraysKt extends ArraysKt___ArraysKt {
    public static /* bridge */ /* synthetic */ Object[] copyInto$default(Object[] objArr, Object[] objArr2, int i, int i2, int i3, int i4, Object obj) {
        ArraysKt___ArraysJvmKt.copyInto$default(objArr, objArr2, i, i2, i3, i4, obj);
        return objArr2;
    }

    public static /* bridge */ /* synthetic */ <T> T singleOrNull(T[] tArr) {
        return (T) ArraysKt___ArraysKt.singleOrNull(tArr);
    }
}
