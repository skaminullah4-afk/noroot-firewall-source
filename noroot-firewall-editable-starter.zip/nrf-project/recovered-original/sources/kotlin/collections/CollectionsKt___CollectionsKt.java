package kotlin.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: compiled from: _Collections.kt */
/* JADX INFO: loaded from: classes.dex */
public class CollectionsKt___CollectionsKt extends CollectionsKt___CollectionsJvmKt {
    public static final <T, C extends Collection<? super T>> C toCollection(Iterable<? extends T> toCollection, C destination) {
        Intrinsics.checkParameterIsNotNull(toCollection, "$this$toCollection");
        Intrinsics.checkParameterIsNotNull(destination, "destination");
        Iterator<? extends T> it = toCollection.iterator();
        while (it.hasNext()) {
            destination.add(it.next());
        }
        return destination;
    }

    public static <T> List<T> toList(Iterable<? extends T> toList) {
        Intrinsics.checkParameterIsNotNull(toList, "$this$toList");
        if (toList instanceof Collection) {
            Collection collection = (Collection) toList;
            int size = collection.size();
            if (size == 0) {
                return CollectionsKt__CollectionsKt.emptyList();
            }
            if (size != 1) {
                return toMutableList(collection);
            }
            return CollectionsKt__CollectionsJVMKt.listOf(toList instanceof List ? ((List) toList).get(0) : toList.iterator().next());
        }
        return CollectionsKt__CollectionsKt.optimizeReadOnlyList(toMutableList(toList));
    }

    public static final <T> List<T> toMutableList(Iterable<? extends T> toMutableList) {
        Intrinsics.checkParameterIsNotNull(toMutableList, "$this$toMutableList");
        if (toMutableList instanceof Collection) {
            return toMutableList((Collection) toMutableList);
        }
        ArrayList arrayList = new ArrayList();
        toCollection(toMutableList, arrayList);
        return arrayList;
    }

    public static final <T> List<T> toMutableList(Collection<? extends T> toMutableList) {
        Intrinsics.checkParameterIsNotNull(toMutableList, "$this$toMutableList");
        return new ArrayList(toMutableList);
    }

    public static <T> Set<T> toSet(Iterable<? extends T> toSet) {
        Intrinsics.checkParameterIsNotNull(toSet, "$this$toSet");
        if (toSet instanceof Collection) {
            Collection collection = (Collection) toSet;
            int size = collection.size();
            if (size == 0) {
                return SetsKt__SetsKt.emptySet();
            }
            if (size == 1) {
                return SetsKt__SetsJVMKt.setOf(toSet instanceof List ? ((List) toSet).get(0) : toSet.iterator().next());
            }
            LinkedHashSet linkedHashSet = new LinkedHashSet(MapsKt__MapsKt.mapCapacity(collection.size()));
            toCollection(toSet, linkedHashSet);
            return linkedHashSet;
        }
        LinkedHashSet linkedHashSet2 = new LinkedHashSet();
        toCollection(toSet, linkedHashSet2);
        return SetsKt__SetsKt.optimizeReadOnlySet(linkedHashSet2);
    }
}
