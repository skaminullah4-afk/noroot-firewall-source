package kotlin.collections;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: compiled from: _Arrays.kt */
/* JADX INFO: loaded from: classes.dex */
public class ArraysKt___ArraysKt extends ArraysKt___ArraysJvmKt {
    public static char single(char[] single) {
        Intrinsics.checkParameterIsNotNull(single, "$this$single");
        int length = single.length;
        if (length == 0) {
            throw new NoSuchElementException("Array is empty.");
        }
        if (length == 1) {
            return single[0];
        }
        throw new IllegalArgumentException("Array has more than one element.");
    }

    public static <T> T singleOrNull(T[] singleOrNull) {
        Intrinsics.checkParameterIsNotNull(singleOrNull, "$this$singleOrNull");
        if (singleOrNull.length == 1) {
            return singleOrNull[0];
        }
        return null;
    }

    public static final <T> T[] sortedArrayWith(T[] sortedArrayWith, Comparator<? super T> comparator) {
        Intrinsics.checkParameterIsNotNull(sortedArrayWith, "$this$sortedArrayWith");
        Intrinsics.checkParameterIsNotNull(comparator, "comparator");
        if (sortedArrayWith.length == 0) {
            return sortedArrayWith;
        }
        T[] tArr = (T[]) Arrays.copyOf(sortedArrayWith, sortedArrayWith.length);
        Intrinsics.checkExpressionValueIsNotNull(tArr, "java.util.Arrays.copyOf(this, size)");
        ArraysKt___ArraysJvmKt.sortWith(tArr, comparator);
        return tArr;
    }

    public static <T> List<T> sortedWith(T[] sortedWith, Comparator<? super T> comparator) {
        Intrinsics.checkParameterIsNotNull(sortedWith, "$this$sortedWith");
        Intrinsics.checkParameterIsNotNull(comparator, "comparator");
        return ArraysKt___ArraysJvmKt.asList(sortedArrayWith(sortedWith, comparator));
    }
}
