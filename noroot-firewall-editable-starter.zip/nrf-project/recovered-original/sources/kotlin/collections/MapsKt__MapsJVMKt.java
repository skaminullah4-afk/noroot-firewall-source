package kotlin.collections;

/* JADX INFO: compiled from: MapsJVM.kt */
/* JADX INFO: loaded from: classes.dex */
class MapsKt__MapsJVMKt extends MapsKt__MapWithDefaultKt {
}
