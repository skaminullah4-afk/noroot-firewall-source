package kotlin;

/* JADX INFO: compiled from: Exceptions.kt */
/* JADX INFO: loaded from: classes.dex */
public final class ExceptionsKt extends ExceptionsKt__ExceptionsKt {
}
