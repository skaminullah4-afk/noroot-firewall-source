package kotlin;

/* JADX INFO: compiled from: Lazy.kt */
/* JADX INFO: loaded from: classes.dex */
class LazyKt__LazyKt extends LazyKt__LazyJVMKt {
}
