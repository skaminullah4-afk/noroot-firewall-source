package kotlin.ranges;

import java.lang.Comparable;

/* JADX INFO: compiled from: Range.kt */
/* JADX INFO: loaded from: classes.dex */
public interface ClosedRange<T extends Comparable<? super T>> {
}
