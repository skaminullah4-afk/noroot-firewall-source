package kotlin.ranges;

/* JADX INFO: compiled from: Ranges.kt */
/* JADX INFO: loaded from: classes.dex */
class RangesKt__RangesKt extends RangesKt__RangesJVMKt {
}
