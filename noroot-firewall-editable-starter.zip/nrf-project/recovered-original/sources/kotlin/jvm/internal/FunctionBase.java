package kotlin.jvm.internal;

import kotlin.Function;

/* JADX INFO: compiled from: FunctionBase.kt */
/* JADX INFO: loaded from: classes.dex */
public interface FunctionBase<R> extends Function<R> {
    int getArity();
}
