package kotlin.jvm.internal;

import kotlin.reflect.KClass;
import kotlin.reflect.KProperty1;

/* JADX INFO: loaded from: classes.dex */
public class ReflectionFactory {
    public KProperty1 property1(PropertyReference1 propertyReference1) {
        return propertyReference1;
    }

    public KClass getOrCreateKotlinClass(Class cls) {
        return new ClassReference(cls);
    }

    public String renderLambdaToString(Lambda lambda) {
        return renderLambdaToString((FunctionBase) lambda);
    }

    public String renderLambdaToString(FunctionBase functionBase) {
        String string = functionBase.getClass().getGenericInterfaces()[0].toString();
        return string.startsWith("kotlin.jvm.functions.") ? string.substring(21) : string;
    }
}
