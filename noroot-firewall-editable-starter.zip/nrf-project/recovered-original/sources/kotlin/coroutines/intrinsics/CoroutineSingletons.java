package kotlin.coroutines.intrinsics;

/* JADX INFO: compiled from: Intrinsics.kt */
/* JADX INFO: loaded from: classes.dex */
public enum CoroutineSingletons {
    COROUTINE_SUSPENDED,
    /* JADX INFO: Fake field, exist only in values array */
    UNDECIDED,
    /* JADX INFO: Fake field, exist only in values array */
    RESUMED
}
