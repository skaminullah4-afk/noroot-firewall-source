package kotlin.coroutines.intrinsics;

import kotlin.ResultKt;
import kotlin.TypeCastException;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.BaseContinuationImpl;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.coroutines.jvm.internal.RestrictedContinuationImpl;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.TypeIntrinsics;

/* JADX INFO: Access modifiers changed from: package-private */
/* JADX INFO: compiled from: IntrinsicsJvm.kt */
/* JADX INFO: loaded from: classes.dex */
public class IntrinsicsKt__IntrinsicsJvmKt {
    /* JADX WARN: Multi-variable type inference failed */
    public static <R, T> Continuation<Unit> createCoroutineUnintercepted(final Function2<? super R, ? super Continuation<? super T>, ? extends Object> createCoroutineUnintercepted, final R r, final Continuation<? super T> completion) {
        Intrinsics.checkParameterIsNotNull(createCoroutineUnintercepted, "$this$createCoroutineUnintercepted");
        Intrinsics.checkParameterIsNotNull(completion, "completion");
        DebugProbesKt.probeCoroutineCreated(completion);
        if (createCoroutineUnintercepted instanceof BaseContinuationImpl) {
            return ((BaseContinuationImpl) createCoroutineUnintercepted).create(r, completion);
        }
        final CoroutineContext context = completion.getContext();
        if (context == EmptyCoroutineContext.INSTANCE) {
            if (completion != null) {
                return new RestrictedContinuationImpl(completion, completion, createCoroutineUnintercepted, r) { // from class: kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt$createCoroutineUnintercepted$$inlined$createCoroutineFromSuspendFunction$IntrinsicsKt__IntrinsicsJvmKt$3
                    final /* synthetic */ Object $receiver$inlined;
                    final /* synthetic */ Function2 $this_createCoroutineUnintercepted$inlined;
                    private int label;

                    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                    {
                        super(completion);
                        this.$this_createCoroutineUnintercepted$inlined = createCoroutineUnintercepted;
                        this.$receiver$inlined = r;
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    protected Object invokeSuspend(Object obj) throws Throwable {
                        int i = this.label;
                        if (i != 0) {
                            if (i == 1) {
                                this.label = 2;
                                ResultKt.throwOnFailure(obj);
                                return obj;
                            }
                            throw new IllegalStateException("This coroutine had already completed".toString());
                        }
                        this.label = 1;
                        ResultKt.throwOnFailure(obj);
                        Function2 function2 = this.$this_createCoroutineUnintercepted$inlined;
                        if (function2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type (R, kotlin.coroutines.Continuation<T>) -> kotlin.Any?");
                        }
                        TypeIntrinsics.beforeCheckcastToFunctionOfArity(function2, 2);
                        return function2.invoke(this.$receiver$inlined, this);
                    }
                };
            }
            throw new TypeCastException("null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
        }
        if (completion != null) {
            return new ContinuationImpl(completion, context, completion, context, createCoroutineUnintercepted, r) { // from class: kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt$createCoroutineUnintercepted$$inlined$createCoroutineFromSuspendFunction$IntrinsicsKt__IntrinsicsJvmKt$4
                final /* synthetic */ Object $receiver$inlined;
                final /* synthetic */ Function2 $this_createCoroutineUnintercepted$inlined;
                private int label;

                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(completion, context);
                    this.$this_createCoroutineUnintercepted$inlined = createCoroutineUnintercepted;
                    this.$receiver$inlined = r;
                }

                @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                protected Object invokeSuspend(Object obj) throws Throwable {
                    int i = this.label;
                    if (i != 0) {
                        if (i == 1) {
                            this.label = 2;
                            ResultKt.throwOnFailure(obj);
                            return obj;
                        }
                        throw new IllegalStateException("This coroutine had already completed".toString());
                    }
                    this.label = 1;
                    ResultKt.throwOnFailure(obj);
                    Function2 function2 = this.$this_createCoroutineUnintercepted$inlined;
                    if (function2 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type (R, kotlin.coroutines.Continuation<T>) -> kotlin.Any?");
                    }
                    TypeIntrinsics.beforeCheckcastToFunctionOfArity(function2, 2);
                    return function2.invoke(this.$receiver$inlined, this);
                }
            };
        }
        throw new TypeCastException("null cannot be cast to non-null type kotlin.coroutines.Continuation<kotlin.Any?>");
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static <T> Continuation<T> intercepted(Continuation<? super T> intercepted) {
        Continuation<T> continuation;
        Intrinsics.checkParameterIsNotNull(intercepted, "$this$intercepted");
        ContinuationImpl continuationImpl = (ContinuationImpl) (!(intercepted instanceof ContinuationImpl) ? null : intercepted);
        return (continuationImpl == null || (continuation = (Continuation<T>) continuationImpl.intercepted()) == null) ? intercepted : continuation;
    }
}
