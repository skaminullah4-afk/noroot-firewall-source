package kotlin;

/* JADX INFO: compiled from: Unit.kt */
/* JADX INFO: loaded from: classes.dex */
public final class Unit {
    public static final Unit INSTANCE = new Unit();

    public String toString() {
        return "kotlin.Unit";
    }

    private Unit() {
    }
}
