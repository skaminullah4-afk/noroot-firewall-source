package kotlin.sequences;

import java.util.Iterator;

/* JADX INFO: compiled from: Sequence.kt */
/* JADX INFO: loaded from: classes.dex */
public interface Sequence<T> {
    Iterator<T> iterator();
}
