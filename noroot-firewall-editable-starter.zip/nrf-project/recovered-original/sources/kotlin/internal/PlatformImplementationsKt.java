package kotlin.internal;

import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt__StringsKt;

/* JADX INFO: compiled from: PlatformImplementations.kt */
/* JADX INFO: loaded from: classes.dex */
public final class PlatformImplementationsKt {
    public static final PlatformImplementations IMPLEMENTATIONS;

    /* JADX WARN: Code duplicated, block: B:27:0x00bc A[Catch: ClassCastException -> 0x00c1, ClassNotFoundException -> 0x00f7, TRY_ENTER, TryCatch #7 {ClassCastException -> 0x00c1, blocks: (B:27:0x00bc, B:30:0x00c3, B:31:0x00c8), top: B:52:0x00ba, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:30:0x00c3 A[Catch: ClassCastException -> 0x00c1, ClassNotFoundException -> 0x00f7, TryCatch #7 {ClassCastException -> 0x00c1, blocks: (B:27:0x00bc, B:30:0x00c3, B:31:0x00c8), top: B:52:0x00ba, outer: #1 }] */
    /* JADX WARN: Code duplicated, block: B:43:0x0140  */
    /* JADX WARN: Code duplicated, block: B:47:0x00ad A[EXC_TOP_SPLITTER, SYNTHETIC] */
    static {
        PlatformImplementations platformImplementations;
        Object objNewInstance;
        int javaVersion = getJavaVersion();
        if (javaVersion >= 65544) {
            try {
                Object objNewInstance2 = Class.forName("kotlin.internal.jdk8.JDK8PlatformImplementations").newInstance();
                Intrinsics.checkExpressionValueIsNotNull(objNewInstance2, "Class.forName(\"kotlin.in…entations\").newInstance()");
                try {
                    try {
                        if (objNewInstance2 == null) {
                            throw new TypeCastException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                        }
                        platformImplementations = (PlatformImplementations) objNewInstance2;
                    } catch (ClassNotFoundException unused) {
                        if (javaVersion >= 65543) {
                            try {
                                try {
                                    objNewInstance = Class.forName("kotlin.internal.jdk7.JDK7PlatformImplementations").newInstance();
                                    Intrinsics.checkExpressionValueIsNotNull(objNewInstance, "Class.forName(\"kotlin.in…entations\").newInstance()");
                                    try {
                                        if (objNewInstance != null) {
                                            throw new TypeCastException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                                        }
                                        platformImplementations = (PlatformImplementations) objNewInstance;
                                    } catch (ClassCastException e) {
                                        Throwable thInitCause = new ClassCastException("Instance classloader: " + objNewInstance.getClass().getClassLoader() + ", base type classloader: " + PlatformImplementations.class.getClassLoader()).initCause(e);
                                        Intrinsics.checkExpressionValueIsNotNull(thInitCause, "ClassCastException(\"Inst…baseTypeCL\").initCause(e)");
                                        throw thInitCause;
                                    }
                                } catch (ClassNotFoundException unused2) {
                                    Object objNewInstance3 = Class.forName("kotlin.internal.JRE7PlatformImplementations").newInstance();
                                    Intrinsics.checkExpressionValueIsNotNull(objNewInstance3, "Class.forName(\"kotlin.in…entations\").newInstance()");
                                    try {
                                        if (objNewInstance3 == null) {
                                            throw new TypeCastException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                                        }
                                        platformImplementations = (PlatformImplementations) objNewInstance3;
                                    } catch (ClassCastException e2) {
                                        Throwable thInitCause2 = new ClassCastException("Instance classloader: " + objNewInstance3.getClass().getClassLoader() + ", base type classloader: " + PlatformImplementations.class.getClassLoader()).initCause(e2);
                                        Intrinsics.checkExpressionValueIsNotNull(thInitCause2, "ClassCastException(\"Inst…baseTypeCL\").initCause(e)");
                                        throw thInitCause2;
                                    }
                                }
                            } catch (ClassNotFoundException unused3) {
                                platformImplementations = new PlatformImplementations();
                            }
                        } else {
                            platformImplementations = new PlatformImplementations();
                        }
                    }
                } catch (ClassCastException e3) {
                    Throwable thInitCause3 = new ClassCastException("Instance classloader: " + objNewInstance2.getClass().getClassLoader() + ", base type classloader: " + PlatformImplementations.class.getClassLoader()).initCause(e3);
                    Intrinsics.checkExpressionValueIsNotNull(thInitCause3, "ClassCastException(\"Inst…baseTypeCL\").initCause(e)");
                    throw thInitCause3;
                }
            } catch (ClassNotFoundException unused4) {
                Object objNewInstance4 = Class.forName("kotlin.internal.JRE8PlatformImplementations").newInstance();
                Intrinsics.checkExpressionValueIsNotNull(objNewInstance4, "Class.forName(\"kotlin.in…entations\").newInstance()");
                try {
                    if (objNewInstance4 == null) {
                        throw new TypeCastException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
                    }
                    platformImplementations = (PlatformImplementations) objNewInstance4;
                } catch (ClassCastException e4) {
                    Throwable thInitCause4 = new ClassCastException("Instance classloader: " + objNewInstance4.getClass().getClassLoader() + ", base type classloader: " + PlatformImplementations.class.getClassLoader()).initCause(e4);
                    Intrinsics.checkExpressionValueIsNotNull(thInitCause4, "ClassCastException(\"Inst…baseTypeCL\").initCause(e)");
                    throw thInitCause4;
                }
            }
        } else if (javaVersion >= 65543) {
            objNewInstance = Class.forName("kotlin.internal.jdk7.JDK7PlatformImplementations").newInstance();
            Intrinsics.checkExpressionValueIsNotNull(objNewInstance, "Class.forName(\"kotlin.in…entations\").newInstance()");
            if (objNewInstance != null) {
                throw new TypeCastException("null cannot be cast to non-null type kotlin.internal.PlatformImplementations");
            }
            platformImplementations = (PlatformImplementations) objNewInstance;
        } else {
            platformImplementations = new PlatformImplementations();
        }
        IMPLEMENTATIONS = platformImplementations;
    }

    private static final int getJavaVersion() {
        String property = System.getProperty("java.specification.version");
        if (property == null) {
            return 65542;
        }
        int iIndexOf$default = StringsKt__StringsKt.indexOf$default((CharSequence) property, '.', 0, false, 6, (Object) null);
        if (iIndexOf$default < 0) {
            try {
                return Integer.parseInt(property) * 65536;
            } catch (NumberFormatException unused) {
                return 65542;
            }
        }
        int i = iIndexOf$default + 1;
        int iIndexOf$default2 = StringsKt__StringsKt.indexOf$default((CharSequence) property, '.', i, false, 4, (Object) null);
        if (iIndexOf$default2 < 0) {
            iIndexOf$default2 = property.length();
        }
        if (property != null) {
            String strSubstring = property.substring(0, iIndexOf$default);
            Intrinsics.checkExpressionValueIsNotNull(strSubstring, "(this as java.lang.Strin…ing(startIndex, endIndex)");
            if (property != null) {
                String strSubstring2 = property.substring(i, iIndexOf$default2);
                Intrinsics.checkExpressionValueIsNotNull(strSubstring2, "(this as java.lang.Strin…ing(startIndex, endIndex)");
                try {
                    return (Integer.parseInt(strSubstring) * 65536) + Integer.parseInt(strSubstring2);
                } catch (NumberFormatException unused2) {
                    return 65542;
                }
            }
            throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
        }
        throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
    }
}
