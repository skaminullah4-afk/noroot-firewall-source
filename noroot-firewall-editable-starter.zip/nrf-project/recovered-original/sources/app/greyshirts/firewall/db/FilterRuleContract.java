package app.greyshirts.firewall.db;

import android.content.Context;
import android.net.Uri;
import android.provider.BaseColumns;
import app.greyshirts.firewall.R;

/* JADX INFO: loaded from: classes.dex */
public class FilterRuleContract implements BaseColumns {
    private static FilterRuleContract instance;
    private final Uri contentUri;
    private final Uri contentUriNoObserver;
    private final Uri contentUriOnlyGlobal;

    public static synchronized FilterRuleContract getInstance(Context context) {
        if (instance == null) {
            instance = new FilterRuleContract(context);
        }
        return instance;
    }

    private FilterRuleContract(Context context) {
        String string = context.getString(R.string.provider_authority_notranslate);
        this.contentUri = Uri.parse("content://" + string + "/filter");
        this.contentUriNoObserver = Uri.parse("content://" + string + "/filter/noObserver");
        this.contentUriOnlyGlobal = Uri.parse("content://" + string + "/filter/global");
    }

    public Uri getContentUri() {
        return this.contentUri;
    }

    public Uri getContentUriNoObserver() {
        return this.contentUriNoObserver;
    }

    public Uri getContentUriOnlyGlobal() {
        return this.contentUriOnlyGlobal;
    }
}
