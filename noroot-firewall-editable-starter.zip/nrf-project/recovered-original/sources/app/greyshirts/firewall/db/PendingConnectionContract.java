package app.greyshirts.firewall.db;

import android.content.Context;
import android.net.Uri;
import android.provider.BaseColumns;
import app.greyshirts.firewall.R;

/* JADX INFO: loaded from: classes.dex */
public class PendingConnectionContract implements BaseColumns {
    private static PendingConnectionContract instance;
    private final Uri contentFilterByPkgs;
    private final Uri contentGroupedByLeaderAppNameUri;
    private final Uri contentGroupedByPkg1Uri;
    private final Uri contentUri;

    public static synchronized PendingConnectionContract getInstance(Context context) {
        if (instance == null) {
            instance = new PendingConnectionContract(context);
        }
        return instance;
    }

    private PendingConnectionContract(Context context) {
        String string = context.getString(R.string.provider_authority_notranslate);
        this.contentUri = Uri.parse("content://" + string + "/pending");
        this.contentGroupedByLeaderAppNameUri = Uri.parse("content://" + string + "/pending/grouped");
        this.contentGroupedByPkg1Uri = Uri.parse("content://" + string + "/pending/groupedByPkg1");
        this.contentFilterByPkgs = Uri.parse("content://" + string + "/pending/pkgs");
    }

    public Uri getContentUri() {
        return this.contentUri;
    }

    public Uri getContentGroupedByLeaderAppNameUri() {
        return this.contentGroupedByLeaderAppNameUri;
    }

    public Uri getContentGroupedByPkg1Uri() {
        return this.contentGroupedByPkg1Uri;
    }

    public Uri getContentFilterByPkgs() {
        return this.contentFilterByPkgs;
    }
}
