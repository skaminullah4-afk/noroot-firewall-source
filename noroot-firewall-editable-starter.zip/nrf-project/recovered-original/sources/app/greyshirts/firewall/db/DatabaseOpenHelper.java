package app.greyshirts.firewall.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/* JADX INFO: loaded from: classes.dex */
public class DatabaseOpenHelper extends SQLiteOpenHelper {
    private static DatabaseOpenHelper instance;

    public static synchronized DatabaseOpenHelper getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseOpenHelper(context.getApplicationContext());
        }
        return instance;
    }

    private DatabaseOpenHelper(Context context) {
        super(context, "db", (SQLiteDatabase.CursorFactory) null, 10);
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onCreate(SQLiteDatabase sQLiteDatabase) {
        sQLiteDatabase.execSQL("CREATE TABLE pending (serverIp TEXT, serverHost TEXT, serverPort INTEGER, localIp TEXT, localPort INTEGER, protocol INTEGER, serverName TEXT, createdData INTEGER, appName TEXT, allAppName TEXT, pkgName TEXT, pkg2Name TEXT, pkg3Name TEXT, appUid INTEGER, _id INTEGER PRIMARY KEY AUTOINCREMENT )");
        sQLiteDatabase.execSQL("CREATE TABLE filter (serverIp TEXT, serverStrType INTEGER, serverPort INTEGER, protocol INTEGER, serverName TEXT, createdData INTEGER, type INTEGER DEFAULT 0, type1 INTEGER DEFAULT 0, appName TEXT, pkgName TEXT, pkg2Name TEXT, pkg3Name TEXT, isPolicy INTEGER, appUid INTEGER, priority INTEGER DEFAULT 0, _id INTEGER PRIMARY KEY AUTOINCREMENT )");
        sQLiteDatabase.execSQL("CREATE TABLE app (appName TEXT, pkg1Name TEXT, appType INTEGER, _id INTEGER PRIMARY KEY AUTOINCREMENT )");
        sQLiteDatabase.execSQL("CREATE INDEX pend_pkg1 ON pending(pkgName)");
        sQLiteDatabase.execSQL("CREATE INDEX pend_pkg2 ON pending(pkg2Name)");
        sQLiteDatabase.execSQL("CREATE INDEX pend_pkg3 ON pending(pkg3Name)");
        sQLiteDatabase.execSQL("CREATE INDEX filter_pkg1 ON filter(pkgName)");
        sQLiteDatabase.execSQL("CREATE INDEX filter_pkg2 ON filter(pkg2Name)");
        sQLiteDatabase.execSQL("CREATE INDEX filter_pkg3 ON filter(pkg3Name)");
    }

    @Override // android.database.sqlite.SQLiteOpenHelper
    public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i, int i2) {
        if (i == 3) {
            sQLiteDatabase.execSQL("ALTER TABLE pending ADD COLUMN allAppName TEXT");
            sQLiteDatabase.execSQL("ALTER TABLE pending ADD COLUMN pkg2Name TEXT");
            sQLiteDatabase.execSQL("ALTER TABLE pending ADD COLUMN pkg3Name TEXT");
            sQLiteDatabase.execSQL("UPDATE pending SET allAppName=appName");
            sQLiteDatabase.execSQL("UPDATE pending SET pkgName='nonpkg.mediaserver' WHERE appName='mediaserver'");
            sQLiteDatabase.execSQL("ALTER TABLE filter ADD COLUMN pkg2Name TEXT");
            sQLiteDatabase.execSQL("ALTER TABLE filter ADD COLUMN pkg3Name TEXT");
            sQLiteDatabase.execSQL("ALTER TABLE filter ADD COLUMN isPolicy INTEGER DEFAULT 0");
            sQLiteDatabase.execSQL("UPDATE filter SET pkgName='nonpkg.mediaserver' WHERE appName='mediaserver'");
            sQLiteDatabase.execSQL("CREATE TABLE app (appName TEXT, pkg1Name TEXT, appType INTEGER, _id INTEGER PRIMARY KEY AUTOINCREMENT )");
            sQLiteDatabase.execSQL("CREATE INDEX pend_pkg1 ON pending(pkgName)");
            sQLiteDatabase.execSQL("CREATE INDEX pend_pkg2 ON pending(pkg2Name)");
            sQLiteDatabase.execSQL("CREATE INDEX pend_pkg3 ON pending(pkg3Name)");
            sQLiteDatabase.execSQL("CREATE INDEX filter_pkg1 ON filter(pkgName)");
            sQLiteDatabase.execSQL("CREATE INDEX filter_pkg2 ON filter(pkg2Name)");
            sQLiteDatabase.execSQL("CREATE INDEX filter_pkg3 ON filter(pkg3Name)");
            i = 4;
        }
        if (i == 4) {
            sQLiteDatabase.execSQL("ALTER TABLE filter ADD COLUMN serverStrType INTEGER DEFAULT 0");
            i = 5;
        }
        if (i == 5) {
            sQLiteDatabase.execSQL("ALTER TABLE pending ADD COLUMN serverHost TEXT");
            i = 6;
        }
        if (i == 6) {
            sQLiteDatabase.execSQL("UPDATE filter SET serverIp='*', serverPort=-1, serverStrType=0 WHERE type IN (3,4)");
            sQLiteDatabase.execSQL("ALTER TABLE filter ADD COLUMN type1 INTEGER DEFAULT 0");
            sQLiteDatabase.execSQL("UPDATE filter SET type1=type");
            i = 7;
        }
        if (i == 7) {
            sQLiteDatabase.execSQL("UPDATE filter SET type=1 WHERE type=3");
            sQLiteDatabase.execSQL("UPDATE filter SET type=2 WHERE type=4");
            sQLiteDatabase.execSQL("UPDATE filter SET type1=1 WHERE type1=3");
            sQLiteDatabase.execSQL("UPDATE filter SET type1=2 WHERE type1=4");
            i = 8;
        }
        if (i == 8) {
            sQLiteDatabase.execSQL("UPDATE filter SET serverIp='*', serverPort=-1, serverStrType=0 WHERE isPolicy=1");
            i = 9;
        }
        if (i == 9) {
            sQLiteDatabase.execSQL("ALTER TABLE filter ADD COLUMN priority INTEGER DEFAULT 0");
        }
    }
}
