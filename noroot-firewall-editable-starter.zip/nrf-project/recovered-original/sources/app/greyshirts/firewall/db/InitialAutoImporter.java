package app.greyshirts.firewall.db;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import app.greyshirts.firewall.app.MyVpnService;
import java.io.InputStream;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.GlobalScope;
import kotlinx.coroutines.MainCoroutineDispatcher;

/* JADX INFO: compiled from: InitialAutoImporter.kt */
/* JADX INFO: loaded from: classes.dex */
public final class InitialAutoImporter {
    private final String assetFileName;
    private final Context ctx;

    public InitialAutoImporter(Context ctx, String assetFileName) {
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        Intrinsics.checkParameterIsNotNull(assetFileName, "assetFileName");
        this.ctx = ctx;
        this.assetFileName = assetFileName;
    }

    public final String getAssetFileName() {
        return this.assetFileName;
    }

    public final Context getCtx() {
        return this.ctx;
    }

    public final void tryImport() {
        String str = "isInitialFilterImported_" + this.assetFileName;
        SharedPreferences sharedPreferences = this.ctx.getSharedPreferences("pref", 0);
        if (sharedPreferences.getBoolean(str, false)) {
            return;
        }
        BuildersKt__Builders_commonKt.launch$default(GlobalScope.INSTANCE, null, null, new AnonymousClass1(sharedPreferences, str, null), 3, null);
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.db.InitialAutoImporter$tryImport$1, reason: invalid class name */
    /* JADX INFO: compiled from: InitialAutoImporter.kt */
    @DebugMetadata(c = "app.greyshirts.firewall.db.InitialAutoImporter$tryImport$1", f = "InitialAutoImporter.kt", l = {36}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ SharedPreferences $pref;
        final /* synthetic */ String $prefKey;
        Object L$0;
        Object L$1;
        Object L$2;
        int label;
        private CoroutineScope p$;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(SharedPreferences sharedPreferences, String str, Continuation continuation) {
            super(2, continuation);
            this.$pref = sharedPreferences;
            this.$prefKey = str;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> completion) {
            Intrinsics.checkParameterIsNotNull(completion, "completion");
            AnonymousClass1 anonymousClass1 = InitialAutoImporter.this.new AnonymousClass1(this.$pref, this.$prefKey, completion);
            anonymousClass1.p$ = (CoroutineScope) obj;
            return anonymousClass1;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) throws Throwable {
            ImportResult importResultImportJsonFromInputStream;
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.label;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                CoroutineScope coroutineScope = this.p$;
                try {
                    InputStream inputStreamOpen = InitialAutoImporter.this.getCtx().getAssets().open(InitialAutoImporter.this.getAssetFileName());
                    Intrinsics.checkExpressionValueIsNotNull(inputStreamOpen, "try {\n                  …@launch\n                }");
                    try {
                        try {
                            importResultImportJsonFromInputStream = ImportExportKt.importJsonFromInputStream(InitialAutoImporter.this.getCtx(), inputStreamOpen);
                            inputStreamOpen.close();
                        } catch (Exception e) {
                            ImportResult importResult = new ImportResult(0, 0, e);
                            inputStreamOpen.close();
                            importResultImportJsonFromInputStream = importResult;
                        }
                        MainCoroutineDispatcher main = Dispatchers.getMain();
                        C00001 c00001 = new C00001(importResultImportJsonFromInputStream, null);
                        this.L$0 = coroutineScope;
                        this.L$1 = inputStreamOpen;
                        this.L$2 = importResultImportJsonFromInputStream;
                        this.label = 1;
                        if (BuildersKt.withContext(main, c00001, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } catch (Throwable th) {
                        inputStreamOpen.close();
                        throw th;
                    }
                } catch (Exception unused) {
                    Log.i("NRFW", "asset " + InitialAutoImporter.this.getAssetFileName() + " not found");
                    return Unit.INSTANCE;
                }
            } else {
                if (i != 1) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
            }
            return Unit.INSTANCE;
        }

        /* JADX INFO: renamed from: app.greyshirts.firewall.db.InitialAutoImporter$tryImport$1$1, reason: invalid class name and collision with other inner class name */
        /* JADX INFO: compiled from: InitialAutoImporter.kt */
        @DebugMetadata(c = "app.greyshirts.firewall.db.InitialAutoImporter$tryImport$1$1", f = "InitialAutoImporter.kt", l = {}, m = "invokeSuspend")
        static final class C00001 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
            final /* synthetic */ ImportResult $importResult;
            int label;
            private CoroutineScope p$;

            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            C00001(ImportResult importResult, Continuation continuation) {
                super(2, continuation);
                this.$importResult = importResult;
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Continuation<Unit> create(Object obj, Continuation<?> completion) {
                Intrinsics.checkParameterIsNotNull(completion, "completion");
                C00001 c00001 = AnonymousClass1.this.new C00001(this.$importResult, completion);
                c00001.p$ = (CoroutineScope) obj;
                return c00001;
            }

            @Override // kotlin.jvm.functions.Function2
            public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                return ((C00001) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
            public final Object invokeSuspend(Object obj) throws Throwable {
                IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                if (this.label != 0) {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                ResultKt.throwOnFailure(obj);
                if (this.$importResult.getE() == null) {
                    AnonymousClass1.this.$pref.edit().putBoolean(AnonymousClass1.this.$prefKey, true).apply();
                    MyVpnService.notifyBlockingRuleChange(InitialAutoImporter.this.getCtx());
                    Log.i("NRFW", "initial import OK");
                } else {
                    Log.i("NRFW", "initial import failed", this.$importResult.getE());
                }
                return Unit.INSTANCE;
            }
        }
    }
}
