package app.greyshirts.firewall.db;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.SparseArray;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.NonPkgApp;
import app.greyshirts.firewall.app.PackageNames;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class UidGroupList {
    private static List<PackageCacheEntry> packageCache;
    private static final Object packageCacheLock = new Object();
    private static final String[] COLUMNS = {"groupName", "leaderPkgName", "sqrIn", "install", "hasAllow0", "hasDeny0", "policy0", "hasAllow1", "hasDeny1", "policy1", "type0", "type1", "leaderAppName", "serverStr", "serverStrType", "serverPort", "createdData", "filterRuleId", "_id"};
    private final SparseArray<UidGroupEntry> mapUid2Group = new SparseArray<>();
    private final Map<String, UidGroupEntry> mapPkg2Group = new HashMap();
    private final ArrayList<UidGroupEntry> allGroups = new ArrayList<>();

    static class PackageCacheEntry {
        final boolean hasNetPerm;
        final String label;
        final String packageName;
        final int uid;

        public PackageCacheEntry(PackageInfo packageInfo, PackageManager packageManager) {
            this.label = packageInfo.applicationInfo.loadLabel(packageManager).toString();
            this.packageName = packageInfo.packageName;
            this.uid = packageInfo.applicationInfo.uid;
            String[] strArr = packageInfo.requestedPermissions;
            boolean z = false;
            if (strArr != null) {
                for (String str : strArr) {
                    if ("android.permission.INTERNET".equals(str)) {
                        z = true;
                        break;
                    }
                }
            }
            this.hasNetPerm = z;
        }
    }

    public static synchronized void clearPackageCache() {
        synchronized (packageCacheLock) {
            packageCache = null;
        }
    }

    void createPackageCache(PackageManager packageManager) {
        synchronized (packageCacheLock) {
            packageCache = new ArrayList();
            List<PackageInfo> installedPackages = packageManager.getInstalledPackages(4096);
            if (installedPackages != null) {
                Iterator<PackageInfo> it = installedPackages.iterator();
                while (it.hasNext()) {
                    packageCache.add(new PackageCacheEntry(it.next(), packageManager));
                }
            }
        }
    }

    public void loadInstalledApps(PackageManager packageManager) {
        synchronized (packageCacheLock) {
            if (packageCache == null) {
                createPackageCache(packageManager);
            }
            for (PackageCacheEntry packageCacheEntry : packageCache) {
                int i = packageCacheEntry.uid;
                UidGroupEntry uidGroupEntry = this.mapUid2Group.get(i);
                if (uidGroupEntry == null) {
                    uidGroupEntry = new UidGroupEntry(i);
                    this.allGroups.add(uidGroupEntry);
                    this.mapUid2Group.put(i, uidGroupEntry);
                }
                this.mapPkg2Group.put(packageCacheEntry.packageName, uidGroupEntry);
                uidGroupEntry.addApp(new UidGroupEntry.AppEntry(packageCacheEntry.label, packageCacheEntry.packageName, packageCacheEntry.hasNetPerm));
            }
        }
    }

    public void loadNonPkgApps(Context context) {
        Iterator<NonPkgApp> iterator = NonPkgApp.getIterator(context);
        while (iterator.hasNext()) {
            NonPkgApp next = iterator.next();
            if (this.mapPkg2Group.get(next.getPkgName()) == null) {
                UidGroupEntry uidGroupEntry = new UidGroupEntry(-1);
                this.allGroups.add(uidGroupEntry);
                this.mapPkg2Group.put(next.getPkgName(), uidGroupEntry);
                uidGroupEntry.addApp(new UidGroupEntry.AppEntry(next.getAppName(), next.getPkgName(), true));
            }
        }
    }

    public void loadFilters(DatabaseOpenHelper databaseOpenHelper) {
        Cursor cursorQuery;
        int i;
        try {
            cursorQuery = databaseOpenHelper.getWritableDatabase().query("filter", null, "pkgName<>'*'", null, null, null, "_id ASC");
            try {
                int columnIndexOrThrow = cursorQuery.getColumnIndexOrThrow("_id");
                int columnIndexOrThrow2 = cursorQuery.getColumnIndexOrThrow("serverIp");
                int columnIndexOrThrow3 = cursorQuery.getColumnIndexOrThrow("serverStrType");
                int columnIndexOrThrow4 = cursorQuery.getColumnIndexOrThrow("serverPort");
                int columnIndexOrThrow5 = cursorQuery.getColumnIndexOrThrow("protocol");
                int columnIndexOrThrow6 = cursorQuery.getColumnIndexOrThrow("createdData");
                int columnIndexOrThrow7 = cursorQuery.getColumnIndexOrThrow("type");
                int columnIndexOrThrow8 = cursorQuery.getColumnIndexOrThrow("type1");
                int columnIndexOrThrow9 = cursorQuery.getColumnIndexOrThrow("appName");
                int columnIndexOrThrow10 = cursorQuery.getColumnIndexOrThrow("pkgName");
                int columnIndexOrThrow11 = cursorQuery.getColumnIndexOrThrow("pkg2Name");
                int columnIndexOrThrow12 = cursorQuery.getColumnIndexOrThrow("pkg3Name");
                int columnIndexOrThrow13 = cursorQuery.getColumnIndexOrThrow("isPolicy");
                cursorQuery.moveToFirst();
                while (!cursorQuery.isAfterLast()) {
                    String string = cursorQuery.getString(columnIndexOrThrow10);
                    int i2 = columnIndexOrThrow10;
                    String string2 = cursorQuery.getString(columnIndexOrThrow11);
                    int i3 = columnIndexOrThrow11;
                    String string3 = cursorQuery.getString(columnIndexOrThrow12);
                    UidGroupEntry uidGroupEntry = !TextUtils.isEmpty(string) ? this.mapPkg2Group.get(string) : null;
                    if (uidGroupEntry == null && !TextUtils.isEmpty(string2)) {
                        uidGroupEntry = this.mapPkg2Group.get(string2);
                    }
                    if (uidGroupEntry == null && !TextUtils.isEmpty(string3)) {
                        uidGroupEntry = this.mapPkg2Group.get(string3);
                    }
                    if (uidGroupEntry == null) {
                        i = columnIndexOrThrow13;
                        uidGroupEntry = new UidGroupEntry(-1);
                        this.allGroups.add(uidGroupEntry);
                        if (!TextUtils.isEmpty(string)) {
                            this.mapPkg2Group.put(string, uidGroupEntry);
                        }
                        if (!TextUtils.isEmpty(string2)) {
                            this.mapPkg2Group.put(string2, uidGroupEntry);
                        }
                        if (!TextUtils.isEmpty(string3)) {
                            this.mapPkg2Group.put(string3, uidGroupEntry);
                        }
                    } else {
                        i = columnIndexOrThrow13;
                    }
                    UidGroupEntry.FilterEntry filterEntry = new UidGroupEntry.FilterEntry(cursorQuery.getLong(columnIndexOrThrow), cursorQuery.getString(columnIndexOrThrow2), cursorQuery.getInt(columnIndexOrThrow3), cursorQuery.getInt(columnIndexOrThrow4), cursorQuery.getInt(columnIndexOrThrow5), cursorQuery.getLong(columnIndexOrThrow6), cursorQuery.getInt(columnIndexOrThrow7), cursorQuery.getInt(columnIndexOrThrow8), cursorQuery.getString(columnIndexOrThrow9), string, string2, string3);
                    int i4 = i;
                    if (cursorQuery.getInt(i4) == 1) {
                        uidGroupEntry.addPolicyFilter(filterEntry);
                    } else {
                        uidGroupEntry.addCustomFilter(filterEntry);
                    }
                    cursorQuery.moveToNext();
                    columnIndexOrThrow13 = i4;
                    columnIndexOrThrow10 = i2;
                    columnIndexOrThrow11 = i3;
                    columnIndexOrThrow12 = columnIndexOrThrow12;
                }
            } catch (Exception unused) {
                if (cursorQuery != null) {
                    cursorQuery.close();
                }
            }
        } catch (Exception unused2) {
            cursorQuery = null;
        }
    }

    public MatrixCursor getCombinedDataCursor(boolean z) {
        Collections.sort(this.allGroups, UidGroupEntry.CASE_INSENSITIVE_COMPARATOR);
        MatrixCursor matrixCursor = new MatrixCursor(COLUMNS);
        for (UidGroupEntry uidGroupEntry : this.allGroups) {
            List<UidGroupEntry.FilterEntry> customFilters = uidGroupEntry.getCustomFilters();
            if (uidGroupEntry.hasNetPerm() || !customFilters.isEmpty() || uidGroupEntry.getPolicy(Filter.Profile.PROFILE_WIFI) != 0 || uidGroupEntry.getPolicy(Filter.Profile.PROFILE_MOBILE) != 0) {
                Object[] objArr = new Object[19];
                fillPolicyColumns(uidGroupEntry, objArr);
                matrixCursor.addRow(objArr);
                if (z) {
                    fillCustomFilterColumnsAndAddRows(matrixCursor, uidGroupEntry, objArr);
                }
            }
        }
        return matrixCursor;
    }

    public MatrixCursor getCustomFilterCursor(String str) {
        PackageNames packageNamesNewInstanceFromCommaList = PackageNames.newInstanceFromCommaList(str);
        final Bundle bundle = new Bundle();
        MatrixCursor matrixCursor = new MatrixCursor(this, COLUMNS) { // from class: app.greyshirts.firewall.db.UidGroupList.1
            @Override // android.database.AbstractCursor, android.database.Cursor
            public Bundle getExtras() {
                return bundle;
            }
        };
        int length = packageNamesNewInstanceFromCommaList.length();
        for (int i = 0; i < length; i++) {
            UidGroupEntry uidGroupEntry = this.mapPkg2Group.get(packageNamesNewInstanceFromCommaList.getAt(i));
            if (uidGroupEntry != null) {
                bundle.putString("groupName", uidGroupEntry.getGroupName());
                bundle.putString("leaderPkgName", uidGroupEntry.getLeaderPkgName());
                bundle.putString("sqrIn", uidGroupEntry.getPkgs().getCommaJoinedString());
                bundle.putInt("install", !isInstalled(uidGroupEntry) ? 1 : 0);
                bundle.putInt("hasAllow0", uidGroupEntry.hasAllowBeforeAll(Filter.Profile.PROFILE_WIFI) ? 1 : 0);
                bundle.putInt("hasDeny0", uidGroupEntry.hasDenyBeforeAll(Filter.Profile.PROFILE_WIFI) ? 1 : 0);
                bundle.putInt("policy0", uidGroupEntry.getPolicy(Filter.Profile.PROFILE_WIFI));
                bundle.putInt("hasAllow1", uidGroupEntry.hasAllowBeforeAll(Filter.Profile.PROFILE_MOBILE) ? 1 : 0);
                bundle.putInt("hasDeny1", uidGroupEntry.hasDenyBeforeAll(Filter.Profile.PROFILE_MOBILE) ? 1 : 0);
                bundle.putInt("policy1", uidGroupEntry.getPolicy(Filter.Profile.PROFILE_MOBILE));
                bundle.putString("leaderAppName", uidGroupEntry.getLeaderAppName());
                uidGroupEntry.getCustomFilters();
                Object[] objArr = new Object[19];
                fillPolicyColumns(uidGroupEntry, objArr);
                fillCustomFilterColumnsAndAddRows(matrixCursor, uidGroupEntry, objArr);
                break;
            }
        }
        return matrixCursor;
    }

    private void fillPolicyColumns(UidGroupEntry uidGroupEntry, Object[] objArr) {
        objArr[0] = uidGroupEntry.getGroupName();
        objArr[1] = uidGroupEntry.getLeaderPkgName();
        objArr[2] = uidGroupEntry.getPkgs().getCommaJoinedString();
        if (isInstalled(uidGroupEntry)) {
            objArr[3] = 0;
        } else {
            objArr[3] = 1;
        }
        objArr[4] = Integer.valueOf(uidGroupEntry.hasAllowBeforeAll(Filter.Profile.PROFILE_WIFI) ? 1 : 0);
        objArr[5] = Integer.valueOf(uidGroupEntry.hasDenyBeforeAll(Filter.Profile.PROFILE_WIFI) ? 1 : 0);
        objArr[6] = Integer.valueOf(uidGroupEntry.getPolicy(Filter.Profile.PROFILE_WIFI));
        objArr[7] = Integer.valueOf(uidGroupEntry.hasAllowBeforeAll(Filter.Profile.PROFILE_MOBILE) ? 1 : 0);
        objArr[8] = Integer.valueOf(uidGroupEntry.hasDenyBeforeAll(Filter.Profile.PROFILE_MOBILE) ? 1 : 0);
        objArr[9] = Integer.valueOf(uidGroupEntry.getPolicy(Filter.Profile.PROFILE_MOBILE));
        objArr[10] = 128;
        objArr[11] = 128;
        objArr[12] = uidGroupEntry.getLeaderAppName();
        objArr[17] = null;
        objArr[16] = null;
        objArr[15] = null;
        objArr[14] = null;
        objArr[13] = null;
        objArr[18] = Long.valueOf(((long) uidGroupEntry.uid) << 32);
    }

    private void fillCustomFilterColumnsAndAddRows(MatrixCursor matrixCursor, UidGroupEntry uidGroupEntry, Object[] objArr) {
        for (UidGroupEntry.FilterEntry filterEntry : uidGroupEntry.getCustomFilters()) {
            objArr[10] = Integer.valueOf(filterEntry.filterType0);
            objArr[11] = Integer.valueOf(filterEntry.filterType1);
            objArr[12] = filterEntry.leaderAppName;
            objArr[13] = filterEntry.serverStr;
            objArr[14] = Integer.valueOf(filterEntry.serverStrType);
            objArr[15] = Integer.valueOf(filterEntry.serverPort);
            objArr[16] = Long.valueOf(filterEntry.createDate);
            objArr[17] = Long.valueOf(filterEntry.id);
            objArr[18] = Long.valueOf(((long) uidGroupEntry.uid) << ((int) (filterEntry.id + 32)));
            matrixCursor.addRow(objArr);
        }
    }

    public PackageNames getUninstalledPkgs() {
        ArrayList arrayList = new ArrayList();
        for (UidGroupEntry uidGroupEntry : this.allGroups) {
            if (!isInstalled(uidGroupEntry)) {
                Collections.addAll(arrayList, uidGroupEntry.getPkgs().getPkgs());
            }
        }
        String[] strArr = new String[arrayList.size()];
        arrayList.toArray(strArr);
        return PackageNames.newInstance(strArr);
    }

    boolean isInstalled(UidGroupEntry uidGroupEntry) {
        if (uidGroupEntry.getLeaderPkgName().startsWith("uid=") && uidGroupEntry.getGroupName().startsWith("Unknown")) {
            return true;
        }
        return (uidGroupEntry.getLeaderPkgName().equals("mediaserver") && uidGroupEntry.getGroupName().equals("mediaserver")) || uidGroupEntry.getLeaderPkgName().startsWith("nonpkg.") || uidGroupEntry.uid != -1;
    }
}
