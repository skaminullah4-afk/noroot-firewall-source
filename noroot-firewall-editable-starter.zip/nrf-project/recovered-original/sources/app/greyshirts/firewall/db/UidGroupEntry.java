package app.greyshirts.firewall.db;

import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.PackageNames;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/* JADX INFO: loaded from: classes.dex */
class UidGroupEntry {
    public static final Comparator<UidGroupEntry> CASE_INSENSITIVE_COMPARATOR = new Comparator<UidGroupEntry>() { // from class: app.greyshirts.firewall.db.UidGroupEntry.1
        @Override // java.util.Comparator
        public int compare(UidGroupEntry uidGroupEntry, UidGroupEntry uidGroupEntry2) {
            return uidGroupEntry.getGroupName().compareToIgnoreCase(uidGroupEntry2.getGroupName());
        }
    };
    final int uid;
    private final TreeMap<String, AppEntry> installed = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private final ArrayList<FilterEntry> policyFilter = new ArrayList<>();
    private final ArrayList<FilterEntry> customFilter = new ArrayList<>();
    private String groupName = null;
    private boolean hasNetPerm = false;
    private boolean hasAll0 = false;
    private boolean hasAllowBeforeAll0 = false;
    private boolean hasDenyBeforeAll0 = false;
    private boolean hasAll1 = false;
    private boolean hasAllowBeforeAll1 = false;
    private boolean hasDenyBeforeAll1 = false;

    public UidGroupEntry(int i) {
        this.uid = i;
    }

    public void addApp(AppEntry appEntry) {
        this.groupName = null;
        this.installed.put(appEntry.appName + "+" + appEntry.pkgName, appEntry);
        if (appEntry.hasNetPerm) {
            this.hasNetPerm = true;
        }
    }

    public int getPolicy(Filter.Profile profile) {
        int i;
        int i2 = 0;
        if (this.policyFilter.size() == 0) {
            return 0;
        }
        int i3 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$Profile[profile.ordinal()];
        if (i3 == 2) {
            i = this.policyFilter.get(0).filterType0;
        } else {
            if (i3 != 3) {
                throw new RuntimeException("profile is all");
            }
            i = this.policyFilter.get(0).filterType1;
        }
        if (i != 0) {
            i2 = 1;
            if (i != 1) {
                return 2;
            }
        }
        return i2;
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.db.UidGroupEntry$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$app$Filter$Profile = new int[Filter.Profile.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Profile[Filter.Profile.PROFILE_ALL.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Profile[Filter.Profile.PROFILE_WIFI.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Profile[Filter.Profile.PROFILE_MOBILE.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    public void addPolicyFilter(FilterEntry filterEntry) {
        this.groupName = null;
        this.policyFilter.add(filterEntry);
    }

    public void addCustomFilter(FilterEntry filterEntry) {
        this.groupName = null;
        this.customFilter.add(filterEntry);
        if (!this.hasAll0) {
            int i = filterEntry.filterType0;
            if (i == 1) {
                this.hasAllowBeforeAll0 = true;
                if (filterEntry.serverPort == -1 && filterEntry.serverStr.equals("*")) {
                    this.hasAll0 = true;
                }
            } else if (i == 2) {
                this.hasDenyBeforeAll0 = true;
                if (filterEntry.serverPort == -1 && filterEntry.serverStr.equals("*")) {
                    this.hasAll0 = true;
                }
            }
        }
        if (this.hasAll1) {
            return;
        }
        int i2 = filterEntry.filterType1;
        if (i2 == 1) {
            this.hasAllowBeforeAll1 = true;
            if (filterEntry.serverPort == -1 && filterEntry.serverStr.equals("*")) {
                this.hasAll1 = true;
                return;
            }
            return;
        }
        if (i2 != 2) {
            return;
        }
        this.hasDenyBeforeAll1 = true;
        if (filterEntry.serverPort == -1 && filterEntry.serverStr.equals("*")) {
            this.hasAll1 = true;
        }
    }

    public String getGroupName() {
        String str = this.groupName;
        if (str != null) {
            return str;
        }
        if (!this.installed.isEmpty()) {
            String str2 = null;
            for (Map.Entry<String, AppEntry> entry : this.installed.entrySet()) {
                str2 = str2 == null ? entry.getValue().appName : str2 + ", " + entry.getValue().appName;
            }
            this.groupName = str2;
            return str2;
        }
        if (!this.policyFilter.isEmpty()) {
            this.groupName = this.policyFilter.get(0).leaderAppName;
            return this.groupName;
        }
        if (!this.customFilter.isEmpty()) {
            this.groupName = this.customFilter.get(0).leaderAppName;
            return this.groupName;
        }
        this.groupName = "";
        return this.groupName;
    }

    public String getLeaderPkgName() {
        if (!this.installed.isEmpty()) {
            return this.installed.firstEntry().getValue().pkgName;
        }
        if (!this.policyFilter.isEmpty()) {
            return this.policyFilter.get(0).pkg1Name;
        }
        if (this.customFilter.isEmpty()) {
            return null;
        }
        return this.customFilter.get(0).pkg1Name;
    }

    public String getLeaderAppName() {
        if (!this.installed.isEmpty()) {
            return this.installed.firstEntry().getValue().appName;
        }
        if (!this.policyFilter.isEmpty()) {
            return this.policyFilter.get(0).leaderAppName;
        }
        if (this.customFilter.isEmpty()) {
            return null;
        }
        return this.customFilter.get(0).leaderAppName;
    }

    public PackageNames getPkgs() {
        int i = 0;
        if (!this.installed.isEmpty()) {
            String[] strArr = new String[this.installed.size()];
            Iterator<Map.Entry<String, AppEntry>> it = this.installed.entrySet().iterator();
            while (it.hasNext()) {
                strArr[i] = it.next().getValue().pkgName;
                i++;
            }
            return PackageNames.newInstance(strArr);
        }
        if (!this.policyFilter.isEmpty()) {
            return PackageNames.newInstance(new String[]{this.policyFilter.get(0).pkg1Name});
        }
        if (this.customFilter.isEmpty()) {
            return null;
        }
        return PackageNames.newInstance(new String[]{this.customFilter.get(0).pkg1Name});
    }

    public boolean hasNetPerm() {
        return this.hasNetPerm;
    }

    public boolean hasAllowBeforeAll(Filter.Profile profile) {
        int i = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$Profile[profile.ordinal()];
        if (i == 2) {
            return this.hasAllowBeforeAll0;
        }
        if (i != 3) {
            throw new RuntimeException("profile all");
        }
        return this.hasAllowBeforeAll1;
    }

    public boolean hasDenyBeforeAll(Filter.Profile profile) {
        int i = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$Profile[profile.ordinal()];
        if (i == 2) {
            return this.hasDenyBeforeAll0;
        }
        if (i != 3) {
            throw new RuntimeException("profile all");
        }
        return this.hasDenyBeforeAll1;
    }

    public List<FilterEntry> getCustomFilters() {
        return this.customFilter;
    }

    static class AppEntry {
        final String appName;
        final boolean hasNetPerm;
        final String pkgName;

        public AppEntry(String str, String str2, boolean z) {
            this.appName = str;
            this.pkgName = str2;
            this.hasNetPerm = z;
        }
    }

    static class FilterEntry {
        final long createDate;
        final int filterType0;
        final int filterType1;
        final long id;
        final String leaderAppName;
        final String pkg1Name;
        final int serverPort;
        final String serverStr;
        final int serverStrType;

        public FilterEntry(long j, String str, int i, int i2, int i3, long j2, int i4, int i5, String str2, String str3, String str4, String str5) {
            this.id = j;
            this.serverStr = str;
            this.serverStrType = i;
            this.serverPort = i2;
            this.createDate = j2;
            this.filterType0 = i4;
            this.filterType1 = i5;
            this.leaderAppName = str2;
            this.pkg1Name = str3;
        }
    }
}
