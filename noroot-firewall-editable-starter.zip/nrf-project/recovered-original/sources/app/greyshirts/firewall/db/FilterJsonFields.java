package app.greyshirts.firewall.db;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class FilterJsonFields {
    private final String appName;
    private final boolean isCustom;
    private final String mobile;
    private final String pkg1Name;
    private final String pkg2Name;
    private final String pkg3Name;
    private final int port;
    private final int priority;
    private final String proto;
    private final String server;
    private final String serverStrType;
    private final String wifi;

    public boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof FilterJsonFields) {
                FilterJsonFields filterJsonFields = (FilterJsonFields) obj;
                if (Intrinsics.areEqual(this.server, filterJsonFields.server) && Intrinsics.areEqual(this.serverStrType, filterJsonFields.serverStrType)) {
                    if ((this.port == filterJsonFields.port) && Intrinsics.areEqual(this.proto, filterJsonFields.proto) && Intrinsics.areEqual(this.wifi, filterJsonFields.wifi) && Intrinsics.areEqual(this.mobile, filterJsonFields.mobile) && Intrinsics.areEqual(this.appName, filterJsonFields.appName) && Intrinsics.areEqual(this.pkg1Name, filterJsonFields.pkg1Name) && Intrinsics.areEqual(this.pkg2Name, filterJsonFields.pkg2Name) && Intrinsics.areEqual(this.pkg3Name, filterJsonFields.pkg3Name)) {
                        if (this.isCustom == filterJsonFields.isCustom) {
                            if (this.priority == filterJsonFields.priority) {
                            }
                        }
                    }
                }
            }
            return false;
        }
        return true;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v22, types: [int] */
    /* JADX WARN: Type inference failed for: r1v3, types: [int] */
    /* JADX WARN: Type inference failed for: r1v6 */
    /* JADX WARN: Type inference failed for: r1v8 */
    public int hashCode() {
        String str = this.server;
        int iHashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.serverStrType;
        int iHashCode2 = (((iHashCode + (str2 != null ? str2.hashCode() : 0)) * 31) + Integer.valueOf(this.port).hashCode()) * 31;
        String str3 = this.proto;
        int iHashCode3 = (iHashCode2 + (str3 != null ? str3.hashCode() : 0)) * 31;
        String str4 = this.wifi;
        int iHashCode4 = (iHashCode3 + (str4 != null ? str4.hashCode() : 0)) * 31;
        String str5 = this.mobile;
        int iHashCode5 = (iHashCode4 + (str5 != null ? str5.hashCode() : 0)) * 31;
        String str6 = this.appName;
        int iHashCode6 = (iHashCode5 + (str6 != null ? str6.hashCode() : 0)) * 31;
        String str7 = this.pkg1Name;
        int iHashCode7 = (iHashCode6 + (str7 != null ? str7.hashCode() : 0)) * 31;
        String str8 = this.pkg2Name;
        int iHashCode8 = (iHashCode7 + (str8 != null ? str8.hashCode() : 0)) * 31;
        String str9 = this.pkg3Name;
        int iHashCode9 = (iHashCode8 + (str9 != null ? str9.hashCode() : 0)) * 31;
        boolean z = this.isCustom;
        ?? r1 = z;
        if (z) {
            r1 = 1;
        }
        return ((iHashCode9 + r1) * 31) + Integer.valueOf(this.priority).hashCode();
    }

    public String toString() {
        return "FilterJsonFields(server=" + this.server + ", serverStrType=" + this.serverStrType + ", port=" + this.port + ", proto=" + this.proto + ", wifi=" + this.wifi + ", mobile=" + this.mobile + ", appName=" + this.appName + ", pkg1Name=" + this.pkg1Name + ", pkg2Name=" + this.pkg2Name + ", pkg3Name=" + this.pkg3Name + ", isCustom=" + this.isCustom + ", priority=" + this.priority + ")";
    }

    public FilterJsonFields(String server, String serverStrType, int i, String proto, String wifi, String mobile, String str, String str2, String str3, String str4, boolean z, int i2) {
        Intrinsics.checkParameterIsNotNull(server, "server");
        Intrinsics.checkParameterIsNotNull(serverStrType, "serverStrType");
        Intrinsics.checkParameterIsNotNull(proto, "proto");
        Intrinsics.checkParameterIsNotNull(wifi, "wifi");
        Intrinsics.checkParameterIsNotNull(mobile, "mobile");
        this.server = server;
        this.serverStrType = serverStrType;
        this.port = i;
        this.proto = proto;
        this.wifi = wifi;
        this.mobile = mobile;
        this.appName = str;
        this.pkg1Name = str2;
        this.pkg2Name = str3;
        this.pkg3Name = str4;
        this.isCustom = z;
        this.priority = i2;
    }

    public final String getServer() {
        return this.server;
    }

    public final String getServerStrType() {
        return this.serverStrType;
    }

    public final int getPort() {
        return this.port;
    }

    public final String getProto() {
        return this.proto;
    }

    public final String getWifi() {
        return this.wifi;
    }

    public final String getMobile() {
        return this.mobile;
    }

    public final String getAppName() {
        return this.appName;
    }

    public final String getPkg1Name() {
        return this.pkg1Name;
    }

    public final String getPkg2Name() {
        return this.pkg2Name;
    }

    public final String getPkg3Name() {
        return this.pkg3Name;
    }

    public final boolean isCustom() {
        return this.isCustom;
    }

    public final int getPriority() {
        return this.priority;
    }
}
