package app.greyshirts.firewall.db;

import android.content.Context;
import android.net.Uri;
import android.provider.BaseColumns;
import app.greyshirts.firewall.R;

/* JADX INFO: loaded from: classes.dex */
public class CombinedDataContract implements BaseColumns {
    private static CombinedDataContract instance;
    private final Uri contentUri;

    public static synchronized CombinedDataContract getInstance(Context context) {
        if (instance == null) {
            instance = new CombinedDataContract(context);
        }
        return instance;
    }

    private CombinedDataContract(Context context) {
        this.contentUri = Uri.parse("content://" + context.getString(R.string.provider_authority_notranslate) + "/combined");
    }

    public Uri getContentUri() {
        return this.contentUri;
    }
}
