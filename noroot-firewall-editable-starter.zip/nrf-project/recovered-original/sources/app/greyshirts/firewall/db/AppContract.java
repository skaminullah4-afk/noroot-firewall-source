package app.greyshirts.firewall.db;

import android.content.Context;
import android.net.Uri;
import android.provider.BaseColumns;
import app.greyshirts.firewall.R;

/* JADX INFO: loaded from: classes.dex */
public class AppContract implements BaseColumns {
    private static AppContract instance;
    private final Uri contentUri;

    public static synchronized AppContract getInstance(Context context) {
        if (instance == null) {
            instance = new AppContract(context);
        }
        return instance;
    }

    private AppContract(Context context) {
        this.contentUri = Uri.parse("content://" + context.getString(R.string.provider_authority_notranslate) + "/app");
    }

    public Uri getContentUri() {
        return this.contentUri;
    }
}
