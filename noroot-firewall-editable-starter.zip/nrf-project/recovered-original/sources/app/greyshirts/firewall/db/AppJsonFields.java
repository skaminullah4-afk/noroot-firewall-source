package app.greyshirts.firewall.db;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class AppJsonFields {
    private final String appName;
    private final String pkgName;

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof AppJsonFields)) {
            return false;
        }
        AppJsonFields appJsonFields = (AppJsonFields) obj;
        return Intrinsics.areEqual(this.appName, appJsonFields.appName) && Intrinsics.areEqual(this.pkgName, appJsonFields.pkgName);
    }

    public int hashCode() {
        String str = this.appName;
        int iHashCode = (str != null ? str.hashCode() : 0) * 31;
        String str2 = this.pkgName;
        return iHashCode + (str2 != null ? str2.hashCode() : 0);
    }

    public String toString() {
        return "AppJsonFields(appName=" + this.appName + ", pkgName=" + this.pkgName + ")";
    }

    public AppJsonFields(String str, String str2) {
        this.appName = str;
        this.pkgName = str2;
    }

    public final String getAppName() {
        return this.appName;
    }

    public final String getPkgName() {
        return this.pkgName;
    }
}
