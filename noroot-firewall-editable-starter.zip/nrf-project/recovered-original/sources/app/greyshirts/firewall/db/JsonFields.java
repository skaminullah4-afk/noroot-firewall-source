package app.greyshirts.firewall.db;

import java.util.List;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class JsonFields {
    private final List<AppJsonFields> apps;
    private final List<FilterJsonFields> filters;

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof JsonFields)) {
            return false;
        }
        JsonFields jsonFields = (JsonFields) obj;
        return Intrinsics.areEqual(this.filters, jsonFields.filters) && Intrinsics.areEqual(this.apps, jsonFields.apps);
    }

    public int hashCode() {
        List<FilterJsonFields> list = this.filters;
        int iHashCode = (list != null ? list.hashCode() : 0) * 31;
        List<AppJsonFields> list2 = this.apps;
        return iHashCode + (list2 != null ? list2.hashCode() : 0);
    }

    public String toString() {
        return "JsonFields(filters=" + this.filters + ", apps=" + this.apps + ")";
    }

    public JsonFields(List<FilterJsonFields> filters, List<AppJsonFields> apps) {
        Intrinsics.checkParameterIsNotNull(filters, "filters");
        Intrinsics.checkParameterIsNotNull(apps, "apps");
        this.filters = filters;
        this.apps = apps;
    }

    public final List<FilterJsonFields> getFilters() {
        return this.filters;
    }

    public final List<AppJsonFields> getApps() {
        return this.apps;
    }
}
