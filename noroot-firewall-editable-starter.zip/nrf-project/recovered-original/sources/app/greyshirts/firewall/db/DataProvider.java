package app.greyshirts.firewall.db;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.MergeCursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.os.Bundle;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.PackageNames;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;

/* JADX INFO: loaded from: classes.dex */
public class DataProvider extends ContentProvider {
    private static final HashMap<String, String> pendingProjectionMap = new HashMap<>();
    private DatabaseOpenHelper mOpenHelper;
    private UriMatcher mUriMatcher;

    static {
        pendingProjectionMap.put("groupCount", "COUNT(*) AS groupCount");
        pendingProjectionMap.put("createdDateMax", "MAX(createdData) AS createdDateMax");
    }

    @Override // android.content.ContentProvider
    public boolean onCreate() {
        String string = getContext().getString(R.string.provider_authority_notranslate);
        this.mOpenHelper = DatabaseOpenHelper.getInstance(getContext());
        this.mUriMatcher = new UriMatcher(-1);
        this.mUriMatcher.addURI(string, "pending", 1);
        this.mUriMatcher.addURI(string, "pending/#", 2);
        this.mUriMatcher.addURI(string, "pending/grouped", 3);
        this.mUriMatcher.addURI(string, "pending/groupedByPkg1", 4);
        this.mUriMatcher.addURI(string, "pending/pkgs/*", 5);
        this.mUriMatcher.addURI(string, "filter", 10);
        this.mUriMatcher.addURI(string, "filter/#", 11);
        this.mUriMatcher.addURI(string, "filter/noObserver", 12);
        this.mUriMatcher.addURI(string, "filter/global", 13);
        this.mUriMatcher.addURI(string, "combined", 20);
        this.mUriMatcher.addURI(string, "combined/*", 21);
        this.mUriMatcher.addURI(string, "app", 30);
        return true;
    }

    @Override // android.content.ContentProvider
    public int delete(Uri uri, String str, String[] strArr) {
        String str2;
        int iMatch = this.mUriMatcher.match(uri);
        if (iMatch == 1) {
            str2 = "pending";
        } else {
            if (iMatch == 2) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 3) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 4) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 5) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch != 10) {
                if (iMatch == 11) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 13) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 30) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 20) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 21) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            str2 = "filter";
        }
        int iDelete = this.mOpenHelper.getWritableDatabase().delete(str2, str, strArr);
        getContext().getContentResolver().notifyChange(uri, null);
        getContext().getContentResolver().notifyChange(CombinedDataContract.getInstance(getContext()).getContentUri(), null);
        return iDelete;
    }

    @Override // android.content.ContentProvider
    public String getType(Uri uri) {
        this.mUriMatcher.match(uri);
        throw new IllegalArgumentException("Unknown URI " + uri);
    }

    @Override // android.content.ContentProvider
    public Uri insert(Uri uri, ContentValues contentValues) {
        String str;
        int iMatch = this.mUriMatcher.match(uri);
        if (iMatch == 1) {
            str = "pending";
        } else {
            if (iMatch == 2) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 3) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 4) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 5) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 10) {
                str = "filter";
            } else {
                if (iMatch == 11) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 13) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch != 30) {
                    if (iMatch == 20) {
                        throw new IllegalArgumentException("Unknown URI " + uri);
                    }
                    if (iMatch == 21) {
                        throw new IllegalArgumentException("Unknown URI " + uri);
                    }
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                str = "app";
            }
        }
        Uri uriWithAppendedPath = Uri.withAppendedPath(uri, String.valueOf(this.mOpenHelper.getWritableDatabase().insert(str, null, contentValues)));
        getContext().getContentResolver().notifyChange(uri, null);
        getContext().getContentResolver().notifyChange(CombinedDataContract.getInstance(getContext()).getContentUri(), null);
        return uriWithAppendedPath;
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    @Override // android.content.ContentProvider
    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        String str3;
        String[] strArr3;
        boolean z;
        String str4;
        Cursor cursorQuery;
        String string = str;
        String[] stringList = strArr2;
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        int iMatch = this.mUriMatcher.match(uri);
        boolean z2 = true;
        String str5 = null;
        if (iMatch != 1) {
            if (iMatch == 2) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 3) {
                sQLiteQueryBuilder.setTables("pending");
                if (str2 == null) {
                    strArr3 = stringList;
                    str4 = "MAX(_id) DESC";
                    str5 = "appName";
                    z = true;
                    str3 = string;
                } else {
                    str4 = str2;
                    str3 = string;
                    strArr3 = stringList;
                    str5 = "appName";
                    z = true;
                }
            } else if (iMatch == 4) {
                sQLiteQueryBuilder.setTables("pending");
                sQLiteQueryBuilder.setProjectionMap(createProjectionMap(pendingProjectionMap, strArr));
                str4 = str2;
                str3 = string;
                str5 = "pkgName";
                z = true;
                strArr3 = stringList;
            } else if (iMatch == 5) {
                PackageNames packageNamesNewInstanceFromCommaList = PackageNames.newInstanceFromCommaList(uri.getLastPathSegment());
                StringBuilder sb = new StringBuilder();
                sb.append(Filter.makeWhereForInClause("pkgName", "pkg2Name", "pkg3Name", packageNamesNewInstanceFromCommaList));
                ArrayList<String> arrayListMakeWhereArgsForInClause = Filter.makeWhereArgsForInClause(3, packageNamesNewInstanceFromCommaList);
                if (string != null) {
                    sb.insert(0, "(");
                    sb.append(") AND (");
                    sb.append(string);
                    sb.append(")");
                }
                if (stringList != null) {
                    Collections.addAll(arrayListMakeWhereArgsForInClause, stringList);
                }
                string = sb.toString();
                stringList = Filter.toStringList(arrayListMakeWhereArgsForInClause);
                sQLiteQueryBuilder.setTables("pending");
            } else {
                if (iMatch == 20) {
                    UidGroupList uidGroupList = new UidGroupList();
                    uidGroupList.loadInstalledApps(getContext().getPackageManager());
                    uidGroupList.loadNonPkgApps(getContext());
                    uidGroupList.loadFilters(this.mOpenHelper);
                    MatrixCursor combinedDataCursor = uidGroupList.getCombinedDataCursor(false);
                    if (combinedDataCursor != null) {
                        combinedDataCursor.setNotificationUri(getContext().getContentResolver(), uri);
                    }
                    return combinedDataCursor;
                }
                if (iMatch == 21) {
                    UidGroupList uidGroupList2 = new UidGroupList();
                    uidGroupList2.loadInstalledApps(getContext().getPackageManager());
                    uidGroupList2.loadNonPkgApps(getContext());
                    uidGroupList2.loadFilters(this.mOpenHelper);
                    MatrixCursor customFilterCursor = uidGroupList2.getCustomFilterCursor(uri.getLastPathSegment());
                    if (customFilterCursor != null) {
                        customFilterCursor.setNotificationUri(getContext().getContentResolver(), uri);
                    }
                    return customFilterCursor;
                }
                if (iMatch != 30) {
                    switch (iMatch) {
                        case 10:
                            sQLiteQueryBuilder.setTables("filter");
                            str3 = string;
                            strArr3 = stringList;
                            z = z2;
                            break;
                        case 11:
                            throw new IllegalArgumentException("Unknown URI " + uri);
                        case 12:
                            z2 = false;
                            sQLiteQueryBuilder.setTables("filter");
                            str3 = string;
                            strArr3 = stringList;
                            z = z2;
                            break;
                        case 13:
                            return makeOnlyGlobalCursor(uri, strArr, str, strArr2, str2);
                        default:
                            throw new IllegalArgumentException("Unknown URI " + uri);
                    }
                } else {
                    sQLiteQueryBuilder.setTables("app");
                }
                str4 = str2;
            }
            cursorQuery = sQLiteQueryBuilder.query(this.mOpenHelper.getWritableDatabase(), strArr, str3, strArr3, str5, null, str4);
            if (cursorQuery != null && z) {
                cursorQuery.setNotificationUri(getContext().getContentResolver(), uri);
            }
            return cursorQuery;
        }
        sQLiteQueryBuilder.setTables("pending");
        str3 = string;
        strArr3 = stringList;
        z = true;
        str4 = str2;
        cursorQuery = sQLiteQueryBuilder.query(this.mOpenHelper.getWritableDatabase(), strArr, str3, strArr3, str5, null, str4);
        if (cursorQuery != null) {
            cursorQuery.setNotificationUri(getContext().getContentResolver(), uri);
        }
        return cursorQuery;
    }

    private Cursor makeOnlyGlobalCursor(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        SQLiteQueryBuilder sQLiteQueryBuilder = new SQLiteQueryBuilder();
        StringBuilder sb = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        sb.append("(");
        sb.append("priority");
        sb.append("=");
        sb.append(-10);
        sb.append(")");
        sb.append("AND(");
        sb.append("pkgName");
        sb.append("='*')");
        sb2.append("(");
        sb2.append("priority");
        sb2.append("=");
        sb2.append(10);
        sb2.append(")");
        sb2.append("AND(");
        sb2.append("pkgName");
        sb2.append("='*')");
        if (str != null) {
            sb.append("AND(");
            sb.append(str);
            sb.append(")");
            sb2.append("AND(");
            sb2.append(str);
            sb2.append(")");
        }
        sQLiteQueryBuilder.setTables("filter");
        SQLiteDatabase writableDatabase = this.mOpenHelper.getWritableDatabase();
        Cursor cursorQuery = sQLiteQueryBuilder.query(writableDatabase, strArr, sb.toString(), strArr2, null, null, str2);
        Cursor cursorQuery2 = sQLiteQueryBuilder.query(writableDatabase, strArr, sb2.toString(), strArr2, null, null, str2);
        Cursor[] cursorArr = {cursorQuery, cursorQuery2};
        final int count = cursorQuery != null ? cursorQuery.getCount() : 0;
        final int count2 = cursorQuery2 != null ? cursorQuery2.getCount() : 0;
        MergeCursor mergeCursor = new MergeCursor(this, cursorArr) { // from class: app.greyshirts.firewall.db.DataProvider.1
            @Override // android.database.AbstractCursor, android.database.Cursor
            public Bundle getExtras() {
                Bundle bundle = new Bundle();
                bundle.putInt("pre", count);
                bundle.putInt("post", count2);
                return bundle;
            }
        };
        cursorQuery.setNotificationUri(getContext().getContentResolver(), uri);
        return mergeCursor;
    }

    @Override // android.content.ContentProvider
    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        String str2;
        int iMatch = this.mUriMatcher.match(uri);
        if (iMatch == 1) {
            str2 = "pending";
        } else {
            if (iMatch == 2) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 3) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 4) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch == 5) {
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            if (iMatch != 10) {
                if (iMatch == 11) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 13) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 30) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 20) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                if (iMatch == 21) {
                    throw new IllegalArgumentException("Unknown URI " + uri);
                }
                throw new IllegalArgumentException("Unknown URI " + uri);
            }
            str2 = "filter";
        }
        int iUpdate = this.mOpenHelper.getWritableDatabase().update(str2, contentValues, str, strArr);
        if (iUpdate > 0) {
            getContext().getContentResolver().notifyChange(uri, null);
            getContext().getContentResolver().notifyChange(CombinedDataContract.getInstance(getContext()).getContentUri(), null);
        }
        return iUpdate;
    }

    @Override // android.content.ContentProvider
    public Bundle call(String str, String str2, Bundle bundle) {
        if ("deleteUninstalled".equals(str)) {
            UidGroupList uidGroupList = new UidGroupList();
            uidGroupList.loadInstalledApps(getContext().getPackageManager());
            uidGroupList.loadNonPkgApps(getContext());
            uidGroupList.loadFilters(this.mOpenHelper);
            Filter.getInstance(getContext()).deletePolicyAndFilter(uidGroupList.getUninstalledPkgs());
            ContentResolver contentResolver = getContext().getContentResolver();
            contentResolver.notifyChange(CombinedDataContract.getInstance(getContext()).getContentUri(), null);
            contentResolver.notifyChange(FilterRuleContract.getInstance(getContext()).getContentUri(), null);
        }
        return super.call(str, str2, bundle);
    }

    private HashMap<String, String> createProjectionMap(HashMap<String, String> map, String[] strArr) {
        HashMap<String, String> map2 = new HashMap<>();
        if (strArr != null) {
            for (String str : strArr) {
                if (str != null) {
                    String str2 = map.get(str);
                    if (str2 != null) {
                        map2.put(str, str2);
                    } else {
                        map2.put(str, str);
                    }
                }
            }
        }
        for (String str3 : map.keySet()) {
            if (!map2.containsKey(str3)) {
                map2.put(str3, map.get(str3));
            }
        }
        return map2;
    }
}
