package app.greyshirts.firewall.db;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import app.greyshirts.firewall.app.MyVpnService;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import kotlin.TypeCastException;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class ImportExportKt {
    public static final String filterTypeToString(int i) {
        if (i == 0) {
            return "none";
        }
        if (i != 1) {
            return i != 2 ? "none" : "deny";
        }
        return "allow";
    }

    public static final List<FilterJsonFields> readFilterListFromDb(Context ctx) {
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        ArrayList arrayList = new ArrayList();
        DatabaseOpenHelper databaseOpenHelper = DatabaseOpenHelper.getInstance(ctx);
        Intrinsics.checkExpressionValueIsNotNull(databaseOpenHelper, "DatabaseOpenHelper.getInstance(ctx)");
        Cursor cursorQuery = databaseOpenHelper.getWritableDatabase().query("filter", null, null, null, null, null, null);
        if (cursorQuery != null) {
            try {
                int columnIndexOrThrow = cursorQuery.getColumnIndexOrThrow("serverIp");
                int columnIndexOrThrow2 = cursorQuery.getColumnIndexOrThrow("serverStrType");
                int columnIndexOrThrow3 = cursorQuery.getColumnIndexOrThrow("serverPort");
                int columnIndexOrThrow4 = cursorQuery.getColumnIndexOrThrow("protocol");
                int columnIndexOrThrow5 = cursorQuery.getColumnIndexOrThrow("type");
                int columnIndexOrThrow6 = cursorQuery.getColumnIndexOrThrow("type1");
                int columnIndexOrThrow7 = cursorQuery.getColumnIndexOrThrow("appName");
                int columnIndexOrThrow8 = cursorQuery.getColumnIndexOrThrow("pkgName");
                int columnIndexOrThrow9 = cursorQuery.getColumnIndexOrThrow("pkg2Name");
                int columnIndexOrThrow10 = cursorQuery.getColumnIndexOrThrow("pkg3Name");
                int columnIndexOrThrow11 = cursorQuery.getColumnIndexOrThrow("isPolicy");
                int columnIndexOrThrow12 = cursorQuery.getColumnIndexOrThrow("priority");
                cursorQuery.moveToFirst();
                while (!cursorQuery.isAfterLast()) {
                    String string = cursorQuery.getString(columnIndexOrThrow);
                    int i = columnIndexOrThrow;
                    Intrinsics.checkExpressionValueIsNotNull(string, "cursor.getString(colServerStr)");
                    int i2 = columnIndexOrThrow2;
                    arrayList.add(new FilterJsonFields(string, cursorQuery.getInt(columnIndexOrThrow2) == 0 ? "ip4" : "host", cursorQuery.getInt(columnIndexOrThrow3), cursorQuery.getInt(columnIndexOrThrow4) == 1 ? "udp" : "tcp", filterTypeToString(cursorQuery.getInt(columnIndexOrThrow5)), filterTypeToString(cursorQuery.getInt(columnIndexOrThrow6)), cursorQuery.getString(columnIndexOrThrow7), cursorQuery.getString(columnIndexOrThrow8), cursorQuery.getString(columnIndexOrThrow9), cursorQuery.getString(columnIndexOrThrow10), cursorQuery.getInt(columnIndexOrThrow11) != 1, cursorQuery.getInt(columnIndexOrThrow12)));
                    cursorQuery.moveToNext();
                    columnIndexOrThrow = i;
                    columnIndexOrThrow2 = i2;
                }
                cursorQuery.close();
            } catch (Throwable th) {
                cursorQuery.close();
                throw th;
            }
        }
        return arrayList;
    }

    public static final List<AppJsonFields> readAppListFromDb(Context ctx) {
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        ArrayList arrayList = new ArrayList();
        DatabaseOpenHelper databaseOpenHelper = DatabaseOpenHelper.getInstance(ctx);
        Intrinsics.checkExpressionValueIsNotNull(databaseOpenHelper, "DatabaseOpenHelper.getInstance(ctx)");
        Cursor cursorQuery = databaseOpenHelper.getWritableDatabase().query("app", null, null, null, null, null, null);
        if (cursorQuery != null) {
            try {
                int columnIndexOrThrow = cursorQuery.getColumnIndexOrThrow("appName");
                int columnIndexOrThrow2 = cursorQuery.getColumnIndexOrThrow("pkg1Name");
                cursorQuery.moveToFirst();
                while (!cursorQuery.isAfterLast()) {
                    arrayList.add(new AppJsonFields(cursorQuery.getString(columnIndexOrThrow), cursorQuery.getString(columnIndexOrThrow2)));
                    cursorQuery.moveToNext();
                }
                cursorQuery.close();
            } catch (Throwable th) {
                cursorQuery.close();
                throw th;
            }
        }
        return arrayList;
    }

    public static final ImportResult writeFilterListToDb(Context ctx, List<FilterJsonFields> filterList) {
        int i;
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        Intrinsics.checkParameterIsNotNull(filterList, "filterList");
        DatabaseOpenHelper databaseOpenHelper = DatabaseOpenHelper.getInstance(ctx);
        Intrinsics.checkExpressionValueIsNotNull(databaseOpenHelper, "DatabaseOpenHelper.getInstance(ctx)");
        SQLiteDatabase writableDatabase = databaseOpenHelper.getWritableDatabase();
        filterList.size();
        writableDatabase.beginTransaction();
        try {
            int i2 = 0;
            int i3 = 0;
            for (FilterJsonFields filterJsonFields : filterList) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("serverIp", filterJsonFields.getServer());
                contentValues.put("serverStrType", Integer.valueOf(Intrinsics.areEqual(filterJsonFields.getServerStrType(), "ip4") ? 0 : 1));
                contentValues.put("serverPort", Integer.valueOf(filterJsonFields.getPort()));
                contentValues.put("protocol", Integer.valueOf(Intrinsics.areEqual(filterJsonFields.getProto(), "udp") ? 1 : 0));
                contentValues.put("type", Integer.valueOf(filterStringToType(filterJsonFields.getWifi())));
                contentValues.put("type1", Integer.valueOf(filterStringToType(filterJsonFields.getMobile())));
                contentValues.put("appName", filterJsonFields.getAppName());
                contentValues.put("pkgName", filterJsonFields.getPkg1Name());
                contentValues.put("pkg2Name", filterJsonFields.getPkg2Name());
                contentValues.put("pkg3Name", filterJsonFields.getPkg3Name());
                contentValues.put("isPolicy", Integer.valueOf(filterJsonFields.isCustom() ? 0 : 1));
                if (filterJsonFields.getPriority() < 0) {
                    i = -10;
                } else {
                    i = filterJsonFields.getPriority() > 0 ? 10 : 0;
                }
                contentValues.put("priority", Integer.valueOf(i));
                StringBuilder sb = new StringBuilder();
                ArrayList arrayList = new ArrayList();
                for (String str : new String[]{"serverIp", "serverStrType", "serverPort", "protocol", "type", "type1", "appName", "pkgName", "pkg2Name", "pkg3Name", "isPolicy"}) {
                    if (!(sb.length() == 0)) {
                        sb.append(" AND ");
                    }
                    if (contentValues.get(str) == null) {
                        sb.append(str + " IS NULL");
                        Intrinsics.checkExpressionValueIsNotNull(sb, "where.append(\"${key} IS NULL\")");
                    } else {
                        sb.append(str + "=?");
                        arrayList.add(contentValues.get(str).toString());
                    }
                }
                String string = sb.toString();
                Object[] array = arrayList.toArray(new String[0]);
                if (array != null) {
                    if (writableDatabase.update("filter", contentValues, string, (String[]) array) == 0) {
                        writableDatabase.insert("filter", null, contentValues);
                        i2++;
                    } else {
                        i3++;
                    }
                } else {
                    throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<T>");
                }
            }
            writableDatabase.setTransactionSuccessful();
            writableDatabase.endTransaction();
            return new ImportResult(i2, i3, null);
        } catch (Throwable th) {
            writableDatabase.endTransaction();
            throw th;
        }
    }

    public static final void writeAppListToDb(Context ctx, List<AppJsonFields> appList) {
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        Intrinsics.checkParameterIsNotNull(appList, "appList");
        DatabaseOpenHelper databaseOpenHelper = DatabaseOpenHelper.getInstance(ctx);
        Intrinsics.checkExpressionValueIsNotNull(databaseOpenHelper, "DatabaseOpenHelper.getInstance(ctx)");
        SQLiteDatabase writableDatabase = databaseOpenHelper.getWritableDatabase();
        writableDatabase.beginTransaction();
        try {
            for (AppJsonFields appJsonFields : appList) {
                ContentValues contentValues = new ContentValues();
                contentValues.put("appName", appJsonFields.getAppName());
                contentValues.put("pkg1Name", appJsonFields.getPkgName());
                StringBuilder sb = new StringBuilder();
                ArrayList arrayList = new ArrayList();
                for (String str : new String[]{"appName", "pkg1Name"}) {
                    if (!(sb.length() == 0)) {
                        sb.append(" AND ");
                    }
                    if (contentValues.get(str) == null) {
                        sb.append(str + " IS NULL");
                        Intrinsics.checkExpressionValueIsNotNull(sb, "where.append(\"${key} IS NULL\")");
                    } else {
                        sb.append(str + "=?");
                        arrayList.add(contentValues.get(str).toString());
                    }
                }
                String string = sb.toString();
                Object[] array = arrayList.toArray(new String[0]);
                if (array != null) {
                    if (writableDatabase.update("app", contentValues, string, (String[]) array) == 0) {
                        writableDatabase.insert("app", null, contentValues);
                    }
                } else {
                    throw new TypeCastException("null cannot be cast to non-null type kotlin.Array<T>");
                }
            }
            writableDatabase.setTransactionSuccessful();
            writableDatabase.endTransaction();
        } catch (Throwable th) {
            writableDatabase.endTransaction();
            throw th;
        }
    }

    public static final void exportJsonToUri(Context ctx, Uri outputUri) throws IOException {
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        Intrinsics.checkParameterIsNotNull(outputUri, "outputUri");
        String jsonData = new Gson().toJson(new JsonFields(readFilterListFromDb(ctx), readAppListFromDb(ctx)));
        OutputStream outputStreamOpenOutputStream = ctx.getContentResolver().openOutputStream(outputUri);
        if (outputStreamOpenOutputStream != null) {
            Intrinsics.checkExpressionValueIsNotNull(outputStreamOpenOutputStream, "ctx.contentResolver.open…ption(\"cannot open file\")");
            try {
                Intrinsics.checkExpressionValueIsNotNull(jsonData, "jsonData");
                Charset charsetForName = Charset.forName("utf-8");
                Intrinsics.checkExpressionValueIsNotNull(charsetForName, "Charset.forName(\"utf-8\")");
                if (jsonData == null) {
                    throw new TypeCastException("null cannot be cast to non-null type java.lang.String");
                }
                byte[] bytes = jsonData.getBytes(charsetForName);
                Intrinsics.checkExpressionValueIsNotNull(bytes, "(this as java.lang.String).getBytes(charset)");
                outputStreamOpenOutputStream.write(bytes);
                outputStreamOpenOutputStream.close();
                return;
            } catch (Throwable th) {
                outputStreamOpenOutputStream.close();
                throw th;
            }
        }
        throw new RuntimeException("cannot open file");
    }

    public static final ImportResult importJsonFromUri(Context ctx, Uri inputUri) throws FileNotFoundException {
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        Intrinsics.checkParameterIsNotNull(inputUri, "inputUri");
        InputStream inputStreamOpenInputStream = ctx.getContentResolver().openInputStream(inputUri);
        if (inputStreamOpenInputStream != null) {
            Intrinsics.checkExpressionValueIsNotNull(inputStreamOpenInputStream, "ctx.contentResolver.open…ption(\"cannot open file\")");
            return importJsonFromInputStream(ctx, inputStreamOpenInputStream);
        }
        throw new RuntimeException("cannot open file");
    }

    public static final ImportResult importJsonFromInputStream(Context ctx, InputStream inputStream) throws IOException {
        Intrinsics.checkParameterIsNotNull(ctx, "ctx");
        Intrinsics.checkParameterIsNotNull(inputStream, "inputStream");
        try {
            Object objFromJson = new Gson().fromJson(new InputStreamReader(inputStream), new TypeToken<JsonFields>() { // from class: app.greyshirts.firewall.db.ImportExportKt$importJsonFromInputStream$jsonFieldsType$1
            }.getType());
            Intrinsics.checkExpressionValueIsNotNull(objFromJson, "Gson().fromJson(reader, jsonFieldsType)");
            JsonFields jsonFields = (JsonFields) objFromJson;
            ImportResult importResultWriteFilterListToDb = writeFilterListToDb(ctx, jsonFields.getFilters());
            writeAppListToDb(ctx, jsonFields.getApps());
            ContentResolver contentResolver = ctx.getContentResolver();
            AppContract appContract = AppContract.getInstance(ctx);
            Intrinsics.checkExpressionValueIsNotNull(appContract, "AppContract.getInstance(ctx)");
            contentResolver.notifyChange(appContract.getContentUri(), null);
            ContentResolver contentResolver2 = ctx.getContentResolver();
            FilterRuleContract filterRuleContract = FilterRuleContract.getInstance(ctx);
            Intrinsics.checkExpressionValueIsNotNull(filterRuleContract, "FilterRuleContract.getInstance(ctx)");
            contentResolver2.notifyChange(filterRuleContract.getContentUri(), null);
            MyVpnService.notifyBlockingRuleChange(ctx);
            return importResultWriteFilterListToDb;
        } finally {
            inputStream.close();
        }
    }

    public static final int filterStringToType(String str) {
        if (str != null) {
            int iHashCode = str.hashCode();
            if (iHashCode != 3079692) {
                if (iHashCode == 92906313 && str.equals("allow")) {
                    return 1;
                }
            } else if (str.equals("deny")) {
                return 2;
            }
        }
        return 0;
    }
}
