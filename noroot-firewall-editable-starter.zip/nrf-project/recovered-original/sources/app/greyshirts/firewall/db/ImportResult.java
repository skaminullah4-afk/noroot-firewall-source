package app.greyshirts.firewall.db;

import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: ImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class ImportResult {
    private final Exception e;
    private final int numInserted;
    private final int numUpdated;

    public boolean equals(Object obj) {
        if (this != obj) {
            if (obj instanceof ImportResult) {
                ImportResult importResult = (ImportResult) obj;
                if (this.numInserted == importResult.numInserted) {
                    if (!(this.numUpdated == importResult.numUpdated) || !Intrinsics.areEqual(this.e, importResult.e)) {
                    }
                }
            }
            return false;
        }
        return true;
    }

    public int hashCode() {
        int iHashCode = ((Integer.valueOf(this.numInserted).hashCode() * 31) + Integer.valueOf(this.numUpdated).hashCode()) * 31;
        Exception exc = this.e;
        return iHashCode + (exc != null ? exc.hashCode() : 0);
    }

    public String toString() {
        return "ImportResult(numInserted=" + this.numInserted + ", numUpdated=" + this.numUpdated + ", e=" + this.e + ")";
    }

    public ImportResult(int i, int i2, Exception exc) {
        this.numInserted = i;
        this.numUpdated = i2;
        this.e = exc;
    }

    public final Exception getE() {
        return this.e;
    }

    public final int getNumInserted() {
        return this.numInserted;
    }

    public final int getNumUpdated() {
        return this.numUpdated;
    }
}
