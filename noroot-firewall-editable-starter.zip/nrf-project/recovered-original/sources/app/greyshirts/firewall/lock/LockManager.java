package app.greyshirts.firewall.lock;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: LockManager.kt */
/* JADX INFO: loaded from: classes.dex */
public final class LockManager {
    public static final Companion Companion = new Companion(null);
    private static LockManager instance;
    private MutableLiveData<Boolean> _isLockedLiveData;
    private final SharedPreferences pref;

    public static final synchronized LockManager getInstance(Context context) {
        return Companion.getInstance(context);
    }

    public final boolean isLocked() {
        return false;
    }

    public LockManager(SharedPreferences pref) {
        Intrinsics.checkParameterIsNotNull(pref, "pref");
        this.pref = pref;
        this._isLockedLiveData = new MutableLiveData<>();
    }

    /* JADX INFO: compiled from: LockManager.kt */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final synchronized LockManager getInstance(Context ctx) {
            LockManager lockManager;
            Intrinsics.checkParameterIsNotNull(ctx, "ctx");
            if (LockManager.instance == null) {
                SharedPreferences sharedPreferences = ctx.getSharedPreferences("pref", 0);
                Intrinsics.checkExpressionValueIsNotNull(sharedPreferences, "ctx.getSharedPreferences(\"pref\", 0)");
                LockManager.instance = new LockManager(sharedPreferences);
            }
            lockManager = LockManager.instance;
            if (lockManager == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            return lockManager;
        }
    }

    public final LiveData<Boolean> isLockedLiveData() {
        return this._isLockedLiveData;
    }

    public final void lock(String newPassCode) {
        Intrinsics.checkParameterIsNotNull(newPassCode, "newPassCode");
        SharedPreferences.Editor editorEdit = this.pref.edit();
        editorEdit.putBoolean("passCodeLocked", true);
        editorEdit.putString("passCode", newPassCode);
        editorEdit.apply();
        this._isLockedLiveData.setValue(true);
    }

    public final void unlock() {
        SharedPreferences.Editor editorEdit = this.pref.edit();
        editorEdit.putBoolean("passCodeLocked", false);
        editorEdit.apply();
        this._isLockedLiveData.setValue(false);
    }

    public final boolean isPassCodeValid(String code) {
        Intrinsics.checkParameterIsNotNull(code, "code");
        return Intrinsics.areEqual(this.pref.getString("passCode", ""), code);
    }
}
