package app.greyshirts.firewall.cache;

/* JADX INFO: loaded from: classes.dex */
public class AddressCache {
    private final BasicLruCache<String, AddressCacheEntry> cache = new BasicLruCache<>(512);

    public enum EntryType {
        VALID,
        NXDOMAIN,
        ERROR
    }

    public static class AddressCacheEntry {
        final long expiryNanos;
        public final String hostname;
        public final EntryType type;

        AddressCacheEntry(EntryType entryType, String str, long j) {
            this.type = entryType;
            this.hostname = str;
            this.expiryNanos = j;
        }
    }

    public AddressCacheEntry get(String str) {
        AddressCacheEntry addressCacheEntry = this.cache.get(str);
        if (addressCacheEntry == null || addressCacheEntry.expiryNanos < System.nanoTime()) {
            return null;
        }
        return new AddressCacheEntry(addressCacheEntry.type, addressCacheEntry.hostname, addressCacheEntry.expiryNanos);
    }

    public void putValid(String str, String str2) {
        put(str, str2, EntryType.VALID);
    }

    public void putNxDomain(String str) {
        put(str, null, EntryType.NXDOMAIN);
    }

    public void putError(String str) {
        put(str, null, EntryType.ERROR);
    }

    private void put(String str, String str2, EntryType entryType) {
        this.cache.put(str, new AddressCacheEntry(entryType, str2, System.nanoTime() + (entryType == EntryType.VALID ? 1800000000000L : 30000000000L)));
    }
}
