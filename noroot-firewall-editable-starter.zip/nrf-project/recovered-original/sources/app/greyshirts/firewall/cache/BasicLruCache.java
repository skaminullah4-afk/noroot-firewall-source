package app.greyshirts.firewall.cache;

import java.util.LinkedHashMap;
import java.util.Map;

/* JADX INFO: loaded from: classes.dex */
public class BasicLruCache<K, V> {
    private final LinkedHashMap<K, V> map;
    private final int maxSize;

    protected V create(K k) {
        return null;
    }

    protected void entryEvicted(K k, V v) {
    }

    public BasicLruCache(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        this.maxSize = i;
        this.map = new LinkedHashMap<>(0, 0.75f, true);
    }

    public final synchronized V get(K k) {
        try {
            if (k == null) {
                throw new NullPointerException();
            }
            V v = this.map.get(k);
            if (v != null) {
                return v;
            }
            V vCreate = create(k);
            if (vCreate != null) {
                this.map.put(k, vCreate);
                trimToSize(this.maxSize);
            }
            return vCreate;
        } catch (Throwable th) {
            throw th;
        }
    }

    public final synchronized V put(K k, V v) {
        V vPut;
        try {
            if (k == null || v == null) {
                throw new NullPointerException();
            }
            vPut = this.map.put(k, v);
            trimToSize(this.maxSize);
        } catch (Throwable th) {
            throw th;
        }
        return vPut;
    }

    private void trimToSize(int i) {
        while (this.map.size() > i) {
            Map.Entry<K, V> next = this.map.entrySet().iterator().next();
            K key = next.getKey();
            V value = next.getValue();
            this.map.remove(key);
            entryEvicted(key, value);
        }
    }
}
