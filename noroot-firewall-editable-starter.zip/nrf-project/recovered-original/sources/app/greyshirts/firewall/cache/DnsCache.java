package app.greyshirts.firewall.cache;

import android.os.Handler;

/* JADX INFO: loaded from: classes.dex */
public class DnsCache {
    private static final DnsCache instance = new DnsCache();
    private final Object lock = new Object();
    private final AddressCache ip2name = new AddressCache();

    public interface ResolveNameResult {
        void onFinish(String str, String str2);
    }

    public static native int getnameinfo(String str, String[] strArr);

    static {
        System.loadLibrary("core");
    }

    public static DnsCache getInstance() {
        return instance;
    }

    private DnsCache() {
    }

    public AddressCache.AddressCacheEntry resolveNameFromIpPeek(String str) {
        AddressCache.AddressCacheEntry addressCacheEntry;
        synchronized (this.lock) {
            addressCacheEntry = this.ip2name.get(str);
        }
        return addressCacheEntry;
    }

    public void startResolver(final String str, final ResolveNameResult resolveNameResult) {
        new Thread(new Runnable() { // from class: app.greyshirts.firewall.cache.DnsCache.1
            @Override // java.lang.Runnable
            public void run() {
                String[] strArr = new String[1];
                int i = DnsCache.getnameinfo(str, strArr);
                String str2 = null;
                if (i == 0) {
                    str2 = strArr[0];
                    synchronized (DnsCache.this.lock) {
                        DnsCache.this.ip2name.putValid(str, str2);
                    }
                } else if (i == 1) {
                    synchronized (DnsCache.this.lock) {
                        DnsCache.this.ip2name.putNxDomain(str);
                    }
                } else if (DnsCache.getnameinfo("8.8.8.8", strArr) == 0) {
                    synchronized (DnsCache.this.lock) {
                        DnsCache.this.ip2name.putNxDomain(str);
                    }
                } else {
                    synchronized (DnsCache.this.lock) {
                        DnsCache.this.ip2name.putError(str);
                    }
                }
                resolveNameResult.onFinish(str, str2);
            }
        }).start();
    }

    public AddressCache.AddressCacheEntry resolveNameFromIpForUiThread(String str, final ResolveNameResult resolveNameResult) {
        AddressCache.AddressCacheEntry addressCacheEntryResolveNameFromIpPeek = resolveNameFromIpPeek(str);
        if (addressCacheEntryResolveNameFromIpPeek != null) {
            return addressCacheEntryResolveNameFromIpPeek;
        }
        final Handler handler = new Handler();
        startResolver(str, new ResolveNameResult(this) { // from class: app.greyshirts.firewall.cache.DnsCache.2
            @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
            public void onFinish(final String str2, final String str3) {
                handler.post(new Runnable() { // from class: app.greyshirts.firewall.cache.DnsCache.2.1
                    @Override // java.lang.Runnable
                    public void run() {
                        resolveNameResult.onFinish(str2, str3);
                    }
                });
            }
        });
        return null;
    }
}
