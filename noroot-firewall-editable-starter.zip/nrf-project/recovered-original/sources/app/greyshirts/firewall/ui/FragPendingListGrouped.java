package app.greyshirts.firewall.ui;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;
import androidx.fragment.app.ListFragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.MyVpnService;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.db.PendingConnectionContract;

/* JADX INFO: loaded from: classes.dex */
public class FragPendingListGrouped extends ListFragment implements LoaderManager.LoaderCallbacks<Cursor>, AdapterPendingListGrouped.AdapterPendingListGroupedListener {
    static final String[] PROJECTION = {"_id", "appName", "allAppName", "pkgName", "pkg2Name", "pkg3Name", "groupCount", "createdDateMax"};
    private AdapterPendingListGrouped adapter;
    private ListView lv;

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Log.i("NRFW", "onCreate" + this);
        this.adapter = new AdapterPendingListGrouped(getActivity());
        this.adapter.setListener(this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        setEmptyText(getString(R.string.pending_no_pending_access));
        getLoaderManager().initLoader(0, null, this);
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroy() {
        super.onDestroy();
        Log.i("NRFW", "onDestroy" + this);
    }

    @Override // androidx.fragment.app.ListFragment, androidx.fragment.app.Fragment
    public void onViewCreated(View view, Bundle bundle) {
        super.onViewCreated(view, bundle);
        if (this.adapter.getCursor() == null) {
            Log.i("pend", "adapter.cursor is null");
            setListShown(false);
        } else {
            Log.i("pend", "adapter.cursor is not null");
        }
        setListAdapter(this.adapter);
        this.lv = getListView();
        this.lv.setFastScrollEnabled(true);
    }

    @Override // androidx.fragment.app.ListFragment, androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        setListAdapter(null);
        this.lv = null;
    }

    @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
    public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
        return new CursorLoader(getActivity(), PendingConnectionContract.getInstance(getActivity()).getContentGroupedByPkg1Uri(), PROJECTION, null, null, "createdDateMax DESC");
    }

    @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
    public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
        Log.i("NRFW", "onLoadFinished" + this + " data=" + cursor);
        this.adapter.changeCursor(cursor);
        if (this.lv == null) {
            return;
        }
        if (isResumed()) {
            setListShown(true);
        } else {
            setListShownNoAnimation(true);
        }
    }

    @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
    public void onLoaderReset(Loader<Cursor> loader) {
        this.adapter.changeCursor(null);
    }

    @Override // app.greyshirts.firewall.ui.AdapterPendingListGrouped.AdapterPendingListGroupedListener
    public void onAllowDenyClicked(String str, PackageNames packageNames, Filter.Type type) {
        Context applicationContext = getActivity().getApplicationContext();
        Filter filter = Filter.getInstance(applicationContext);
        filter.setPolicyRule(Filter.Profile.PROFILE_ALL, str, packageNames, type);
        filter.removePendingMatching(packageNames);
        MyVpnService.notifyBlockingRuleChange(applicationContext);
    }

    @Override // app.greyshirts.firewall.ui.AdapterPendingListGrouped.AdapterPendingListGroupedListener
    public void onItemClicked(PackageNames packageNames, String str) {
        Intent intent = new Intent(getActivity(), (Class<?>) ActivityAppDetail.class);
        intent.putExtra("extra.pkgs", packageNames.getCommaJoinedString());
        intent.putExtra("extra.leaderName", str);
        startActivity(intent);
    }
}
