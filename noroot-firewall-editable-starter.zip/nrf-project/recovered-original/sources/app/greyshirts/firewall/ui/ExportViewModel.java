package app.greyshirts.firewall.ui;

import android.app.Application;
import android.net.Uri;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import app.greyshirts.firewall.db.ImportExportKt;
import app.greyshirts.firewall.db.ImportResult;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.GlobalScope;

/* JADX INFO: compiled from: FragImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class ExportViewModel extends AndroidViewModel {
    private final MutableLiveData<Exception> _exportResult;
    private final MutableLiveData<ImportResult> _importResult;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ExportViewModel(Application app2) {
        super(app2);
        Intrinsics.checkParameterIsNotNull(app2, "app");
        this._exportResult = new MutableLiveData<>();
        this._importResult = new MutableLiveData<>();
    }

    public final LiveData<Exception> getExportResult() {
        return this._exportResult;
    }

    public final LiveData<ImportResult> getImportResult() {
        return this._importResult;
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.ExportViewModel$startExporting$1, reason: invalid class name */
    /* JADX INFO: compiled from: FragImportExport.kt */
    @DebugMetadata(c = "app.greyshirts.firewall.ui.ExportViewModel$startExporting$1", f = "FragImportExport.kt", l = {}, m = "invokeSuspend")
    static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Uri $exportUri;
        int label;
        private CoroutineScope p$;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        AnonymousClass1(Uri uri, Continuation continuation) {
            super(2, continuation);
            this.$exportUri = uri;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> completion) {
            Intrinsics.checkParameterIsNotNull(completion, "completion");
            AnonymousClass1 anonymousClass1 = ExportViewModel.this.new AnonymousClass1(this.$exportUri, completion);
            anonymousClass1.p$ = (CoroutineScope) obj;
            return anonymousClass1;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) throws Throwable {
            IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            try {
                Application application = ExportViewModel.this.getApplication();
                Intrinsics.checkExpressionValueIsNotNull(application, "getApplication()");
                ImportExportKt.exportJsonToUri(application, this.$exportUri);
                ExportViewModel.this._exportResult.postValue(null);
            } catch (Exception e) {
                ExportViewModel.this._exportResult.postValue(e);
            }
            return Unit.INSTANCE;
        }
    }

    public final void startExporting(Uri exportUri) {
        Intrinsics.checkParameterIsNotNull(exportUri, "exportUri");
        BuildersKt__Builders_commonKt.launch$default(GlobalScope.INSTANCE, null, null, new AnonymousClass1(exportUri, null), 3, null);
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.ExportViewModel$startImporting$1, reason: invalid class name and case insensitive filesystem */
    /* JADX INFO: compiled from: FragImportExport.kt */
    @DebugMetadata(c = "app.greyshirts.firewall.ui.ExportViewModel$startImporting$1", f = "FragImportExport.kt", l = {}, m = "invokeSuspend")
    static final class C00031 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
        final /* synthetic */ Uri $importUri;
        int label;
        private CoroutineScope p$;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        C00031(Uri uri, Continuation continuation) {
            super(2, continuation);
            this.$importUri = uri;
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Continuation<Unit> create(Object obj, Continuation<?> completion) {
            Intrinsics.checkParameterIsNotNull(completion, "completion");
            C00031 c00031 = ExportViewModel.this.new C00031(this.$importUri, completion);
            c00031.p$ = (CoroutineScope) obj;
            return c00031;
        }

        @Override // kotlin.jvm.functions.Function2
        public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
            return ((C00031) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
        public final Object invokeSuspend(Object obj) throws Throwable {
            IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            if (this.label != 0) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            ResultKt.throwOnFailure(obj);
            try {
                MutableLiveData mutableLiveData = ExportViewModel.this._importResult;
                Application application = ExportViewModel.this.getApplication();
                Intrinsics.checkExpressionValueIsNotNull(application, "getApplication()");
                mutableLiveData.postValue(ImportExportKt.importJsonFromUri(application, this.$importUri));
            } catch (Exception e) {
                ExportViewModel.this._importResult.postValue(new ImportResult(0, 0, e));
            }
            return Unit.INSTANCE;
        }
    }

    public final void startImporting(Uri importUri) {
        Intrinsics.checkParameterIsNotNull(importUri, "importUri");
        BuildersKt__Builders_commonKt.launch$default(GlobalScope.INSTANCE, null, null, new C00031(importUri, null), 3, null);
    }
}
