package app.greyshirts.firewall.ui;

import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.cursoradapter.widget.CursorAdapter;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.AppInfo;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.PackageNames;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class AdapterPendingListGrouped extends CursorAdapter {
    private final LayoutInflater inflater;
    private AdapterPendingListGroupedListener listener;

    public interface AdapterPendingListGroupedListener {
        void onAllowDenyClicked(String str, PackageNames packageNames, Filter.Type type);

        void onItemClicked(PackageNames packageNames, String str);
    }

    public AdapterPendingListGrouped(Context context) {
        super(context, (Cursor) null, 0);
        this.inflater = LayoutInflater.from(context);
    }

    public void setListener(AdapterPendingListGroupedListener adapterPendingListGroupedListener) {
        this.listener = adapterPendingListGroupedListener;
    }

    @Override // androidx.cursoradapter.widget.CursorAdapter
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        View viewInflate = this.inflater.inflate(R.layout.listitem_pending2, (ViewGroup) null);
        Tag tag = new Tag();
        tag.viewIcon = (ImageView) viewInflate.findViewById(R.id.icon);
        tag.viewName = (TextView) viewInflate.findViewById(R.id.name);
        tag.viewNumPending = (TextView) viewInflate.findViewById(R.id.numPending);
        tag.viewAllowButton = viewInflate.findViewById(R.id.allow);
        tag.viewDenyButton = viewInflate.findViewById(R.id.deny);
        viewInflate.setTag(tag);
        tag.viewAllowButton.setTag(tag);
        tag.viewDenyButton.setTag(tag);
        viewInflate.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterPendingListGrouped.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (AdapterPendingListGrouped.this.listener != null) {
                    Tag tag2 = (Tag) view.getTag();
                    AdapterPendingListGrouped.this.listener.onItemClicked(tag2.pkgs, tag2.leaderAppName);
                }
            }
        });
        tag.viewAllowButton.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterPendingListGrouped.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (AdapterPendingListGrouped.this.listener != null) {
                    Tag tag2 = (Tag) view.getTag();
                    AdapterPendingListGrouped.this.listener.onAllowDenyClicked(tag2.leaderAppName, tag2.pkgs, Filter.Type.POLICY_ALLOW);
                }
            }
        });
        tag.viewDenyButton.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterPendingListGrouped.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (AdapterPendingListGrouped.this.listener != null) {
                    Tag tag2 = (Tag) view.getTag();
                    AdapterPendingListGrouped.this.listener.onAllowDenyClicked(tag2.leaderAppName, tag2.pkgs, Filter.Type.POLICY_DENY);
                }
            }
        });
        return viewInflate;
    }

    @Override // androidx.cursoradapter.widget.CursorAdapter
    public void bindView(View view, Context context, Cursor cursor) {
        Tag tag = (Tag) view.getTag();
        tag._id = cursor.getLong(cursor.getColumnIndexOrThrow("_id"));
        tag.allAppName = cursor.getString(cursor.getColumnIndexOrThrow("allAppName"));
        tag.leaderAppName = cursor.getString(cursor.getColumnIndexOrThrow("appName"));
        tag.numPending = cursor.getInt(cursor.getColumnIndexOrThrow("groupCount"));
        ArrayList arrayList = new ArrayList();
        String string = cursor.getString(cursor.getColumnIndexOrThrow("pkgName"));
        if (!TextUtils.isEmpty(string)) {
            arrayList.add(string);
        }
        String string2 = cursor.getString(cursor.getColumnIndexOrThrow("pkg2Name"));
        if (!TextUtils.isEmpty(string2)) {
            arrayList.add(string2);
        }
        String string3 = cursor.getString(cursor.getColumnIndexOrThrow("pkg3Name"));
        if (!TextUtils.isEmpty(string3)) {
            arrayList.add(string3);
        }
        String[] strArr = new String[arrayList.size()];
        arrayList.toArray(strArr);
        tag.pkgs = PackageNames.newInstance(strArr);
        tag.viewName.setText(tag.allAppName);
        TextView textView = tag.viewNumPending;
        Resources resources = context.getResources();
        int i = tag.numPending;
        textView.setText(resources.getQuantityString(R.plurals.pending_count, i, Integer.valueOf(i)));
        tag.viewIcon.setImageDrawable(AppInfo.getIcon(view.getContext(), tag.pkgs.getAt(0)));
    }

    static class Tag {
        long _id;
        String allAppName;
        String leaderAppName;
        int numPending;
        PackageNames pkgs;
        View viewAllowButton;
        View viewDenyButton;
        ImageView viewIcon;
        TextView viewName;
        TextView viewNumPending;

        Tag() {
        }
    }
}
