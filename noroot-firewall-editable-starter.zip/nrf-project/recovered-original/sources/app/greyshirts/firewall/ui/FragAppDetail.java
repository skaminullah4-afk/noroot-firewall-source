package app.greyshirts.firewall.ui;

import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.AppInfo;
import app.greyshirts.firewall.app.AsyncImageDrawable;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.MyVpnService;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.db.CombinedDataContract;
import app.greyshirts.firewall.db.FilterRuleContract;
import app.greyshirts.firewall.db.PendingConnectionContract;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;
import java.util.HashSet;

/* JADX INFO: loaded from: classes.dex */
public class FragAppDetail extends Fragment {
    private AdapterAppDetail adapter;
    private Context ctx;
    private Filter filter;
    private ModelGroup modelGroup;
    private boolean pendingAccessLoaded;
    private AllowDenyCheckbox viewCheckMobile;
    private AllowDenyCheckbox viewCheckWifi;
    private View viewContent;
    private ImageView viewIcon;
    private ListView viewList;
    private TextView viewName;
    private View viewProgress;
    private TextView viewTextMobile;
    private TextView viewTextWifi;
    private HashSet<Long> selectedFilterIds = new HashSet<>();
    private HashSet<Long> selectedPendingIds = new HashSet<>();
    private final AbsListView.OnScrollListener onScrollListener = new AbsListView.OnScrollListener() { // from class: app.greyshirts.firewall.ui.FragAppDetail.2
        @Override // android.widget.AbsListView.OnScrollListener
        public void onScrollStateChanged(AbsListView absListView, int i) {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
            Log.i("NWFW", "first=" + i + " visibles=" + i2 + " total=" + i3);
            if ((FragAppDetail.this.selectedFilterIds.size() != 0 || FragAppDetail.this.selectedPendingIds.size() != 0) && FragAppDetail.this.selectedPendingIds.size() > 0) {
            }
        }
    };
    private final LoaderManager.LoaderCallbacks<Cursor> customFilterLoaderCallbacks = new LoaderManager.LoaderCallbacks<Cursor>() { // from class: app.greyshirts.firewall.ui.FragAppDetail.4
        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
            return new CursorLoader(FragAppDetail.this.getActivity(), Uri.withAppendedPath(CombinedDataContract.getInstance(FragAppDetail.this.getActivity()).getContentUri(), FragAppDetail.this.getPkgs()), null, null, null, null);
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
            if (cursor != null) {
                Bundle extras = cursor.getExtras();
                FragAppDetail fragAppDetail = FragAppDetail.this;
                fragAppDetail.modelGroup = fragAppDetail.loadModelGroup(extras);
            }
            FragAppDetail.this.adapter.swapCustomFilterCursor(cursor);
            FragAppDetail.this.updateView();
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoaderReset(Loader<Cursor> loader) {
            FragAppDetail.this.adapter.swapCustomFilterCursor(null);
            FragAppDetail.this.updateView();
        }
    };
    private final LoaderManager.LoaderCallbacks<Cursor> pendingAccessLoaderCallbacks = new LoaderManager.LoaderCallbacks<Cursor>() { // from class: app.greyshirts.firewall.ui.FragAppDetail.5
        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
            return new CursorLoader(FragAppDetail.this.getActivity(), Uri.withAppendedPath(PendingConnectionContract.getInstance(FragAppDetail.this.getActivity()).getContentFilterByPkgs(), FragAppDetail.this.getPkgs()), null, null, null, "_id DESC");
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
            FragAppDetail.this.pendingAccessLoaded = true;
            FragAppDetail.this.adapter.swapPendingAccessCursor(cursor);
            FragAppDetail.this.updateView();
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoaderReset(Loader<Cursor> loader) {
            FragAppDetail.this.adapter.swapPendingAccessCursor(null);
            FragAppDetail.this.updateView();
        }
    };
    private final AdapterAppDetail.OnCustomFilterCheckStateChangedListener onCustomFilterCheckStateChanged = new AdapterAppDetail.OnCustomFilterCheckStateChangedListener() { // from class: app.greyshirts.firewall.ui.FragAppDetail.6
        @Override // app.greyshirts.firewall.ui.AdapterAppDetail.OnCustomFilterCheckStateChangedListener
        public void onCustomFilterChanged(long j, Filter.Profile profile, AllowDenyCheckbox.CheckState checkState) {
            int i = AnonymousClass12.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[checkState.ordinal()];
            int i2 = 2;
            if (i == 1) {
                i2 = 1;
            } else if (i != 2) {
                i2 = 0;
            }
            FragAppDetail.this.filter.updateCustomFilter(j, profile, i2);
            MyVpnService.notifyBlockingRuleChange(FragAppDetail.this.getActivity());
        }
    };
    private final AdapterAppDetail.OnRuleDeletedListener onRuleDeleted = new AdapterAppDetail.OnRuleDeletedListener() { // from class: app.greyshirts.firewall.ui.FragAppDetail.7
        @Override // app.greyshirts.firewall.ui.AdapterAppDetail.OnRuleDeletedListener
        public void onRuleDeleted() {
            MyVpnService.notifyBlockingRuleChange(FragAppDetail.this.getActivity());
        }
    };
    private final AllowDenyCheckbox.OnCheckStateChanged onWifiPolicyChecked = new AllowDenyCheckbox.OnCheckStateChanged() { // from class: app.greyshirts.firewall.ui.FragAppDetail.8
        @Override // app.greyshirts.firewall.ui.widget.AllowDenyCheckbox.OnCheckStateChanged
        public void onCheckStateChanged(AllowDenyCheckbox allowDenyCheckbox, AllowDenyCheckbox.CheckState checkState) {
            FragAppDetail.this.changePolicy(Filter.Profile.PROFILE_WIFI, (ModelGroup) allowDenyCheckbox.getTag(), checkState);
        }
    };
    private final AllowDenyCheckbox.OnCheckStateChanged onMobilePolicyChecked = new AllowDenyCheckbox.OnCheckStateChanged() { // from class: app.greyshirts.firewall.ui.FragAppDetail.9
        @Override // app.greyshirts.firewall.ui.widget.AllowDenyCheckbox.OnCheckStateChanged
        public void onCheckStateChanged(AllowDenyCheckbox allowDenyCheckbox, AllowDenyCheckbox.CheckState checkState) {
            FragAppDetail.this.changePolicy(Filter.Profile.PROFILE_MOBILE, (ModelGroup) allowDenyCheckbox.getTag(), checkState);
        }
    };
    private final View.OnClickListener onAddRuleClicked = new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.FragAppDetail.10
        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (FragAppDetail.this.modelGroup == null) {
                return;
            }
            DiagFragFilterEdit.newInstanceNewAppCustomFilter(FragAppDetail.this.modelGroup).show(FragAppDetail.this.getFragmentManager(), null);
        }
    };
    private final AdapterView.OnItemClickListener onListItemClicked = new AdapterView.OnItemClickListener() { // from class: app.greyshirts.firewall.ui.FragAppDetail.11
        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            if (view instanceof ViewCustomFilter) {
                DiagFragFilterEdit.newInstanceModifyAppCustomFilter(((ViewCustomFilter) view).getModel()).show(FragAppDetail.this.getFragmentManager(), null);
            } else if (view instanceof ViewPendingAccess) {
                DiagFragFilterEdit.newInstanceNewAppCustomFilter(((ViewPendingAccess) view).getModel()).show(FragAppDetail.this.getFragmentManager(), null);
            }
        }
    };

    public static FragAppDetail newInstance(String str, String str2) {
        FragAppDetail fragAppDetail = new FragAppDetail();
        Bundle bundle = new Bundle();
        bundle.putString("pkgs", str);
        bundle.putString("leaderAppName", str2);
        fragAppDetail.setArguments(bundle);
        return fragAppDetail;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getPkgs() {
        return getArguments().getString("pkgs");
    }

    private String getLeaderAppName() {
        return getArguments().getString("leaderAppName");
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.ctx = getActivity().getApplicationContext();
        this.adapter = new AdapterAppDetail(getActivity());
        this.adapter.setOnCustomFilterCheckStateChangedListener(this.onCustomFilterCheckStateChanged);
        this.adapter.setOnRuleDeletedListener(this.onRuleDeleted);
        this.filter = Filter.getInstance(getActivity());
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_appdetail, (ViewGroup) null);
        this.viewProgress = viewInflate.findViewById(R.id.progressBar);
        this.viewContent = viewInflate.findViewById(R.id.content);
        this.viewIcon = (ImageView) viewInflate.findViewById(R.id.icon);
        this.viewName = (TextView) viewInflate.findViewById(R.id.name);
        this.viewCheckWifi = (AllowDenyCheckbox) viewInflate.findViewById(R.id.checkWifi);
        this.viewCheckMobile = (AllowDenyCheckbox) viewInflate.findViewById(R.id.checkMobile);
        this.viewTextWifi = (TextView) viewInflate.findViewById(R.id.textWifi);
        this.viewTextMobile = (TextView) viewInflate.findViewById(R.id.textMobile);
        this.viewList = (ListView) viewInflate.findViewById(R.id.list);
        this.viewList.addHeaderView(layoutInflater.inflate(R.layout.listitem_rule_header, (ViewGroup) null, false));
        View viewInflate2 = layoutInflater.inflate(R.layout.listitem_rule_add_custom_filter, (ViewGroup) null, false);
        viewInflate2.setOnClickListener(this.onAddRuleClicked);
        this.viewList.addFooterView(viewInflate2);
        this.viewList.setOnItemClickListener(this.onListItemClicked);
        this.viewList.setChoiceMode(3);
        this.viewList.setMultiChoiceModeListener(new AbsListView.MultiChoiceModeListener() { // from class: app.greyshirts.firewall.ui.FragAppDetail.1
            @Override // android.view.ActionMode.Callback
            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }

            @Override // android.widget.AbsListView.MultiChoiceModeListener
            public void onItemCheckedStateChanged(ActionMode actionMode, int i, long j, boolean z) {
                View childAt = FragAppDetail.this.viewList.getChildAt(i - FragAppDetail.this.viewList.getFirstVisiblePosition());
                if (childAt instanceof ViewCustomFilter) {
                    long j2 = ((ViewCustomFilter) childAt).getModel().filterRuleId;
                    Log.i("NRFW", "id=" + j2);
                    if (z) {
                        FragAppDetail.this.selectedFilterIds.add(Long.valueOf(j2));
                    } else {
                        FragAppDetail.this.selectedFilterIds.remove(Long.valueOf(j2));
                    }
                } else {
                    if (!(childAt instanceof ViewPendingAccess)) {
                        return;
                    }
                    long j3 = ((ViewPendingAccess) childAt).getModel()._id;
                    Log.i("NRFW", "id=" + j3);
                    if (z) {
                        FragAppDetail.this.selectedPendingIds.add(Long.valueOf(j3));
                    } else {
                        FragAppDetail.this.selectedPendingIds.remove(Long.valueOf(j3));
                    }
                }
                FragAppDetail.this.adapter.setSelectedIds(FragAppDetail.this.selectedFilterIds, FragAppDetail.this.selectedFilterIds);
            }

            @Override // android.view.ActionMode.Callback
            public boolean onCreateActionMode(ActionMode actionMode, Menu menu) {
                actionMode.getMenuInflater().inflate(R.menu.frag_app_detail_context, menu);
                FragAppDetail.this.selectedFilterIds.clear();
                FragAppDetail.this.selectedPendingIds.clear();
                return true;
            }

            @Override // android.view.ActionMode.Callback
            public boolean onActionItemClicked(ActionMode actionMode, MenuItem menuItem) {
                return menuItem.getItemId() == R.id.delete;
            }

            @Override // android.view.ActionMode.Callback
            public void onDestroyActionMode(ActionMode actionMode) {
                FragAppDetail.this.selectedFilterIds.clear();
                FragAppDetail.this.selectedPendingIds.clear();
                FragAppDetail.this.adapter.setSelectedIds(FragAppDetail.this.selectedFilterIds, FragAppDetail.this.selectedFilterIds);
            }
        });
        this.viewList.setAdapter((ListAdapter) this.adapter);
        this.viewList.setOnScrollListener(this.onScrollListener);
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.frag_app_detail_debug, menu);
    }

    @Override // androidx.fragment.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.dumpFilter) {
            dumpFilter();
            return true;
        }
        if (itemId == R.id.filterTest) {
            DiagFragFilterTest.newInstance(this.modelGroup.pkgs).show(getFragmentManager(), null);
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void dumpFilter() {
        Cursor cursorQuery = null;
        try {
            cursorQuery = getActivity().getContentResolver().query(FilterRuleContract.getInstance(getActivity()).getContentUri(), null, null, null, null);
            cursorQuery.moveToFirst();
            while (!cursorQuery.isAfterLast()) {
                int columnCount = cursorQuery.getColumnCount();
                for (int i = 0; i < columnCount; i++) {
                    Log.i("NRFW", cursorQuery.getColumnName(i) + ":" + cursorQuery.getString(i));
                }
                Log.i("NRFW", "---------");
                cursorQuery.moveToNext();
            }
        } catch (Exception unused) {
        } finally {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.viewList.setAdapter((ListAdapter) null);
        this.viewList = null;
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        getLoaderManager().initLoader(0, null, this.customFilterLoaderCallbacks);
        getLoaderManager().initLoader(1, null, this.pendingAccessLoaderCallbacks);
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        updateView();
    }

    public void updateView() {
        this.viewProgress.setVisibility(0);
        this.viewContent.setVisibility(8);
        if (this.adapter == null || this.modelGroup == null || !this.pendingAccessLoaded) {
            return;
        }
        this.viewProgress.setVisibility(8);
        this.viewContent.setVisibility(0);
        this.viewCheckWifi.setTag(this.modelGroup);
        this.viewCheckMobile.setTag(this.modelGroup);
        String string = this.ctx.getString(R.string.filter_app_uninstalled);
        ModelGroup modelGroup = this.modelGroup;
        if (modelGroup.install == 1) {
            this.viewName.setText(this.modelGroup.groupName + " " + string);
        } else {
            this.viewName.setText(modelGroup.groupName);
        }
        Drawable icon = AppInfo.getIcon(this.ctx, this.modelGroup.leaderPkgName, true);
        if (icon != null) {
            this.viewIcon.setImageDrawable(icon);
        } else {
            AsyncImageDrawable.loadBitmap(this.viewIcon, null, new AsyncImageDrawable.ImageLoader() { // from class: app.greyshirts.firewall.ui.FragAppDetail.3
                @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                public Drawable loadDrawable(Object obj) {
                    return AppInfo.getIcon(FragAppDetail.this.ctx, (String) obj);
                }

                @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                public boolean isSameTask(Object obj, Object obj2) {
                    return ((String) obj).equals((String) obj2);
                }
            }, this.modelGroup.leaderPkgName);
        }
        AllowDenyCheckbox allowDenyCheckbox = this.viewCheckWifi;
        AllowDenyCheckbox.CheckState checkStatePolicyToCheckState = policyToCheckState(this.modelGroup.policy0);
        ModelGroup modelGroup2 = this.modelGroup;
        allowDenyCheckbox.bindData(checkStatePolicyToCheckState, modelGroup2.hasAllow0, modelGroup2.hasDeny0);
        AllowDenyCheckbox allowDenyCheckbox2 = this.viewCheckMobile;
        AllowDenyCheckbox.CheckState checkStatePolicyToCheckState2 = policyToCheckState(this.modelGroup.policy1);
        ModelGroup modelGroup3 = this.modelGroup;
        allowDenyCheckbox2.bindData(checkStatePolicyToCheckState2, modelGroup3.hasAllow1, modelGroup3.hasDeny1);
        updatePolicyText(this.viewTextWifi, this.viewCheckWifi);
        updatePolicyText(this.viewTextMobile, this.viewCheckMobile);
        this.viewCheckWifi.setOnCheckStateChangedListener(this.onWifiPolicyChecked);
        this.viewCheckMobile.setOnCheckStateChangedListener(this.onMobilePolicyChecked);
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.FragAppDetail$12, reason: invalid class name */
    static /* synthetic */ class AnonymousClass12 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState = new int[AllowDenyCheckbox.CheckState.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.ALLOW.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.DENY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    private void updatePolicyText(TextView textView, AllowDenyCheckbox allowDenyCheckbox) {
        int i = AnonymousClass12.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[allowDenyCheckbox.getCheckState().ordinal()];
        if (i == 1) {
            textView.setText(getString(R.string.filter_allow_any));
            return;
        }
        if (i == 2) {
            textView.setText(getString(R.string.filter_deny_any));
            return;
        }
        if (i != 3) {
            return;
        }
        if (!allowDenyCheckbox.hasCustomAllow() && !allowDenyCheckbox.hasCustomDeny()) {
            textView.setText(getString(R.string.filter_custom_no_filter));
            return;
        }
        if (allowDenyCheckbox.hasCustomAllow() && allowDenyCheckbox.hasCustomDeny()) {
            textView.setText(getString(R.string.filter_custom_has_allow_and_deny));
        } else if (allowDenyCheckbox.hasCustomAllow()) {
            textView.setText(getString(R.string.filter_custom_has_allow));
        } else {
            textView.setText(getString(R.string.filter_custom_has_deny));
        }
    }

    private AllowDenyCheckbox.CheckState policyToCheckState(int i) {
        if (i == 0) {
            return AllowDenyCheckbox.CheckState.CUSTOM;
        }
        if (i == 1) {
            return AllowDenyCheckbox.CheckState.ALLOW;
        }
        if (i == 2) {
            return AllowDenyCheckbox.CheckState.DENY;
        }
        throw new RuntimeException("unknown policy");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public ModelGroup loadModelGroup(Bundle bundle) {
        String string = bundle.getString("groupName");
        String string2 = bundle.getString("leaderPkgName");
        String string3 = bundle.getString("sqrIn");
        int i = bundle.getInt("install");
        boolean z = bundle.getInt("hasAllow0") != 0;
        boolean z2 = bundle.getInt("hasDeny0") != 0;
        int i2 = bundle.getInt("policy0");
        boolean z3 = bundle.getInt("hasAllow1") != 0;
        boolean z4 = bundle.getInt("hasDeny1") != 0;
        int i3 = bundle.getInt("policy1");
        String string4 = bundle.getString("leaderAppName");
        if (string3 != null) {
            return new ModelGroup(string, string4, PackageNames.newInstanceFromCommaList(string3), string2, i, z, z2, i2, z3, z4, i3);
        }
        PackageNames packageNamesNewInstanceFromCommaList = PackageNames.newInstanceFromCommaList(getPkgs());
        return new ModelGroup(getLeaderAppName(), getLeaderAppName(), packageNamesNewInstanceFromCommaList, packageNamesNewInstanceFromCommaList.getAt(0), 1, false, false, 0, false, false, 0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void changePolicy(Filter.Profile profile, ModelGroup modelGroup, AllowDenyCheckbox.CheckState checkState) {
        Filter.Type type;
        int i = AnonymousClass12.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[checkState.ordinal()];
        if (i == 1) {
            type = Filter.Type.POLICY_ALLOW;
        } else if (i == 2) {
            type = Filter.Type.POLICY_DENY;
        } else {
            type = Filter.Type.POLICY_CUSTOM;
        }
        this.filter.setPolicyRule(profile, modelGroup.leaderAppName, modelGroup.pkgs, type);
        MyVpnService.notifyBlockingRuleChange(getActivity());
    }
}
