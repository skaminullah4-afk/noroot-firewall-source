package app.greyshirts.firewall.ui;

import android.content.Context;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CursorAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.AppInfo;
import app.greyshirts.firewall.app.AsyncImageDrawable;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;

/* JADX INFO: loaded from: classes.dex */
class AdapterAllApps extends CursorAdapter {
    private int colGroupName;
    private int colInstall;
    private int colLeaderAppName;
    private int colLeaderPkgName;
    private int colPkgList;
    private int colProfile0HasAllow;
    private int colProfile0HasDeny;
    private int colProfile0Policy;
    private int colProfile1HasAllow;
    private int colProfile1HasDeny;
    private int colProfile1Policy;
    private final LayoutInflater inflater;
    private final AllowDenyCheckbox.OnCheckStateChanged mobileCheckStateChanged;
    private final View.OnClickListener onGroupClicked;
    private OnGroupClickedListener onGroupClickedListener;
    private OnPolicyClickedListener onPolicyClickedListener;
    private final String uninstalledAppString;
    private final AllowDenyCheckbox.OnCheckStateChanged wifiCheckStateChanged;

    public interface OnGroupClickedListener {
        void onGroupClicked(ModelGroup modelGroup);
    }

    public interface OnPolicyClickedListener {
        void onPolicyClicked(Filter.Profile profile, ModelGroup modelGroup, AllowDenyCheckbox.CheckState checkState);
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int i) {
        return true;
    }

    public AdapterAllApps(Context context) {
        super(context, (Cursor) null, 0);
        this.onGroupClicked = new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterAllApps.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (AdapterAllApps.this.onGroupClickedListener == null) {
                    return;
                }
                AdapterAllApps.this.onGroupClickedListener.onGroupClicked(((GroupTag) view.getTag()).modelGroup);
            }
        };
        this.wifiCheckStateChanged = new AllowDenyCheckbox.OnCheckStateChanged() { // from class: app.greyshirts.firewall.ui.AdapterAllApps.3
            @Override // app.greyshirts.firewall.ui.widget.AllowDenyCheckbox.OnCheckStateChanged
            public void onCheckStateChanged(AllowDenyCheckbox allowDenyCheckbox, AllowDenyCheckbox.CheckState checkState) {
                if (AdapterAllApps.this.onPolicyClickedListener == null) {
                    return;
                }
                AdapterAllApps.this.onPolicyClickedListener.onPolicyClicked(Filter.Profile.PROFILE_WIFI, (ModelGroup) allowDenyCheckbox.getTag(), checkState);
            }
        };
        this.mobileCheckStateChanged = new AllowDenyCheckbox.OnCheckStateChanged() { // from class: app.greyshirts.firewall.ui.AdapterAllApps.4
            @Override // app.greyshirts.firewall.ui.widget.AllowDenyCheckbox.OnCheckStateChanged
            public void onCheckStateChanged(AllowDenyCheckbox allowDenyCheckbox, AllowDenyCheckbox.CheckState checkState) {
                if (AdapterAllApps.this.onPolicyClickedListener == null) {
                    return;
                }
                AdapterAllApps.this.onPolicyClickedListener.onPolicyClicked(Filter.Profile.PROFILE_MOBILE, (ModelGroup) allowDenyCheckbox.getTag(), checkState);
            }
        };
        this.inflater = LayoutInflater.from(context);
        this.uninstalledAppString = context.getString(R.string.filter_app_uninstalled);
    }

    public void setOnGroupClickedListener(OnGroupClickedListener onGroupClickedListener) {
        this.onGroupClickedListener = onGroupClickedListener;
    }

    public void setOnPolicyClickedListener(OnPolicyClickedListener onPolicyClickedListener) {
        this.onPolicyClickedListener = onPolicyClickedListener;
    }

    @Override // android.widget.CursorAdapter
    public Cursor swapCursor(Cursor cursor) {
        if (cursor != null) {
            this.colGroupName = cursor.getColumnIndexOrThrow("groupName");
            this.colLeaderPkgName = cursor.getColumnIndexOrThrow("leaderPkgName");
            this.colInstall = cursor.getColumnIndexOrThrow("install");
            this.colLeaderAppName = cursor.getColumnIndexOrThrow("leaderAppName");
            this.colPkgList = cursor.getColumnIndexOrThrow("sqrIn");
            this.colProfile0HasAllow = cursor.getColumnIndexOrThrow("hasAllow0");
            this.colProfile0HasDeny = cursor.getColumnIndexOrThrow("hasDeny0");
            this.colProfile0Policy = cursor.getColumnIndexOrThrow("policy0");
            this.colProfile1HasAllow = cursor.getColumnIndexOrThrow("hasAllow1");
            this.colProfile1HasDeny = cursor.getColumnIndexOrThrow("hasDeny1");
            this.colProfile1Policy = cursor.getColumnIndexOrThrow("policy1");
        }
        return super.swapCursor(cursor);
    }

    @Override // android.widget.CursorAdapter
    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
        View viewInflate = this.inflater.inflate(R.layout.listitem_rule_group, (ViewGroup) null);
        GroupTag groupTag = new GroupTag(viewInflate);
        viewInflate.setTag(groupTag);
        viewInflate.setOnClickListener(this.onGroupClicked);
        groupTag.viewWifi.setOnCheckStateChangedListener(this.wifiCheckStateChanged);
        groupTag.viewMobile.setOnCheckStateChangedListener(this.mobileCheckStateChanged);
        return viewInflate;
    }

    /* JADX WARN: Code duplicated, block: B:43:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:47:0x00d5 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:48:0x00d7  */
    /* JADX WARN: Code duplicated, block: B:49:0x00e1  */
    /* JADX WARN: Code duplicated, block: B:50:0x00eb A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:51:0x00ed A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:52:0x00ef  */
    /* JADX WARN: Code duplicated, block: B:53:0x00f9  */
    /* JADX WARN: Code duplicated, block: B:54:0x0103  */
    /* JADX WARN: Code duplicated, block: B:57:0x0115  */
    /* JADX WARN: Code duplicated, block: B:58:0x011e  */
    /* JADX WARN: Code duplicated, block: B:61:0x0130  */
    /* JADX WARN: Code duplicated, block: B:62:0x014e  */
    /* JADX WARN: Instruction removed from duplicated block: B:61:0x0130, please report this as an issue */
    @Override // android.widget.CursorAdapter
    public void bindView(View view, final Context context, Cursor cursor) {
        boolean z;
        int i;
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        Drawable icon;
        int i2;
        AdapterAllApps adapterAllApps;
        GroupTag groupTag = (GroupTag) view.getTag();
        String string = cursor.getString(this.colGroupName);
        String string2 = cursor.getString(this.colLeaderPkgName);
        int i3 = cursor.getInt(this.colInstall);
        String string3 = cursor.getString(this.colLeaderAppName);
        int i4 = cursor.getInt(this.colProfile0Policy);
        boolean z6 = cursor.getInt(this.colProfile0HasAllow) != 0;
        boolean z7 = cursor.getInt(this.colProfile0HasDeny) != 0;
        int i5 = cursor.getInt(this.colProfile1Policy);
        boolean z8 = cursor.getInt(this.colProfile1HasAllow) != 0;
        boolean z9 = cursor.getInt(this.colProfile1HasDeny) != 0;
        PackageNames packageNamesNewInstanceFromCommaList = PackageNames.newInstanceFromCommaList(cursor.getString(this.colPkgList));
        boolean z10 = z9;
        boolean z11 = z8;
        boolean z12 = z7;
        boolean z13 = z6;
        ModelGroup modelGroup = new ModelGroup(string, string3, packageNamesNewInstanceFromCommaList, string2, i3, z13, z12, i4, z11, z10, i5);
        groupTag.modelGroup = modelGroup;
        groupTag.viewWifi.setTag(modelGroup);
        groupTag.viewMobile.setTag(modelGroup);
        if (i4 != 1) {
            z2 = z13;
            if (i4 != 0 || !z2) {
                i = i5;
                z = z11;
                if (i != 1 && (i != 0 || !z)) {
                    z3 = false;
                }
                if (i4 == 2 && ((i4 != 0 || !z12) && i != 2)) {
                    z4 = z10;
                    z5 = i == 0 && z4;
                    if (z3) {
                        if (!z5) {
                            groupTag.viewBackground.getBackground().setLevel(1);
                        } else {
                            groupTag.viewBackground.getBackground().setLevel(3);
                        }
                    } else if (!z5) {
                        groupTag.viewBackground.getBackground().setLevel(0);
                    } else if (!z3) {
                        groupTag.viewBackground.getBackground().setLevel(2);
                    } else {
                        groupTag.viewBackground.getBackground().setLevel(3);
                    }
                    icon = AppInfo.getIcon(context, string2, true);
                    if (icon != null) {
                        groupTag.viewIcon.setImageDrawable(icon);
                        i2 = 1;
                        adapterAllApps = this;
                    } else {
                        i2 = 1;
                        adapterAllApps = this;
                        AsyncImageDrawable.loadBitmap(groupTag.viewIcon, null, new AsyncImageDrawable.ImageLoader(adapterAllApps) { // from class: app.greyshirts.firewall.ui.AdapterAllApps.1
                            @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                            public Drawable loadDrawable(Object obj) {
                                return AppInfo.getIcon(context, (String) obj);
                            }

                            @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                            public boolean isSameTask(Object obj, Object obj2) {
                                return ((String) obj).equals((String) obj2);
                            }
                        }, string2);
                    }
                    if (i3 == i2) {
                        groupTag.viewName.setText(string + " " + adapterAllApps.uninstalledAppString);
                    } else {
                        groupTag.viewName.setText(string);
                    }
                    groupTag.viewWifi.bindData(adapterAllApps.policyToCheckState(i4), z2, z12);
                    groupTag.viewMobile.bindData(adapterAllApps.policyToCheckState(i), z, z4);
                }
                z4 = z10;
                if (z3) {
                    if (!z5) {
                        groupTag.viewBackground.getBackground().setLevel(1);
                    } else {
                        groupTag.viewBackground.getBackground().setLevel(3);
                    }
                } else if (!z5) {
                    groupTag.viewBackground.getBackground().setLevel(0);
                } else if (!z3) {
                    groupTag.viewBackground.getBackground().setLevel(2);
                } else {
                    groupTag.viewBackground.getBackground().setLevel(3);
                }
                icon = AppInfo.getIcon(context, string2, true);
                if (icon != null) {
                    groupTag.viewIcon.setImageDrawable(icon);
                    i2 = 1;
                    adapterAllApps = this;
                } else {
                    i2 = 1;
                    adapterAllApps = this;
                    AsyncImageDrawable.loadBitmap(groupTag.viewIcon, null, new AsyncImageDrawable.ImageLoader(adapterAllApps) { // from class: app.greyshirts.firewall.ui.AdapterAllApps.1
                        @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                        public Drawable loadDrawable(Object obj) {
                            return AppInfo.getIcon(context, (String) obj);
                        }

                        @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                        public boolean isSameTask(Object obj, Object obj2) {
                            return ((String) obj).equals((String) obj2);
                        }
                    }, string2);
                }
                if (i3 == i2) {
                    groupTag.viewName.setText(string + " " + adapterAllApps.uninstalledAppString);
                } else {
                    groupTag.viewName.setText(string);
                }
                groupTag.viewWifi.bindData(adapterAllApps.policyToCheckState(i4), z2, z12);
                groupTag.viewMobile.bindData(adapterAllApps.policyToCheckState(i), z, z4);
            }
            z = z11;
            i = i5;
        } else {
            z = z11;
            i = i5;
            z2 = z13;
        }
        z3 = true;
        if (i4 == 2) {
            z4 = z10;
        } else {
            z4 = z10;
        }
        if (z3) {
            if (!z5) {
                groupTag.viewBackground.getBackground().setLevel(1);
            } else {
                groupTag.viewBackground.getBackground().setLevel(3);
            }
        } else if (!z5) {
            groupTag.viewBackground.getBackground().setLevel(0);
        } else if (!z3) {
            groupTag.viewBackground.getBackground().setLevel(2);
        } else {
            groupTag.viewBackground.getBackground().setLevel(3);
        }
        icon = AppInfo.getIcon(context, string2, true);
        if (icon != null) {
            groupTag.viewIcon.setImageDrawable(icon);
            i2 = 1;
            adapterAllApps = this;
        } else {
            i2 = 1;
            adapterAllApps = this;
            AsyncImageDrawable.loadBitmap(groupTag.viewIcon, null, new AsyncImageDrawable.ImageLoader(adapterAllApps) { // from class: app.greyshirts.firewall.ui.AdapterAllApps.1
                @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                public Drawable loadDrawable(Object obj) {
                    return AppInfo.getIcon(context, (String) obj);
                }

                @Override // app.greyshirts.firewall.app.AsyncImageDrawable.ImageLoader
                public boolean isSameTask(Object obj, Object obj2) {
                    return ((String) obj).equals((String) obj2);
                }
            }, string2);
        }
        if (i3 == i2) {
            groupTag.viewName.setText(string + " " + adapterAllApps.uninstalledAppString);
        } else {
            groupTag.viewName.setText(string);
        }
        groupTag.viewWifi.bindData(adapterAllApps.policyToCheckState(i4), z2, z12);
        groupTag.viewMobile.bindData(adapterAllApps.policyToCheckState(i), z, z4);
    }

    private AllowDenyCheckbox.CheckState policyToCheckState(int i) {
        if (i == 0) {
            return AllowDenyCheckbox.CheckState.CUSTOM;
        }
        if (i == 1) {
            return AllowDenyCheckbox.CheckState.ALLOW;
        }
        if (i == 2) {
            return AllowDenyCheckbox.CheckState.DENY;
        }
        throw new RuntimeException("unknown policy");
    }

    static class GroupTag {
        ModelGroup modelGroup;
        final View viewBackground;
        final ImageView viewIcon;
        final AllowDenyCheckbox viewMobile;
        final TextView viewName;
        final AllowDenyCheckbox viewWifi;

        public GroupTag(View view) {
            this.viewBackground = view.findViewById(R.id.background);
            this.viewIcon = (ImageView) view.findViewById(R.id.icon);
            this.viewWifi = (AllowDenyCheckbox) view.findViewById(R.id.checkWifi);
            this.viewMobile = (AllowDenyCheckbox) view.findViewById(R.id.checkMobile);
            this.viewName = (TextView) view.findViewById(R.id.name);
        }
    }
}
