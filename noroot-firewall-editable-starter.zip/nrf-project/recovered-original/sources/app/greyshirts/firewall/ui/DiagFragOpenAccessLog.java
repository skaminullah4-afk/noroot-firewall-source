package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.log.AccessLogEntry;

/* JADX INFO: loaded from: classes.dex */
public class DiagFragOpenAccessLog extends DialogFragment {
    AccessLogEntry log;

    public static DiagFragOpenAccessLog newInstance(AccessLogEntry accessLogEntry) {
        DiagFragOpenAccessLog diagFragOpenAccessLog = new DiagFragOpenAccessLog();
        diagFragOpenAccessLog.log = accessLogEntry;
        return diagFragOpenAccessLog;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        String[] strArr = {getString(R.string.access_log_submenu_open_app_detail), getString(R.string.access_log_submenu_open_create_filter)};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        AccessLogEntry accessLogEntry = this.log;
        if (accessLogEntry != null) {
            builder.setTitle(accessLogEntry.getLeaderAppName());
            builder.setItems(strArr, new DialogInterface.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragOpenAccessLog.1
                @Override // android.content.DialogInterface.OnClickListener
                public void onClick(DialogInterface dialogInterface, int i) {
                    if (i == 0) {
                        Intent intent = new Intent(DiagFragOpenAccessLog.this.getActivity(), (Class<?>) ActivityAppDetail.class);
                        intent.putExtra("extra.pkgs", DiagFragOpenAccessLog.this.log.getPkgs().getCommaJoinedString());
                        intent.putExtra("extra.leaderName", DiagFragOpenAccessLog.this.log.getLeaderAppName());
                        DiagFragOpenAccessLog.this.startActivity(intent);
                        return;
                    }
                    DiagFragFilterEdit.newInstanceNewAppCustomFilter(DiagFragOpenAccessLog.this.log).show(DiagFragOpenAccessLog.this.getFragmentManager(), null);
                }
            });
        }
        return builder.create();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        if (this.log == null) {
            dismiss();
        }
    }
}
