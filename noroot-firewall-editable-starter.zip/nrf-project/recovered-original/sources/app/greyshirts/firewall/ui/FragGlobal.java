package app.greyshirts.firewall.ui;

import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.MyVpnService;
import app.greyshirts.firewall.db.FilterRuleContract;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;

/* JADX INFO: loaded from: classes.dex */
public class FragGlobal extends Fragment implements View.OnClickListener {
    private AdapterGlobal adapter;
    private Filter filter;
    private View viewContent;
    private ListView viewList;
    private View viewProgress;
    private final LoaderManager.LoaderCallbacks<Cursor> customFilterLoaderCallbacks = new LoaderManager.LoaderCallbacks<Cursor>() { // from class: app.greyshirts.firewall.ui.FragGlobal.1
        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
            return new CursorLoader(FragGlobal.this.getActivity(), FilterRuleContract.getInstance(FragGlobal.this.getActivity()).getContentUriOnlyGlobal(), null, null, null, null);
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
            FragGlobal.this.adapter.changeCursor(cursor);
            FragGlobal.this.updateView();
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoaderReset(Loader<Cursor> loader) {
            FragGlobal.this.adapter.changeCursor(null);
            FragGlobal.this.updateView();
        }
    };
    private final AdapterGlobal.AdapterGlobalListener adapterGlobalListener = new AdapterGlobal.AdapterGlobalListener() { // from class: app.greyshirts.firewall.ui.FragGlobal.2
        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onPreFilterClicked(ModelCustomFilter modelCustomFilter) {
            DiagFragFilterEdit.newInstanceModifyPreFilter(modelCustomFilter).show(FragGlobal.this.getFragmentManager(), null);
        }

        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onPostFilterClicked(ModelCustomFilter modelCustomFilter) {
            DiagFragFilterEdit.newInstanceModifyPostFilter(modelCustomFilter).show(FragGlobal.this.getFragmentManager(), null);
        }

        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onPreFilterChanged(long j, Filter.Profile profile, AllowDenyCheckbox.CheckState checkState) {
            int i = AnonymousClass3.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[checkState.ordinal()];
            int i2 = 2;
            if (i == 1) {
                i2 = 1;
            } else if (i != 2) {
                i2 = 0;
            }
            FragGlobal.this.filter.updateCustomFilter(j, profile, i2);
            MyVpnService.notifyBlockingRuleChange(FragGlobal.this.getActivity());
        }

        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onPostFilterChanged(long j, Filter.Profile profile, AllowDenyCheckbox.CheckState checkState) {
            int i = AnonymousClass3.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[checkState.ordinal()];
            int i2 = 2;
            if (i == 1) {
                i2 = 1;
            } else if (i != 2) {
                i2 = 0;
            }
            FragGlobal.this.filter.updateCustomFilter(j, profile, i2);
            MyVpnService.notifyBlockingRuleChange(FragGlobal.this.getActivity());
        }

        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onPreFilterDeleted() {
            MyVpnService.notifyBlockingRuleChange(FragGlobal.this.getActivity());
        }

        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onPostFilterDeleted() {
            MyVpnService.notifyBlockingRuleChange(FragGlobal.this.getActivity());
        }

        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onNewPreFilterClicked() {
            DiagFragFilterEdit.newInstanceNewPreFilter().show(FragGlobal.this.getFragmentManager(), null);
        }

        @Override // app.greyshirts.firewall.ui.AdapterGlobal.AdapterGlobalListener
        public void onNewPostFilterClicked() {
            DiagFragFilterEdit.newInstanceNewPostFilter().show(FragGlobal.this.getFragmentManager(), null);
        }
    };

    public static FragGlobal newInstance() {
        FragGlobal fragGlobal = new FragGlobal();
        fragGlobal.setArguments(new Bundle());
        return fragGlobal;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.adapter = new AdapterGlobal(getActivity());
        this.adapter.setListener(this.adapterGlobalListener);
        this.filter = Filter.getInstance(getActivity());
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_global, (ViewGroup) null);
        this.viewProgress = viewInflate.findViewById(R.id.progressBar);
        this.viewContent = viewInflate.findViewById(R.id.content);
        this.viewList = (ListView) viewInflate.findViewById(R.id.list);
        viewInflate.findViewById(R.id.buttonHelp).setOnClickListener(this);
        ImageView imageView = (ImageView) viewInflate.findViewById(R.id.icon);
        ((TextView) viewInflate.findViewById(R.id.name)).setText(getString(R.string.global_filters));
        imageView.setImageResource(R.drawable.global);
        this.viewList.setAdapter((ListAdapter) this.adapter);
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.frag_app_detail_debug, menu);
    }

    @Override // androidx.fragment.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.dumpFilter) {
            dumpFilter();
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void dumpFilter() {
        Cursor cursorQuery = null;
        try {
            cursorQuery = getActivity().getContentResolver().query(FilterRuleContract.getInstance(getActivity()).getContentUri(), null, null, null, null);
            cursorQuery.moveToFirst();
            while (!cursorQuery.isAfterLast()) {
                int columnCount = cursorQuery.getColumnCount();
                for (int i = 0; i < columnCount; i++) {
                    Log.i("NRFW", cursorQuery.getColumnName(i) + ":" + cursorQuery.getString(i));
                }
                Log.i("NRFW", "---------");
                cursorQuery.moveToNext();
            }
        } catch (Exception unused) {
        } finally {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.viewList.setAdapter((ListAdapter) null);
        this.viewList = null;
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        getLoaderManager().initLoader(0, null, this.customFilterLoaderCallbacks);
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        updateView();
    }

    public void updateView() {
        this.viewProgress.setVisibility(0);
        this.viewContent.setVisibility(8);
        if (this.adapter == null) {
            return;
        }
        this.viewProgress.setVisibility(8);
        this.viewContent.setVisibility(0);
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.FragGlobal$3, reason: invalid class name */
    static /* synthetic */ class AnonymousClass3 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState = new int[AllowDenyCheckbox.CheckState.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.ALLOW.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.DENY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        if (view.getId() != R.id.buttonHelp) {
            return;
        }
        new DialogGlobalHelp().show(getFragmentManager(), null);
    }
}
