package app.greyshirts.firewall.ui;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.cache.AddressCache;
import app.greyshirts.firewall.cache.DnsCache;
import java.text.SimpleDateFormat;
import java.util.Date;

/* JADX INFO: loaded from: classes.dex */
public class ViewPendingAccess extends LinearLayout {
    private Listener listener;
    private ModelPendingAccess model;
    private final SimpleDateFormat sdf;
    private View viewDelete;
    private TextView viewHostName;
    private TextView viewServerIp;
    private TextView viewTime;

    public interface Listener {
        void onDeleteClicked(ModelPendingAccess modelPendingAccess);
    }

    public ViewPendingAccess(Context context) {
        super(context);
        this.sdf = new SimpleDateFormat("MM-dd HH:mm");
    }

    public ViewPendingAccess(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.sdf = new SimpleDateFormat("MM-dd HH:mm");
    }

    public ViewPendingAccess(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.sdf = new SimpleDateFormat("MM-dd HH:mm");
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        this.viewServerIp = (TextView) findViewById(R.id.ip);
        this.viewHostName = (TextView) findViewById(R.id.hostName);
        this.viewTime = (TextView) findViewById(R.id.time);
        this.viewDelete = findViewById(R.id.delete);
        this.viewDelete.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.ViewPendingAccess.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (ViewPendingAccess.this.listener != null) {
                    ViewPendingAccess.this.listener.onDeleteClicked(ViewPendingAccess.this.model);
                }
            }
        });
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void bindModel(ModelPendingAccess modelPendingAccess) {
        String str;
        this.model = modelPendingAccess;
        TextView textView = this.viewServerIp;
        ModelPendingAccess modelPendingAccess2 = this.model;
        textView.setText(String.format("%s:%d", modelPendingAccess2.serverIp, Integer.valueOf(modelPendingAccess2.serverPort)));
        this.viewTime.setText(this.sdf.format(new Date(this.model.time)));
        if (TextUtils.isEmpty(this.model.serverHost)) {
            AddressCache.AddressCacheEntry addressCacheEntryResolveNameFromIpForUiThread = DnsCache.getInstance().resolveNameFromIpForUiThread(this.model.serverIp, new DnsCache.ResolveNameResult() { // from class: app.greyshirts.firewall.ui.ViewPendingAccess.2
                @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
                public void onFinish(String str2, String str3) {
                    if (!ViewPendingAccess.this.model.serverIp.equals(str2) || TextUtils.isEmpty(str3)) {
                        return;
                    }
                    ViewPendingAccess.this.viewHostName.setText(str3);
                    Filter.getInstance(ViewPendingAccess.this.viewHostName.getContext()).setPendingServerHost(ViewPendingAccess.this.model._id, str3);
                }
            });
            if (addressCacheEntryResolveNameFromIpForUiThread == null || TextUtils.isEmpty(addressCacheEntryResolveNameFromIpForUiThread.hostname)) {
                str = null;
            } else {
                str = addressCacheEntryResolveNameFromIpForUiThread.hostname;
                Filter.getInstance(this.viewHostName.getContext()).setPendingServerHost(this.model._id, str);
            }
        } else {
            str = this.model.serverHost;
        }
        this.viewHostName.setText(str);
    }

    public ModelPendingAccess getModel() {
        return this.model;
    }
}
