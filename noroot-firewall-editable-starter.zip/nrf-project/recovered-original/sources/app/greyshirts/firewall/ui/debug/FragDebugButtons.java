package app.greyshirts.firewall.ui.debug;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.cache.DnsCache;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.nio.channels.DatagramChannel;

/* JADX INFO: loaded from: classes.dex */
public class FragDebugButtons extends Fragment implements View.OnClickListener {
    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_debug_buttons, (ViewGroup) null);
        viewInflate.findViewById(R.id.buttonNormalHttpGet).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonShutdownByServer).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonClosedByServer).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonPortClosed).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonServerNotExist).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonDownloadBig).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonUploadBig).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonDownloadSmallNotKeepalive).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonDownloadSmallKeepalive).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonGoogle).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonYahoo).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonUDP).setOnClickListener(this);
        viewInflate.findViewById(R.id.buttonUDPRecv).setOnClickListener(this);
        viewInflate.findViewById(R.id.dnsButton).setOnClickListener(this);
        viewInflate.findViewById(R.id.addFilterRules).setOnClickListener(this);
        viewInflate.findViewById(R.id.queryFilter).setOnClickListener(this);
        return viewInflate;
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) throws Throwable {
        int id = view.getId();
        if (id == R.id.buttonNormalHttpGet) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Log.i("HTTP", "connecting to http://192.168.1.216:8000/");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://192.168.1.216:8000/").openConnection();
                        httpURLConnection.connect();
                        Log.i("HTTP", "connected");
                        InputStream inputStream = httpURLConnection.getInputStream();
                        byte[] bArr = new byte[8192];
                        while (true) {
                            int i = inputStream.read(bArr);
                            if (i != -1) {
                                byte[] bArr2 = new byte[i];
                                System.arraycopy(bArr, 0, bArr2, 0, i);
                                Log.i("HTTP", "body:" + new String(bArr2));
                            } else {
                                httpURLConnection.disconnect();
                                return;
                            }
                        }
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.i("HTTP", "err " + e.toString());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        Log.i("HTTP", "err " + e2.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonShutdownByServer) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.2
                @Override // java.lang.Runnable
                public void run() {
                    int i;
                    try {
                        Log.i("SOCK", "connecting to 192.168.1.216");
                        Socket socket = new Socket();
                        socket.connect(new InetSocketAddress("192.168.1.216", 8001));
                        InputStream inputStream = socket.getInputStream();
                        byte[] bArr = new byte[8192];
                        while (true) {
                            i = inputStream.read(bArr);
                            if (i == -1) {
                                break;
                            } else {
                                Log.i("SOCK", String.format("received %d bytes", Integer.valueOf(i)));
                            }
                        }
                        Log.i("SOCK", String.format("received %d bytes", Integer.valueOf(i)));
                        try {
                            Thread.sleep(5000L);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        socket.getOutputStream().write("hello back to you".getBytes());
                        try {
                            Thread.sleep(5000L);
                        } catch (InterruptedException e2) {
                            Log.i("SOCK", "caught exception. " + e2);
                        }
                        inputStream.close();
                    } catch (IOException e3) {
                        e3.printStackTrace();
                        Log.i("SOCK", "err " + e3.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonClosedByServer) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.3
                @Override // java.lang.Runnable
                public void run() {
                    int i;
                    InputStream inputStream = null;
                    try {
                        Log.i("SOCK", "connecting to 192.168.1.216");
                        Socket socket = new Socket();
                        socket.connect(new InetSocketAddress("192.168.1.216", 8002));
                        inputStream = socket.getInputStream();
                        byte[] bArr = new byte[8192];
                        while (true) {
                            i = inputStream.read(bArr);
                            if (i == -1) {
                                break;
                            } else {
                                Log.i("SOCK", String.format("received %d bytes", Integer.valueOf(i)));
                            }
                        }
                        Log.i("SOCK", String.format("received %d bytes", Integer.valueOf(i)));
                        try {
                            Thread.sleep(5000L);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                        OutputStream outputStream = socket.getOutputStream();
                        Log.i("SOCK", "write data1");
                        outputStream.write("hello back to you".getBytes());
                        try {
                            Thread.sleep(5000L);
                        } catch (InterruptedException e2) {
                            e2.printStackTrace();
                        }
                        Log.i("SOCK", "write data2");
                        outputStream.write("hello back to you2".getBytes());
                        try {
                            Thread.sleep(5000L);
                        } catch (InterruptedException e3) {
                            e3.printStackTrace();
                        }
                        Log.i("SOCK", "write data3");
                        outputStream.write("hello back to you3".getBytes());
                        Log.i("SOCK", "XXX cannot reach here");
                    } catch (IOException e4) {
                        e4.printStackTrace();
                        Log.i("SOCK", "err " + e4.toString());
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (Exception unused) {
                            }
                        }
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonPortClosed) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.4
                @Override // java.lang.Runnable
                public void run() {
                    int i;
                    InputStream inputStream = null;
                    try {
                        Log.i("SOCK", "connecting to 192.168.1.216");
                        Socket socket = new Socket();
                        socket.connect(new InetSocketAddress("192.168.1.216", 7999));
                        inputStream = socket.getInputStream();
                        byte[] bArr = new byte[8192];
                        while (true) {
                            i = inputStream.read(bArr);
                            if (i == -1) {
                                break;
                            } else {
                                Log.i("SOCK", String.format("received %d bytes????", Integer.valueOf(i)));
                            }
                        }
                        Log.i("SOCK", String.format("received %d bytes???", Integer.valueOf(i)));
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.i("SOCK", "err " + e.toString());
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException unused) {
                            }
                        }
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonServerNotExist) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.5
                @Override // java.lang.Runnable
                public void run() {
                    int i;
                    InputStream inputStream = null;
                    try {
                        Log.i("SOCK", "connecting to 192.168.1.200");
                        Socket socket = new Socket();
                        socket.connect(new InetSocketAddress("192.168.1.200", 8000));
                        inputStream = socket.getInputStream();
                        byte[] bArr = new byte[8192];
                        while (true) {
                            i = inputStream.read(bArr);
                            if (i == -1) {
                                break;
                            } else {
                                Log.i("SOCK", String.format("received %d bytes????", Integer.valueOf(i)));
                            }
                        }
                        Log.i("SOCK", String.format("received %d bytes???", Integer.valueOf(i)));
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.i("SOCK", "err " + e.toString());
                    } finally {
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException unused) {
                            }
                        }
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonDownloadBig) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.6
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Log.i("HTTP", "connecting to http://192.168.1.216:8000/");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://192.168.1.216:8000/downloadBig").openConnection();
                        httpURLConnection.connect();
                        Log.i("HTTP", "connected");
                        InputStream inputStream = httpURLConnection.getInputStream();
                        byte[] bArr = new byte[1048576];
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        int i = 0;
                        while (true) {
                            int i2 = inputStream.read(bArr);
                            if (i2 == -1) {
                                break;
                            } else {
                                i += i2;
                            }
                        }
                        long jCurrentTimeMillis2 = System.currentTimeMillis();
                        httpURLConnection.disconnect();
                        if (i != 41943040) {
                            Log.i("HTTP", String.format("error!!! download size =%d. but expected %d", Integer.valueOf(i), 41943040));
                        } else {
                            Log.i("HTTP", "download size OK");
                        }
                        Log.i("HTTP", "data check OK");
                        Log.i("HTTP", String.format("thruput %fMbps", Double.valueOf((((3.3554432E8d / (jCurrentTimeMillis2 - jCurrentTimeMillis)) * 1000.0d) / 1024.0d) / 1024.0d)));
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.i("HTTP", "err " + e.toString());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        Log.i("HTTP", "err " + e2.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonUploadBig) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.7
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Log.i("HTTP", "connecting to http://192.168.1.216:8000/");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://192.168.1.216:8000/uploadBig").openConnection();
                        httpURLConnection.setRequestMethod("POST");
                        httpURLConnection.setDoOutput(true);
                        httpURLConnection.setFixedLengthStreamingMode(41943040);
                        Log.i("HTTP", "connected");
                        OutputStream outputStream = httpURLConnection.getOutputStream();
                        long jCurrentTimeMillis = System.currentTimeMillis();
                        byte[] bArr = new byte[1048576];
                        for (int length = 0; length < 41943040; length += bArr.length) {
                            outputStream.write(bArr);
                        }
                        long jCurrentTimeMillis2 = System.currentTimeMillis();
                        httpURLConnection.disconnect();
                        Log.i("HTTP", "data send complete");
                        Log.i("HTTP", String.format("thruput %fMbps", Double.valueOf((((3.3554432E8d / (jCurrentTimeMillis2 - jCurrentTimeMillis)) * 1000.0d) / 1024.0d) / 1024.0d)));
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.i("HTTP", "err " + e.toString());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        Log.i("HTTP", "err " + e2.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonDownloadSmallNotKeepalive) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.8
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Log.i("HTTP", "connecting to http://192.168.1.216:8000/");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://192.168.1.216:8000/downloadSmall").openConnection();
                        httpURLConnection.addRequestProperty("Connection", "close");
                        httpURLConnection.connect();
                        Log.i("HTTP", "connected");
                        InputStream inputStream = httpURLConnection.getInputStream();
                        byte[] bArr = new byte[1048576];
                        int i = 0;
                        while (true) {
                            int i2 = inputStream.read(bArr);
                            if (i2 == -1) {
                                break;
                            } else {
                                i += i2;
                            }
                        }
                        httpURLConnection.disconnect();
                        if (i != 5242880) {
                            Log.i("HTTP", String.format("error!!! download size =%d. but expected %d", Integer.valueOf(i), 5242880));
                        } else {
                            Log.i("HTTP", "download size OK");
                        }
                        Log.i("HTTP", "data check OK");
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.i("HTTP", "err " + e.toString());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        Log.i("HTTP", "err " + e2.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonDownloadSmallKeepalive) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.9
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Log.i("HTTP", "connecting to http://192.168.1.216:8000/");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://192.168.1.216:8000/downloadSmall").openConnection();
                        httpURLConnection.connect();
                        Log.i("HTTP", "connected");
                        InputStream inputStream = httpURLConnection.getInputStream();
                        byte[] bArr = new byte[1048576];
                        int i = 0;
                        while (true) {
                            int i2 = inputStream.read(bArr);
                            if (i2 == -1) {
                                break;
                            } else {
                                i += i2;
                            }
                        }
                        httpURLConnection.disconnect();
                        if (i != 5242880) {
                            Log.i("HTTP", String.format("error!!! download size =%d. but expected %d", Integer.valueOf(i), 5242880));
                        } else {
                            Log.i("HTTP", "download size OK");
                        }
                        Log.i("HTTP", "data check OK");
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.i("HTTP", "err " + e.toString());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        Log.i("HTTP", "err " + e2.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonGoogle) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.10
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Log.i("HTTP", "connecting to www.google.co.jp");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://173.194.38.88").openConnection();
                        httpURLConnection.connect();
                        Log.i("HTTP", "connected");
                        InputStream inputStream = httpURLConnection.getInputStream();
                        byte[] bArr = new byte[8192];
                        while (true) {
                            int i = inputStream.read(bArr);
                            if (i != -1) {
                                byte[] bArr2 = new byte[i];
                                System.arraycopy(bArr, 0, bArr2, 0, i);
                                Log.i("HTTP", "body:" + new String(bArr2));
                            } else {
                                httpURLConnection.disconnect();
                                return;
                            }
                        }
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.i("HTTP", "err " + e.toString());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        Log.i("HTTP", "err " + e2.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonYahoo) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.11
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        Log.i("HTTP", "connecting to yahoo");
                        HttpURLConnection httpURLConnection = (HttpURLConnection) new URL("http://www.yahoo.co.jp").openConnection();
                        httpURLConnection.connect();
                        Log.i("HTTP", "connected");
                        InputStream inputStream = httpURLConnection.getInputStream();
                        byte[] bArr = new byte[8192];
                        while (true) {
                            int i = inputStream.read(bArr);
                            if (i != -1) {
                                byte[] bArr2 = new byte[i];
                                System.arraycopy(bArr, 0, bArr2, 0, i);
                                Log.i("HTTP", "body:" + new String(bArr2));
                            } else {
                                httpURLConnection.disconnect();
                                return;
                            }
                        }
                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.i("HTTP", "err " + e.toString());
                    } catch (IOException e2) {
                        e2.printStackTrace();
                        Log.i("HTTP", "err " + e2.toString());
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonUDP) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.12
                /* JADX WARN: Code duplicated, block: B:18:0x0056  */
                @Override // java.lang.Runnable
                public void run() throws Throwable {
                    DatagramSocket datagramSocket;
                    IOException e;
                    try {
                        Log.i("SOCK", "connecting to 192.168.1.216");
                        datagramSocket = new DatagramSocket();
                        try {
                            try {
                                datagramSocket.connect(new InetSocketAddress("192.168.1.216", 53));
                                datagramSocket.send(new DatagramPacket("hello".getBytes(), 5));
                            } catch (IOException e2) {
                                e = e2;
                                e.printStackTrace();
                                Log.i("SOCK", "err " + e.toString());
                                if (datagramSocket == null) {
                                    return;
                                }
                            }
                        } catch (Throwable th) {
                            th = th;
                            if (datagramSocket != null) {
                                datagramSocket.close();
                            }
                            throw th;
                        }
                    } catch (IOException e3) {
                        datagramSocket = null;
                        e = e3;
                    } catch (Throwable th2) {
                        th = th2;
                        datagramSocket = null;
                        if (datagramSocket != null) {
                            datagramSocket.close();
                        }
                        throw th;
                    }
                    datagramSocket.close();
                }
            }).start();
            return;
        }
        if (id == R.id.buttonUDPRecv) {
            new Thread(new Runnable(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.13
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        new InetSocketAddress(InetAddress.getByAddress(new byte[]{-64, -88, 1, 1}), 80);
                        DatagramChannel datagramChannelOpen = DatagramChannel.open();
                        datagramChannelOpen.socket().bind(null);
                        datagramChannelOpen.configureBlocking(false);
                        datagramChannelOpen.close();
                    } catch (Exception e) {
                        Log.i("TEST", "UDP Recv failed " + e);
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.buttonNotification) {
            return;
        }
        if (id == R.id.dnsButton) {
            new DnsTask().execute(((EditText) getView().findViewById(R.id.dnsText)).getText().toString());
            return;
        }
        if (id == R.id.addFilterRules) {
            new Thread(new Runnable() { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.14
                @Override // java.lang.Runnable
                public void run() {
                    for (int i = 0; i < 500; i++) {
                        Filter.getInstance(FragDebugButtons.this.getActivity()).addCustomFilter(1, 1, "8.8.8.8", 0, 80, "Browser", PackageNames.newInstanceFromCommaList("com.google.android.browser"), 0);
                    }
                }
            }).start();
            return;
        }
        if (id == R.id.queryFilter) {
            long jCurrentTimeMillis = System.currentTimeMillis();
            Filter.getInstance(getActivity()).getRuleForConnection(Filter.Profile.PROFILE_WIFI, new byte[]{8, 8, 8, 8}, 80, PackageNames.newInstanceFromCommaList("com.google.android.browser"));
            long jCurrentTimeMillis2 = System.currentTimeMillis();
            DnsCache.getInstance().startResolver("8.8.8.8", new DnsCache.ResolveNameResult(this) { // from class: app.greyshirts.firewall.ui.debug.FragDebugButtons.15
                @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
                public void onFinish(String str, String str2) {
                }
            });
            Toast.makeText(getActivity(), "" + (jCurrentTimeMillis2 - jCurrentTimeMillis) + "ms", 1).show();
        }
    }

    private class DnsTask extends AsyncTask<String, Void, String> {
        private DnsTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... strArr) {
            String[] strArr2 = new String[1];
            int i = DnsCache.getnameinfo(strArr[0], strArr2);
            if (i == 0) {
                return strArr2[0];
            }
            return "err=" + i;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String str) {
            Toast.makeText(FragDebugButtons.this.getActivity().getApplicationContext(), str, 0).show();
        }
    }

    static {
        System.loadLibrary("core");
    }
}
