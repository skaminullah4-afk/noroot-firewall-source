package app.greyshirts.firewall.ui.debug;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.ViewPager;
import app.greyshirts.firewall.R;

/* JADX INFO: loaded from: classes.dex */
public class ActivityDebug extends AppCompatActivity {
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_debug);
        ((ViewPager) findViewById(R.id.pager)).setAdapter(new FragmentStatePagerAdapter(this, getSupportFragmentManager()) { // from class: app.greyshirts.firewall.ui.debug.ActivityDebug.1
            @Override // androidx.viewpager.widget.PagerAdapter
            public int getCount() {
                return 5;
            }

            @Override // androidx.fragment.app.FragmentStatePagerAdapter
            public Fragment getItem(int i) {
                if (i == 0) {
                    return new FragProxyWorker();
                }
                if (i == 1) {
                    return new FragEvent();
                }
                if (i == 2) {
                    return new FragDebugButtons();
                }
                if (i == 3) {
                    return new FragDebugLog();
                }
                if (i != 4) {
                    return null;
                }
                return new FragDebugCommand();
            }
        });
    }
}
