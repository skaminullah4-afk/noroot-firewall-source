package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.text.Html;
import androidx.appcompat.app.AlertDialog;
import app.greyshirts.firewall.R;

/* JADX INFO: loaded from: classes.dex */
public class DialogHelp {
    public static Dialog createHelpDialog(Context context) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.drawable.launcher);
        builder.setMessage(Html.fromHtml(context.getString(R.string.help_whyvpn)));
        builder.setPositiveButton("OK", (DialogInterface.OnClickListener) null);
        return builder.create();
    }
}
