package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.cache.DnsCache;
import java.net.InetAddress;

/* JADX INFO: loaded from: classes.dex */
public class DiagFragFilterTest extends DialogFragment {
    PackageNames pkgs;
    EditText viewAddress;
    View viewDns;
    View viewMobile;
    EditText viewPort;
    TextView viewResult;
    View viewWifi;

    public static DiagFragFilterTest newInstance(PackageNames packageNames) {
        DiagFragFilterTest diagFragFilterTest = new DiagFragFilterTest();
        diagFragFilterTest.pkgs = packageNames;
        return diagFragFilterTest;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(newView());
        builder.setTitle("Filter Test");
        return builder.create();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        if (this.pkgs == null) {
            dismiss();
        }
    }

    private View newView() {
        View viewInflate = getActivity().getLayoutInflater().inflate(R.layout.diag_filter_test, (ViewGroup) null);
        this.viewAddress = (EditText) viewInflate.findViewById(R.id.address);
        this.viewPort = (EditText) viewInflate.findViewById(R.id.port);
        this.viewWifi = viewInflate.findViewById(R.id.wifi);
        this.viewMobile = viewInflate.findViewById(R.id.mobile);
        this.viewResult = (TextView) viewInflate.findViewById(R.id.result);
        this.viewDns = viewInflate.findViewById(R.id.dns);
        this.viewAddress.setText("");
        this.viewPort.setText("");
        this.viewResult.setText("");
        this.viewWifi.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterTest.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) throws Throwable {
                DiagFragFilterTest.this.checkFilter(Filter.Profile.PROFILE_WIFI);
            }
        });
        this.viewMobile.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterTest.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) throws Throwable {
                DiagFragFilterTest.this.checkFilter(Filter.Profile.PROFILE_MOBILE);
            }
        });
        this.viewDns.setOnClickListener(new AnonymousClass3());
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("pref", 0);
        this.viewAddress.setText(sharedPreferences.getString("filter_test_addr", ""));
        this.viewPort.setText(sharedPreferences.getString("filter_test_port", ""));
        return viewInflate;
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.DiagFragFilterTest$3, reason: invalid class name */
    class AnonymousClass3 implements View.OnClickListener {
        AnonymousClass3() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            DnsCache.getInstance().startResolver(DiagFragFilterTest.this.viewAddress.getText().toString(), new DnsCache.ResolveNameResult() { // from class: app.greyshirts.firewall.ui.DiagFragFilterTest.3.1
                @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
                public void onFinish(String str, final String str2) {
                    DiagFragFilterTest.this.getActivity().runOnUiThread(new Runnable() { // from class: app.greyshirts.firewall.ui.DiagFragFilterTest.3.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            FragmentActivity activity = DiagFragFilterTest.this.getActivity();
                            String str3 = str2;
                            if (str3 == null) {
                                str3 = "failed";
                            }
                            Toast.makeText(activity, str3, 0).show();
                        }
                    });
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void checkFilter(Filter.Profile profile) throws Throwable {
        this.viewResult.setText("");
        try {
            byte[] address = InetAddress.getByName(this.viewAddress.getText().toString()).getAddress();
            if (address == null) {
                Toast.makeText(getActivity(), "address error", 0).show();
                return;
            }
            try {
                int i = AnonymousClass4.$SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.getInstance(getActivity()).getRuleForConnection(profile, address, Integer.parseInt(this.viewPort.getText().toString()), this.pkgs).ordinal()];
                if (i == 1) {
                    this.viewResult.setText("allow");
                } else if (i == 2) {
                    this.viewResult.setText("deny");
                } else if (i == 3) {
                    this.viewResult.setText("pending(no entry)");
                } else if (i == 4) {
                    this.viewResult.setText("pending(duplicate)");
                } else if (i == 5) {
                    this.viewResult.setText("wait dns");
                }
                SharedPreferences.Editor editorEdit = getActivity().getSharedPreferences("pref", 0).edit();
                editorEdit.putString("filter_test_addr", this.viewAddress.getText().toString());
                editorEdit.putString("filter_test_port", this.viewPort.getText().toString());
                editorEdit.commit();
            } catch (Exception unused) {
                Toast.makeText(getActivity(), "port error", 0).show();
            }
        } catch (Exception unused2) {
            Toast.makeText(getActivity(), "address error", 0).show();
        }
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.DiagFragFilterTest$4, reason: invalid class name */
    static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule = new int[Filter.FilterRule.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.SHOULD_ALLOW.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.SHOULD_DENY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.NO_RULE_NO_PENDING_ENTRY.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.NO_RULE_DUPLICATE_PENDING_ENTRY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.WAIT_DNS.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
        }
    }
}
