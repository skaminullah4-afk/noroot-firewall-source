package app.greyshirts.firewall.ui.debug;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.debuglog.PersistentLog;

/* JADX INFO: loaded from: classes.dex */
public class FragDebugLog extends Fragment implements Runnable {
    final Handler handler = new Handler();
    private TextView viewText;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_debug_log, (ViewGroup) null);
        this.viewText = (TextView) viewInflate.findViewById(R.id.text);
        viewInflate.findViewById(R.id.refresh).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugLog.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragDebugLog.this.updateView();
            }
        });
        viewInflate.findViewById(R.id.clear).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugLog.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (FragDebugLog.this.getActivity() == null) {
                    return;
                }
                PersistentLog.getInstance(FragDebugLog.this.getActivity()).clear();
                FragDebugLog.this.updateView();
            }
        });
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        updateView();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateView() {
        if (getActivity() == null) {
            return;
        }
        this.viewText.setText(PersistentLog.getInstance(getActivity()).get());
    }

    @Override // java.lang.Runnable
    public void run() {
        updateView();
        if (isResumed()) {
            this.handler.postDelayed(this, 500L);
        }
    }
}
