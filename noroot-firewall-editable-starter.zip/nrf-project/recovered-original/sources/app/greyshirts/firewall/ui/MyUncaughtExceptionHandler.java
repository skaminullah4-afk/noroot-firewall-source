package app.greyshirts.firewall.ui;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import java.io.PrintWriter;
import java.io.StringWriter;

/* JADX INFO: loaded from: classes.dex */
public class MyUncaughtExceptionHandler implements Thread.UncaughtExceptionHandler {
    private Context ctx;
    private Thread.UncaughtExceptionHandler defaultHandler = Thread.getDefaultUncaughtExceptionHandler();

    public static boolean isSet() {
        return Thread.getDefaultUncaughtExceptionHandler() instanceof MyUncaughtExceptionHandler;
    }

    public MyUncaughtExceptionHandler(Context context) {
        this.ctx = context;
    }

    @Override // java.lang.Thread.UncaughtExceptionHandler
    public void uncaughtException(Thread thread, Throwable th) {
        StringWriter stringWriter = new StringWriter();
        th.printStackTrace(new PrintWriter(stringWriter));
        String string = stringWriter.toString();
        SharedPreferences.Editor editorEdit = this.ctx.getSharedPreferences("pref", 0).edit();
        editorEdit.putString("log", string);
        editorEdit.commit();
        this.defaultHandler.uncaughtException(thread, th);
    }

    static String peekLastErrorLog(Context context) {
        String string = context.getSharedPreferences("pref", 0).getString("log", null);
        if (TextUtils.isEmpty(string)) {
            return null;
        }
        return string;
    }

    static String getAndClearLastErrorLog(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences("pref", 0);
        String string = sharedPreferences.getString("log", null);
        if (TextUtils.isEmpty(string)) {
            return null;
        }
        SharedPreferences.Editor editorEdit = sharedPreferences.edit();
        editorEdit.putString("log", null);
        editorEdit.commit();
        return string;
    }
}
