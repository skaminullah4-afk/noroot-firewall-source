package app.greyshirts.firewall.ui;

import android.content.Context;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.AppInfo;
import app.greyshirts.firewall.app.log.AccessLogEntry;
import app.greyshirts.firewall.app.log.AccessLogs;
import app.greyshirts.firewall.cache.AddressCache;
import app.greyshirts.firewall.cache.DnsCache;
import java.text.SimpleDateFormat;
import java.util.Date;

/* JADX INFO: loaded from: classes.dex */
public class AdapterAccessLog extends BaseAdapter {
    private final String allowedString;
    private final String deniedString;
    private final LayoutInflater inflater;
    private final AccessLogs.Observer observer = new AccessLogs.Observer() { // from class: app.greyshirts.firewall.ui.AdapterAccessLog.1
        @Override // app.greyshirts.firewall.app.log.AccessLogs.Observer
        public void onRingBufferChanged() {
            AdapterAccessLog.this.handler.post(new Runnable() { // from class: app.greyshirts.firewall.ui.AdapterAccessLog.1.1
                @Override // java.lang.Runnable
                public void run() {
                    AdapterAccessLog.this.logs = null;
                    AdapterAccessLog.this.notifyDataSetChanged();
                }
            });
        }
    };
    private final SimpleDateFormat sdf = new SimpleDateFormat("MM-dd HH:mm");
    private final AccessLogs originalLog = AccessLogs.getInstance();
    private AccessLogs logs = this.originalLog.makeCopy();
    private final Handler handler = new Handler();

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return 0L;
    }

    public AdapterAccessLog(Context context) {
        this.inflater = LayoutInflater.from(context);
        this.originalLog.addObserver(this.observer);
        this.allowedString = context.getString(R.string.access_log_allowed);
        this.deniedString = context.getString(R.string.access_log_denied);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        if (this.logs == null) {
            this.logs = this.originalLog.makeCopy();
        }
        return this.logs.count();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        if (this.logs == null) {
            this.logs = this.originalLog.makeCopy();
        }
        AccessLogs accessLogs = this.logs;
        return accessLogs.get((accessLogs.count() - 1) - i);
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = newView();
        }
        bindView(view, i);
        return view;
    }

    public View newView() {
        View viewInflate = this.inflater.inflate(R.layout.listitem_accesslog, (ViewGroup) null);
        Tag tag = new Tag();
        tag.viewBackground = viewInflate.findViewById(R.id.background);
        tag.viewIcon = (ImageView) viewInflate.findViewById(R.id.icon);
        tag.viewName = (TextView) viewInflate.findViewById(R.id.name);
        tag.viewTime = (TextView) viewInflate.findViewById(R.id.time);
        tag.viewIp = (TextView) viewInflate.findViewById(R.id.ip);
        tag.viewHostName = (TextView) viewInflate.findViewById(R.id.hostName);
        tag.viewStatus = (TextView) viewInflate.findViewById(R.id.status);
        viewInflate.setTag(tag);
        return viewInflate;
    }

    public void bindView(View view, int i) {
        String serverHost;
        final Tag tag = (Tag) view.getTag();
        final AccessLogEntry accessLogEntry = (AccessLogEntry) getItem(i);
        tag.viewName.setText(accessLogEntry.getAllAppName());
        tag.viewIp.setText(String.format("%s:%d", accessLogEntry.getServerIp(), Integer.valueOf(accessLogEntry.getServerPort())));
        tag.viewIcon.setImageDrawable(AppInfo.getIcon(view.getContext(), accessLogEntry.getPkgs().getAt(0)));
        tag.viewTime.setText(this.sdf.format(new Date(accessLogEntry.getTime())));
        if (TextUtils.isEmpty(accessLogEntry.getServerHost())) {
            AddressCache.AddressCacheEntry addressCacheEntryResolveNameFromIpForUiThread = DnsCache.getInstance().resolveNameFromIpForUiThread(accessLogEntry.getServerIp(), new DnsCache.ResolveNameResult(this) { // from class: app.greyshirts.firewall.ui.AdapterAccessLog.2
                @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
                public void onFinish(String str, String str2) {
                    if (!accessLogEntry.getServerIp().equals(str) || TextUtils.isEmpty(str2)) {
                        return;
                    }
                    tag.viewHostName.setText(str2);
                    accessLogEntry.setServerHost(str2);
                }
            });
            if (addressCacheEntryResolveNameFromIpForUiThread == null || TextUtils.isEmpty(addressCacheEntryResolveNameFromIpForUiThread.hostname)) {
                serverHost = null;
            } else {
                serverHost = addressCacheEntryResolveNameFromIpForUiThread.hostname;
                accessLogEntry.setServerHost(serverHost);
            }
        } else {
            serverHost = accessLogEntry.getServerHost();
        }
        tag.viewHostName.setText(serverHost);
        int type = accessLogEntry.getType();
        if (type == 0) {
            tag.viewStatus.setText("");
            tag.viewBackground.getBackground().setLevel(0);
        } else if (type == 1) {
            tag.viewStatus.setText(this.allowedString);
            tag.viewBackground.getBackground().setLevel(1);
        } else {
            if (type != 2) {
                return;
            }
            tag.viewStatus.setText(this.deniedString);
            tag.viewBackground.getBackground().setLevel(2);
        }
    }

    static class Tag {
        View viewBackground;
        TextView viewHostName;
        ImageView viewIcon;
        TextView viewIp;
        TextView viewName;
        TextView viewStatus;
        TextView viewTime;

        Tag() {
        }
    }
}
