package app.greyshirts.firewall.ui.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;

/* JADX INFO: loaded from: classes.dex */
public class AllowDenyCheckbox extends ImageView implements View.OnClickListener {
    private CheckState checkState;
    private int customLevel;
    private boolean hasCustomAllow;
    private boolean hasCustomDeny;
    private OnCheckStateChanged listener;

    public enum CheckState {
        ALLOW,
        DENY,
        CUSTOM
    }

    public interface OnCheckStateChanged {
        void onCheckStateChanged(AllowDenyCheckbox allowDenyCheckbox, CheckState checkState);
    }

    public AllowDenyCheckbox(Context context) {
        super(context);
        this.checkState = CheckState.CUSTOM;
        this.customLevel = 2;
        super.setOnClickListener(this);
        updateView();
    }

    public AllowDenyCheckbox(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.checkState = CheckState.CUSTOM;
        this.customLevel = 2;
        super.setOnClickListener(this);
        updateView();
    }

    public AllowDenyCheckbox(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.checkState = CheckState.CUSTOM;
        this.customLevel = 2;
        super.setOnClickListener(this);
        updateView();
    }

    public void setOnCheckStateChangedListener(OnCheckStateChanged onCheckStateChanged) {
        this.listener = onCheckStateChanged;
    }

    public void bindData(CheckState checkState, boolean z, boolean z2) {
        this.checkState = checkState;
        this.hasCustomAllow = z;
        this.hasCustomDeny = z2;
        if (!z && !z2) {
            this.customLevel = 2;
        } else if (z && z2) {
            this.customLevel = 5;
        } else if (z) {
            this.customLevel = 3;
        } else {
            this.customLevel = 4;
        }
        updateView();
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.widget.AllowDenyCheckbox$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState = new int[CheckState.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[CheckState.ALLOW.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[CheckState.DENY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[CheckState.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }

    private void updateView() {
        int i = AnonymousClass1.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[this.checkState.ordinal()];
        if (i == 1) {
            setImageLevel(0);
        } else if (i == 2) {
            setImageLevel(1);
        } else {
            if (i != 3) {
                return;
            }
            setImageLevel(this.customLevel);
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        int i = AnonymousClass1.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[this.checkState.ordinal()];
        if (i == 1) {
            this.checkState = CheckState.DENY;
        } else if (i == 2) {
            this.checkState = CheckState.CUSTOM;
        } else if (i == 3) {
            this.checkState = CheckState.ALLOW;
        }
        updateView();
        OnCheckStateChanged onCheckStateChanged = this.listener;
        if (onCheckStateChanged != null) {
            onCheckStateChanged.onCheckStateChanged(this, this.checkState);
        }
    }

    public CheckState getCheckState() {
        return this.checkState;
    }

    public boolean hasCustomAllow() {
        return this.hasCustomAllow;
    }

    public boolean hasCustomDeny() {
        return this.hasCustomDeny;
    }
}
