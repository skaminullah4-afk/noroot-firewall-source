package app.greyshirts.firewall.ui.debug;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import app.greyshirts.firewall.R;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/* JADX INFO: loaded from: classes.dex */
public class FragDebugCommand extends Fragment {
    private TextView viewText;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_debug_command, (ViewGroup) null);
        this.viewText = (TextView) viewInflate.findViewById(R.id.text);
        viewInflate.findViewById(R.id.procroute).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugCommand.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragDebugCommand.this.execCommand("cat /proc/net/route");
            }
        });
        viewInflate.findViewById(R.id.netcfg).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugCommand.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragDebugCommand.this.execCommand("netcfg");
            }
        });
        viewInflate.findViewById(R.id.ipaddr).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugCommand.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragDebugCommand.this.execCommand("ip addr show");
            }
        });
        viewInflate.findViewById(R.id.iplink).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugCommand.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragDebugCommand.this.execCommand("ip link show");
            }
        });
        viewInflate.findViewById(R.id.iproute).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugCommand.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragDebugCommand.this.execCommand("ip route show");
            }
        });
        viewInflate.findViewById(R.id.clear).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragDebugCommand.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragDebugCommand.this.viewText.setText("");
            }
        });
        return viewInflate;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void execCommand(String str) {
        new MyTask().execute(str);
    }

    class MyTask extends AsyncTask<String, Void, String> {
        MyTask() {
        }

        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Code duplicated, block: B:35:0x006b A[EXC_TOP_SPLITTER, FINALLY_INSNS, SYNTHETIC] */
        @Override // android.os.AsyncTask
        public String doInBackground(String... strArr) {
            String str = strArr[0];
            try {
                InputStream inputStream = null;
                try {
                    inputStream = Runtime.getRuntime().exec(str).getInputStream();
                    byte[] bArr = new byte[8192];
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    while (true) {
                        int i = inputStream.read(bArr);
                        if (i == -1) {
                            break;
                        }
                        byteArrayOutputStream.write(bArr, 0, i);
                        if (inputStream != null) {
                            try {
                                inputStream.close();
                            } catch (IOException unused) {
                            }
                        }
                    }
                    byteArrayOutputStream.close();
                    return "$ " + str + "\n" + byteArrayOutputStream.toString() + "\n\n";
                } catch (IOException e) {
                    return "error " + e;
                } finally {
                    if (inputStream != null) {
                        inputStream.close();
                    }
                }
            } catch (IOException e2) {
                return "exec failed " + e2;
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String str) {
            FragDebugCommand.this.viewText.setText(FragDebugCommand.this.viewText.getText().toString() + str);
        }
    }
}
