package app.greyshirts.firewall.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.MyVpnService;
import app.greyshirts.firewall.app.debuglog.PersistentLog;
import app.greyshirts.firewall.lock.LockManager;
import app.greyshirts.firewall.proxy.CrashDumper;
import app.greyshirts.firewall.proxy.ProxyWorker;

/* JADX INFO: loaded from: classes.dex */
public class FragHome extends Fragment implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    private Context ctx;
    private Handler handler;
    private LockManager lockManager;
    private CheckBox viewAutoStart;
    private View viewButtonStart;
    private View viewButtonStop;
    private View viewCrashReportLayout;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_home, viewGroup, false);
        this.viewButtonStart = viewInflate.findViewById(R.id.buttonStart);
        this.viewButtonStart.setOnClickListener(this);
        this.viewButtonStop = viewInflate.findViewById(R.id.buttonStop);
        this.viewButtonStop.setOnClickListener(this);
        this.viewAutoStart = (CheckBox) viewInflate.findViewById(R.id.autoStart);
        this.viewAutoStart.setOnCheckedChangeListener(this);
        this.viewAutoStart.setChecked(getAutoStart(getActivity()));
        this.viewCrashReportLayout = viewInflate.findViewById(R.id.crashReportLayout);
        viewInflate.findViewById(R.id.buttonSendCrashReport).setOnClickListener(this);
        updateView(this.lockManager.isLocked());
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.ctx = getActivity().getApplicationContext();
        this.handler = new Handler() { // from class: app.greyshirts.firewall.ui.FragHome.1
            @Override // android.os.Handler
            public void handleMessage(Message message) {
                FragHome.this.updateStartButtons();
                FragHome.this.rescheduleButtonUpdate(300);
            }
        };
        this.lockManager = LockManager.getInstance(getActivity());
        this.lockManager.isLockedLiveData().observe(this, new Observer() { // from class: app.greyshirts.firewall.ui.-$$Lambda$FragHome$A1lxFwLa43isbQjpDQatF762aCA
            @Override // androidx.lifecycle.Observer
            public final void onChanged(Object obj) {
                this.f$0.lambda$onCreate$0$FragHome((Boolean) obj);
            }
        });
    }

    public /* synthetic */ void lambda$onCreate$0$FragHome(Boolean bool) {
        updateView(bool.booleanValue());
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        updateStartButtons();
        rescheduleButtonUpdate(300);
        this.viewCrashReportLayout.setVisibility(8);
        if (CrashDumper.getInstance(getActivity()).hasCrashDump()) {
            this.viewCrashReportLayout.setVisibility(0);
        }
        if (MyUncaughtExceptionHandler.peekLastErrorLog(getActivity()) != null) {
            this.viewCrashReportLayout.setVisibility(0);
        }
    }

    @Override // androidx.fragment.app.Fragment
    public void onPause() {
        super.onPause();
        this.handler.removeMessages(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateStartButtons() {
        updateStartButtons(ProxyWorker.getInstance().isRunning());
    }

    private void updateStartButtons(boolean z) {
        if (z) {
            this.viewButtonStart.setEnabled(false);
            if (this.lockManager.isLocked()) {
                this.viewButtonStop.setEnabled(false);
                return;
            } else {
                this.viewButtonStop.setEnabled(true);
                return;
            }
        }
        this.viewButtonStart.setEnabled(true);
        this.viewButtonStop.setEnabled(false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void rescheduleButtonUpdate(int i) {
        this.handler.removeMessages(0);
        this.handler.sendEmptyMessageDelayed(0, i);
    }

    private void updateView(boolean z) {
        if (z) {
            this.viewAutoStart.setEnabled(false);
        } else {
            this.viewAutoStart.setEnabled(true);
        }
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        String str;
        switch (view.getId()) {
            case R.id.buttonSendCrashReport /* 2131230816 */:
                String str2 = "";
                CrashDumper crashDumper = CrashDumper.getInstance(getActivity());
                if (crashDumper.hasCrashDump()) {
                    str2 = ((("===================\n") + " Jni crash dump\n") + "===================\n") + crashDumper.readCrashDump() + "\n\n";
                    crashDumper.removeFile();
                }
                String andClearLastErrorLog = MyUncaughtExceptionHandler.getAndClearLastErrorLog(getActivity());
                if (!TextUtils.isEmpty(andClearLastErrorLog)) {
                    str2 = (((str2 + "===================\n") + " Java crash dump\n") + "===================\n") + andClearLastErrorLog + "\n\n";
                }
                if (!TextUtils.isEmpty(str2)) {
                    try {
                        str = getActivity().getPackageManager().getPackageInfo(getActivity().getPackageName(), 0).versionName;
                    } catch (PackageManager.NameNotFoundException unused) {
                        str = "unknown";
                    }
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.SEND");
                    intent.putExtra("android.intent.extra.TEXT", str2);
                    intent.putExtra("android.intent.extra.SUBJECT", "NoRoot Firewall stacktrace v" + str);
                    intent.putExtra("android.intent.extra.EMAIL", new String[]{"greyshirts@outlook.com"});
                    intent.setType("text/plain");
                    startActivity(Intent.createChooser(intent, getString(R.string.translate_choose_email_app_dialog_title)));
                }
                break;
            case R.id.buttonStart /* 2131230819 */:
                PersistentLog.getInstance(getActivity()).i("UI start button pressed", new Object[0]);
                ((ActivityPager) getActivity()).setupVpn();
                updateStartButtons(true);
                rescheduleButtonUpdate(1000);
                break;
            case R.id.buttonStop /* 2131230820 */:
                PersistentLog.getInstance(getActivity()).i("UI stop button pressed", new Object[0]);
                MyVpnService.stopService(this.ctx);
                break;
        }
    }

    public static boolean getAutoStart(Context context) {
        return context.getSharedPreferences("PREF", 0).getBoolean("autoStart", false);
    }

    private static void setAutoStart(Context context, boolean z) {
        SharedPreferences.Editor editorEdit = context.getSharedPreferences("PREF", 0).edit();
        editorEdit.putBoolean("autoStart", z);
        editorEdit.commit();
    }

    @Override // android.widget.CompoundButton.OnCheckedChangeListener
    public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
        setAutoStart(getActivity(), z);
    }
}
