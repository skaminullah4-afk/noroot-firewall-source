package app.greyshirts.firewall.ui;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.cache.AddressCache;
import app.greyshirts.firewall.cache.DnsCache;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;

/* JADX INFO: loaded from: classes.dex */
public class ViewCustomFilter extends LinearLayout {
    private Listener listener;
    private ModelCustomFilter modelCustomFilter;
    private AllowDenyCheckbox viewCheckMobile;
    private AllowDenyCheckbox viewCheckWifi;
    private View viewDelete;
    private TextView viewHostName;
    private TextView viewServerStr;

    public interface Listener {
        void onDeleteClicked(ModelCustomFilter modelCustomFilter);

        void onMobileCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState);

        void onWifiCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState);
    }

    public ViewCustomFilter(Context context) {
        super(context);
    }

    public ViewCustomFilter(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public ViewCustomFilter(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @Override // android.view.View
    protected void onFinishInflate() {
        super.onFinishInflate();
        this.viewCheckWifi = (AllowDenyCheckbox) findViewById(R.id.checkWifi);
        this.viewCheckMobile = (AllowDenyCheckbox) findViewById(R.id.checkMobile);
        this.viewServerStr = (TextView) findViewById(R.id.ip);
        this.viewHostName = (TextView) findViewById(R.id.hostName);
        this.viewDelete = findViewById(R.id.delete);
        this.viewDelete.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.ViewCustomFilter.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (ViewCustomFilter.this.listener != null) {
                    ViewCustomFilter.this.listener.onDeleteClicked(ViewCustomFilter.this.modelCustomFilter);
                }
            }
        });
        this.viewCheckWifi.setOnCheckStateChangedListener(new AllowDenyCheckbox.OnCheckStateChanged() { // from class: app.greyshirts.firewall.ui.ViewCustomFilter.2
            @Override // app.greyshirts.firewall.ui.widget.AllowDenyCheckbox.OnCheckStateChanged
            public void onCheckStateChanged(AllowDenyCheckbox allowDenyCheckbox, AllowDenyCheckbox.CheckState checkState) {
                if (ViewCustomFilter.this.listener != null) {
                    ViewCustomFilter.this.listener.onWifiCheckStateChanged(ViewCustomFilter.this.modelCustomFilter, checkState);
                }
            }
        });
        this.viewCheckMobile.setOnCheckStateChangedListener(new AllowDenyCheckbox.OnCheckStateChanged() { // from class: app.greyshirts.firewall.ui.ViewCustomFilter.3
            @Override // app.greyshirts.firewall.ui.widget.AllowDenyCheckbox.OnCheckStateChanged
            public void onCheckStateChanged(AllowDenyCheckbox allowDenyCheckbox, AllowDenyCheckbox.CheckState checkState) {
                if (ViewCustomFilter.this.listener != null) {
                    ViewCustomFilter.this.listener.onMobileCheckStateChanged(ViewCustomFilter.this.modelCustomFilter, checkState);
                }
            }
        });
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setModel(ModelCustomFilter modelCustomFilter) {
        this.modelCustomFilter = modelCustomFilter;
        this.viewCheckWifi.bindData(filterTypeToCheckState(this.modelCustomFilter.filterType0), false, false);
        this.viewCheckMobile.bindData(filterTypeToCheckState(this.modelCustomFilter.filterType1), false, false);
        this.viewServerStr.setVisibility(0);
        int i = this.modelCustomFilter.serverPort;
        String strValueOf = i == -1 ? "*" : String.valueOf(i);
        this.viewServerStr.setText(this.modelCustomFilter.serverStr + ":" + strValueOf);
        this.viewHostName.setTag(this.modelCustomFilter.serverStr);
        ModelCustomFilter modelCustomFilter2 = this.modelCustomFilter;
        if (modelCustomFilter2.serverStrType == 0 && !"*".equals(modelCustomFilter2.serverStr)) {
            this.viewHostName.setVisibility(0);
            AddressCache.AddressCacheEntry addressCacheEntryResolveNameFromIpForUiThread = DnsCache.getInstance().resolveNameFromIpForUiThread(this.modelCustomFilter.serverStr, new DnsCache.ResolveNameResult() { // from class: app.greyshirts.firewall.ui.ViewCustomFilter.4
                @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
                public void onFinish(String str, String str2) {
                    if (ViewCustomFilter.this.modelCustomFilter.serverStrType != 0 || ViewCustomFilter.this.modelCustomFilter.serverStr == null || !ViewCustomFilter.this.modelCustomFilter.serverStr.equals(str) || TextUtils.isEmpty(str2)) {
                        return;
                    }
                    ViewCustomFilter.this.viewHostName.setText("(" + str2 + ")");
                }
            });
            if (addressCacheEntryResolveNameFromIpForUiThread != null && !TextUtils.isEmpty(addressCacheEntryResolveNameFromIpForUiThread.hostname)) {
                this.viewHostName.setText("(" + addressCacheEntryResolveNameFromIpForUiThread.hostname + ")");
                return;
            }
            this.viewHostName.setText("");
            return;
        }
        this.viewHostName.setVisibility(8);
    }

    public ModelCustomFilter getModel() {
        return this.modelCustomFilter;
    }

    private AllowDenyCheckbox.CheckState filterTypeToCheckState(int i) {
        if (i == 0) {
            return AllowDenyCheckbox.CheckState.CUSTOM;
        }
        if (i == 1) {
            return AllowDenyCheckbox.CheckState.ALLOW;
        }
        if (i == 2) {
            return AllowDenyCheckbox.CheckState.DENY;
        }
        throw new RuntimeException("unknown filter type");
    }
}
