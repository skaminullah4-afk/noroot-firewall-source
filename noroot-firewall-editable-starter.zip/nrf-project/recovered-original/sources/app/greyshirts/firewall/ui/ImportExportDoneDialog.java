package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentActivity;
import app.greyshirts.firewall.R;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: FragImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class ImportExportDoneDialog extends DialogFragment {
    public static final Companion Companion = new Companion(null);

    /* JADX INFO: compiled from: FragImportExport.kt */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final ImportExportDoneDialog create(String title, String str) {
            Intrinsics.checkParameterIsNotNull(title, "title");
            ImportExportDoneDialog importExportDoneDialog = new ImportExportDoneDialog();
            Bundle bundle = new Bundle();
            bundle.putString("title", title);
            bundle.putString("msg", str);
            importExportDoneDialog.setArguments(bundle);
            return importExportDoneDialog;
        }
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        FragmentActivity activity = getActivity();
        if (activity != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);
            Bundle arguments = getArguments();
            if (arguments == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            builder.setTitle(arguments.getString("title"));
            Bundle arguments2 = getArguments();
            if (arguments2 == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            builder.setMessage(arguments2.getString("msg"));
            builder.setPositiveButton(R.string.filter_import_export_close, new DialogInterface.OnClickListener() { // from class: app.greyshirts.firewall.ui.ImportExportDoneDialog.onCreateDialog.1
                @Override // android.content.DialogInterface.OnClickListener
                public final void onClick(DialogInterface dialogInterface, int i) {
                    ImportExportDoneDialog.this.dismiss();
                }
            });
            AlertDialog alertDialogCreate = builder.create();
            Intrinsics.checkExpressionValueIsNotNull(alertDialogCreate, "AlertDialog.Builder(acti…                .create()");
            return alertDialogCreate;
        }
        Intrinsics.throwNpe();
        throw null;
    }
}
