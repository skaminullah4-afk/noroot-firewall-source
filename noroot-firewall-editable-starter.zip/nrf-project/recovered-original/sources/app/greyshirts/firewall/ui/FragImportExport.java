package app.greyshirts.firewall.ui;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProviders;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.db.ImportResult;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: FragImportExport.kt */
/* JADX INFO: loaded from: classes.dex */
public final class FragImportExport extends DialogFragment {
    public static final Companion Companion = new Companion(null);
    public Button cancelButton;

    public static final FragImportExport forExport(Uri uri) {
        return Companion.forExport(uri);
    }

    public static final FragImportExport forImport(Uri uri) {
        return Companion.forImport(uri);
    }

    /* JADX INFO: compiled from: FragImportExport.kt */
    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final FragImportExport forExport(Uri uri) {
            Intrinsics.checkParameterIsNotNull(uri, "uri");
            FragImportExport fragImportExport = new FragImportExport();
            Bundle bundle = new Bundle();
            bundle.putParcelable("uri", uri);
            bundle.putBoolean("isExport", true);
            fragImportExport.setArguments(bundle);
            return fragImportExport;
        }

        public final FragImportExport forImport(Uri uri) {
            Intrinsics.checkParameterIsNotNull(uri, "uri");
            FragImportExport fragImportExport = new FragImportExport();
            Bundle bundle = new Bundle();
            bundle.putParcelable("uri", uri);
            bundle.putBoolean("isExport", false);
            fragImportExport.setArguments(bundle);
            return fragImportExport;
        }
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater inflater, ViewGroup viewGroup, Bundle bundle) {
        Intrinsics.checkParameterIsNotNull(inflater, "inflater");
        View viewInflate = inflater.inflate(R.layout.frag_import_export, viewGroup, false);
        Intrinsics.checkExpressionValueIsNotNull(viewInflate.findViewById(R.id.progressBar), "v.findViewById(R.id.progressBar)");
        View viewFindViewById = viewInflate.findViewById(R.id.cancelButton);
        Intrinsics.checkExpressionValueIsNotNull(viewFindViewById, "v.findViewById(R.id.cancelButton)");
        this.cancelButton = (Button) viewFindViewById;
        Button button = this.cancelButton;
        if (button != null) {
            button.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.FragImportExport.onCreateView.1
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    FragImportExport.this.dismiss();
                }
            });
            return viewInflate;
        }
        Intrinsics.throwUninitializedPropertyAccessException("cancelButton");
        throw null;
    }

    @Override // androidx.fragment.app.DialogFragment, androidx.fragment.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        Bundle arguments = getArguments();
        if (arguments == null) {
            Intrinsics.throwNpe();
            throw null;
        }
        boolean z = arguments.getBoolean("isExport");
        ViewModel viewModel = ViewModelProviders.of(this).get(ExportViewModel.class);
        Intrinsics.checkExpressionValueIsNotNull(viewModel, "ViewModelProviders.of(th…ortViewModel::class.java)");
        ExportViewModel exportViewModel = (ExportViewModel) viewModel;
        exportViewModel.getExportResult().observe(this, new Observer<Exception>() { // from class: app.greyshirts.firewall.ui.FragImportExport.onActivityCreated.1
            @Override // androidx.lifecycle.Observer
            public final void onChanged(Exception exc) {
                if (exc == null) {
                    ImportExportDoneDialog.Companion companion = ImportExportDoneDialog.Companion;
                    String string = FragImportExport.this.getString(R.string.filter_export_ok_title);
                    Intrinsics.checkExpressionValueIsNotNull(string, "getString(R.string.filter_export_ok_title)");
                    ImportExportDoneDialog importExportDoneDialogCreate = companion.create(string, null);
                    FragmentManager fragmentManager = FragImportExport.this.getFragmentManager();
                    if (fragmentManager == null) {
                        Intrinsics.throwNpe();
                        throw null;
                    }
                    importExportDoneDialogCreate.show(fragmentManager, null);
                    FragImportExport.this.dismiss();
                    return;
                }
                ImportExportDoneDialog.Companion companion2 = ImportExportDoneDialog.Companion;
                String string2 = FragImportExport.this.getString(R.string.filter_export_error_title);
                Intrinsics.checkExpressionValueIsNotNull(string2, "getString(R.string.filter_export_error_title)");
                ImportExportDoneDialog importExportDoneDialogCreate2 = companion2.create(string2, exc.getMessage());
                FragmentManager fragmentManager2 = FragImportExport.this.getFragmentManager();
                if (fragmentManager2 == null) {
                    Intrinsics.throwNpe();
                    throw null;
                }
                importExportDoneDialogCreate2.show(fragmentManager2, null);
                FragImportExport.this.dismiss();
            }
        });
        exportViewModel.getImportResult().observe(this, new Observer<ImportResult>() { // from class: app.greyshirts.firewall.ui.FragImportExport.onActivityCreated.2
            @Override // androidx.lifecycle.Observer
            public final void onChanged(ImportResult importResult) {
                if (importResult.getE() == null) {
                    ImportExportDoneDialog.Companion companion = ImportExportDoneDialog.Companion;
                    String string = FragImportExport.this.getString(R.string.filter_import_ok_title);
                    Intrinsics.checkExpressionValueIsNotNull(string, "getString(R.string.filter_import_ok_title)");
                    ImportExportDoneDialog importExportDoneDialogCreate = companion.create(string, FragImportExport.this.getString(R.string.filter_import_ok_msg, Integer.valueOf(importResult.getNumInserted()), Integer.valueOf(importResult.getNumUpdated())));
                    FragmentManager fragmentManager = FragImportExport.this.getFragmentManager();
                    if (fragmentManager == null) {
                        Intrinsics.throwNpe();
                        throw null;
                    }
                    importExportDoneDialogCreate.show(fragmentManager, null);
                    FragImportExport.this.dismiss();
                    return;
                }
                ImportExportDoneDialog.Companion companion2 = ImportExportDoneDialog.Companion;
                String string2 = FragImportExport.this.getString(R.string.filter_import_error_title);
                Intrinsics.checkExpressionValueIsNotNull(string2, "getString(R.string.filter_import_error_title)");
                String message = importResult.getE().getMessage();
                if (message == null) {
                    message = importResult.getE().toString();
                }
                ImportExportDoneDialog importExportDoneDialogCreate2 = companion2.create(string2, message);
                FragmentManager fragmentManager2 = FragImportExport.this.getFragmentManager();
                if (fragmentManager2 == null) {
                    Intrinsics.throwNpe();
                    throw null;
                }
                importExportDoneDialogCreate2.show(fragmentManager2, null);
                FragImportExport.this.dismiss();
            }
        });
        if (bundle == null) {
            Bundle arguments2 = getArguments();
            if (arguments2 == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            Uri uri = (Uri) arguments2.getParcelable("uri");
            if (uri == null) {
                dismiss();
            } else if (z) {
                exportViewModel.startExporting(uri);
            } else {
                exportViewModel.startImporting(uri);
            }
        }
    }
}
