package app.greyshirts.firewall.ui.debug;

import android.os.Bundle;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.BackgroundColorSpan;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.JsonReader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.proxy.ProxyWorker;
import java.io.IOException;
import java.io.StringReader;

/* JADX INFO: loaded from: classes.dex */
public class FragEvent extends Fragment {
    private TextView viewText;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_debug_log, (ViewGroup) null);
        this.viewText = (TextView) viewInflate.findViewById(R.id.text);
        viewInflate.findViewById(R.id.refresh).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragEvent.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                FragEvent.this.updateView();
            }
        });
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        updateView();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void updateView() {
        SpannableString spannableString;
        String eventJson = ProxyWorker.getInstance().getEventJson();
        if (TextUtils.isEmpty(eventJson)) {
            this.viewText.setText("(empty)");
            return;
        }
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        JsonReader jsonReader = new JsonReader(new StringReader(eventJson));
        try {
            jsonReader.beginObject();
            while (jsonReader.hasNext()) {
                String strNextName = jsonReader.nextName();
                jsonReader.beginObject();
                Log.i("NRFW", "ev " + strNextName);
                spannableStringBuilder.append((CharSequence) (strNextName + "\n"));
                while (jsonReader.hasNext()) {
                    String strNextName2 = jsonReader.nextName();
                    long jNextLong = jsonReader.nextLong();
                    Log.i("NRFW", "ev     " + strNextName2 + ":" + jNextLong);
                    spannableStringBuilder.append((CharSequence) "    ");
                    if (strNextName2.endsWith("_E")) {
                        spannableString = new SpannableString(strNextName2.substring(0, strNextName2.length() - 2) + ":" + jNextLong);
                        if (jNextLong == 0) {
                            spannableString.setSpan(new ForegroundColorSpan(-65536), 0, spannableString.length(), 17);
                        } else {
                            spannableString.setSpan(new ForegroundColorSpan(-1), 0, spannableString.length(), 17);
                            spannableString.setSpan(new BackgroundColorSpan(-65536), 0, spannableString.length(), 17);
                            spannableString.setSpan(new StyleSpan(1), 0, spannableString.length(), 17);
                        }
                    } else if (strNextName2.contains("_W")) {
                        spannableString = new SpannableString(strNextName2.substring(0, strNextName2.length() - 2) + ":" + jNextLong);
                        if (jNextLong == 0) {
                            spannableString.setSpan(new ForegroundColorSpan(-16776961), 0, spannableString.length(), 17);
                        } else {
                            spannableString.setSpan(new ForegroundColorSpan(-1), 0, spannableString.length(), 17);
                            spannableString.setSpan(new BackgroundColorSpan(-16776961), 0, spannableString.length(), 17);
                            spannableString.setSpan(new StyleSpan(1), 0, spannableString.length(), 17);
                        }
                    } else {
                        spannableString = new SpannableString(strNextName2 + ":" + jNextLong);
                    }
                    spannableStringBuilder.append((CharSequence) spannableString);
                    spannableStringBuilder.append((CharSequence) "\n");
                }
                jsonReader.endObject();
            }
            jsonReader.endObject();
            this.viewText.setText(spannableStringBuilder.subSequence(0, spannableStringBuilder.length()));
        } catch (IOException e) {
            Log.i("NRFW", "caught exception. " + e);
            this.viewText.setText("(json parse error)");
        }
    }
}
