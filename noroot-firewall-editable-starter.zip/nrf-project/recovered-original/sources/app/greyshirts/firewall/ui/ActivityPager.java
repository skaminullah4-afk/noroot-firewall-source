package app.greyshirts.firewall.ui;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.util.Pair;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.lifecycle.Observer;
import androidx.viewpager.widget.ViewPager;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.MyVpnService;
import app.greyshirts.firewall.app.PendingNotification;
import app.greyshirts.firewall.app.debuglog.PersistentLog;
import app.greyshirts.firewall.lock.LockManager;
import app.greyshirts.firewall.ui.debug.ActivityDebug;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

/* JADX INFO: loaded from: classes.dex */
public class ActivityPager extends AppCompatActivity {
    private ActionBarDrawerToggle actionBarDrawerToggle;
    private BottomNavigationView bottomNavigationView;
    private DrawerLayout drawerLayout;
    private LockManager lockManager;
    private NavigationView navigationView;
    private ViewPager viewPager;
    private boolean isResumed = false;
    private SingleLiveEvent<Pair<Boolean, Uri>> command = new SingleLiveEvent<>();

    public static Intent getStartIntentFromForegroundServiceNotification(Context context) {
        Intent intent = new Intent(context, (Class<?>) ActivityPager.class);
        intent.setFlags(268435456);
        return intent;
    }

    public static Intent getStartIntentFromBlockNotification(Context context) {
        Intent intent = new Intent(context, (Class<?>) ActivityPager.class);
        intent.setFlags(268435456);
        intent.putExtra("fromNotification", true);
        return intent;
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        Intent intent;
        super.onCreate(bundle);
        if (!MyUncaughtExceptionHandler.isSet()) {
            Thread.setDefaultUncaughtExceptionHandler(new MyUncaughtExceptionHandler(getApplicationContext()));
        }
        this.lockManager = LockManager.getInstance(this);
        this.lockManager.isLockedLiveData().observe(this, new Observer() { // from class: app.greyshirts.firewall.ui.-$$Lambda$ActivityPager$ZgifSq61VVyq3Yox5dhcfqvG5gw
            @Override // androidx.lifecycle.Observer
            public final void onChanged(Object obj) {
                this.f$0.lambda$onCreate$0$ActivityPager((Boolean) obj);
            }
        });
        setContentView(R.layout.activity_pager);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        this.drawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        this.actionBarDrawerToggle = new ActionBarDrawerToggle(this, this.drawerLayout, toolbar, 0, 0);
        this.drawerLayout.addDrawerListener(this.actionBarDrawerToggle);
        this.navigationView = (NavigationView) findViewById(R.id.navigation);
        this.navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() { // from class: app.greyshirts.firewall.ui.-$$Lambda$ActivityPager$uxpVMjOpI2rYcqw7TqCk0OngWBA
            @Override // com.google.android.material.navigation.NavigationView.OnNavigationItemSelectedListener
            public final boolean onNavigationItemSelected(MenuItem menuItem) {
                return this.f$0.onItemSelected(menuItem);
            }
        });
        this.navigationView.getMenu().removeGroup(R.id.menu_group_passcode);
        if (Build.VERSION.SDK_INT < 19) {
            this.navigationView.getMenu().removeGroup(R.id.menu_group_export_import);
        }
        this.bottomNavigationView = (BottomNavigationView) findViewById(R.id.bottomNavigation);
        this.bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() { // from class: app.greyshirts.firewall.ui.-$$Lambda$ActivityPager$fIF3OLo81Sl5kRdQKnHfIsJZtCs
            @Override // com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener
            public final boolean onNavigationItemSelected(MenuItem menuItem) {
                return this.f$0.lambda$onCreate$1$ActivityPager(menuItem);
            }
        });
        this.viewPager = (ViewPager) findViewById(R.id.pager);
        this.viewPager.setAdapter(new MyAdapter(getSupportFragmentManager()));
        this.viewPager.setEnabled(false);
        if (bundle == null && (intent = getIntent()) != null && "autoStart".equals(intent.getAction()) && handleIntentOnce(intent)) {
            setupVpn();
        }
        this.command.observe(this, new Observer<Pair<Boolean, Uri>>() { // from class: app.greyshirts.firewall.ui.ActivityPager.1
            @Override // androidx.lifecycle.Observer
            public void onChanged(Pair<Boolean, Uri> pair) {
                if (pair.first.booleanValue()) {
                    FragImportExport.forExport(pair.second).show(ActivityPager.this.getSupportFragmentManager(), null);
                } else {
                    FragImportExport.forImport(pair.second).show(ActivityPager.this.getSupportFragmentManager(), null);
                }
            }
        });
        updateView(this.lockManager.isLocked());
    }

    public /* synthetic */ void lambda$onCreate$0$ActivityPager(Boolean bool) {
        if (bool.booleanValue()) {
            this.viewPager.setCurrentItem(0, false);
            this.bottomNavigationView.setSelectedItemId(R.id.action_home);
        }
        updateView(bool.booleanValue());
    }

    public /* synthetic */ boolean lambda$onCreate$1$ActivityPager(MenuItem menuItem) {
        int i;
        if (this.lockManager.isLocked()) {
            return true;
        }
        switch (menuItem.getItemId()) {
            case R.id.action_filters /* 2131230770 */:
                i = 2;
                break;
            case R.id.action_global_filters /* 2131230771 */:
                i = 3;
                break;
            case R.id.action_log /* 2131230774 */:
                i = 4;
                break;
            case R.id.action_pending /* 2131230780 */:
                i = 1;
                break;
            default:
                i = 0;
                break;
        }
        this.viewPager.setCurrentItem(i, false);
        updateNotificationStatus();
        return true;
    }

    boolean handleIntentOnce(Intent intent) {
        long longExtra = intent.getLongExtra("RANDOMID", 0L);
        if (longExtra == 0) {
            return false;
        }
        SharedPreferences sharedPreferences = getSharedPreferences("PREF", 0);
        long j = sharedPreferences.getLong("ID", 0L);
        sharedPreferences.edit().putLong("ID", longExtra).apply();
        return j != longExtra;
    }

    @Override // androidx.appcompat.app.AppCompatActivity, android.app.Activity
    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        if (bundle != null) {
            this.bottomNavigationView.setSelectedItemId(R.id.action_pending);
        } else if (getIntent().getBooleanExtra("fromNotification", false) && !this.lockManager.isLocked()) {
            this.bottomNavigationView.setSelectedItemId(R.id.action_pending);
        }
        this.actionBarDrawerToggle.syncState();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onResume() {
        super.onResume();
        this.isResumed = true;
        updateNotificationStatus();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onPause() {
        super.onPause();
        this.isResumed = false;
        updateNotificationStatus();
    }

    void updateNotificationStatus() {
        if (this.isResumed) {
            if (this.bottomNavigationView.getSelectedItemId() == R.id.action_pending) {
                PendingNotification.clearNotification(this);
                PendingNotification.suspend();
                return;
            } else {
                PendingNotification.resume();
                return;
            }
        }
        PendingNotification.resume();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (!intent.getBooleanExtra("fromNotification", false) || this.lockManager.isLocked()) {
            return;
        }
        this.bottomNavigationView.setSelectedItemId(R.id.action_pending);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean onItemSelected(MenuItem menuItem) {
        this.drawerLayout.closeDrawers();
        switch (menuItem.getItemId()) {
            case R.id.about /* 2131230726 */:
                new FragAbout().show(getSupportFragmentManager(), null);
                return true;
            case R.id.debug /* 2131230848 */:
                startActivity(new Intent(this, (Class<?>) ActivityDebug.class));
                return true;
            case R.id.export_filters /* 2131230874 */:
                if (Build.VERSION.SDK_INT >= 19) {
                    Intent intent = new Intent("android.intent.action.CREATE_DOCUMENT");
                    intent.setType("application/json");
                    intent.addCategory("android.intent.category.OPENABLE");
                    intent.putExtra("android.intent.extra.TITLE", "filters.json");
                    startActivityForResult(intent, 1);
                }
                return true;
            case R.id.import_filters /* 2131230891 */:
                if (Build.VERSION.SDK_INT >= 19) {
                    Intent intent2 = new Intent("android.intent.action.OPEN_DOCUMENT");
                    intent2.setType("application/json");
                    intent2.addCategory("android.intent.category.OPENABLE");
                    startActivityForResult(intent2, 0);
                }
                return true;
            case R.id.passcode /* 2131230946 */:
                new DiagFragPassCode().show(getSupportFragmentManager(), null);
                return true;
            case R.id.why_vpn_connection /* 2131231059 */:
                new FragHelp().show(getSupportFragmentManager(), null);
                return true;
            default:
                return false;
        }
    }

    public void setupVpn() {
        try {
            Intent intentPrepare = VpnService.prepare(this);
            if (intentPrepare == null) {
                PersistentLog.getInstance(this).i("VpnService.prepare() returned null intent. It's ready to start", new Object[0]);
                Toast.makeText(this, getString(R.string.vpn_start_already_prepared), 0).show();
                MyVpnService.startService(this);
                return;
            }
            Log.i("NoRootFW", "intent=" + intentPrepare.toString());
            try {
                PersistentLog.getInstance(this).i("VpnService.prepare() returned intent. Ask user's permission", new Object[0]);
                startActivityForResult(intentPrepare, 100);
            } catch (ActivityNotFoundException unused) {
                PersistentLog.getInstance(this).i("Cannot start VPN accept Activity.", new Object[0]);
                Toast.makeText(this, getString(R.string.vpn_start_unavailable), 1).show();
            }
        } catch (NullPointerException e) {
            PersistentLog.getInstance(this).i("VpnService.prepare() threw NPE", new Object[0]);
            Toast.makeText(this, "Cannot prepare VPN (" + e.toString() + ")", 1).show();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i == 0) {
            if (i2 != -1) {
                return;
            }
            this.command.setValue(Pair.create(false, intent.getData()));
        } else {
            if (i == 1) {
                if (i2 != -1 || intent == null || intent.getData() == null) {
                    return;
                }
                this.command.setValue(Pair.create(true, intent.getData()));
                return;
            }
            if (i != 100) {
                super.onActivityResult(i, i2, intent);
            } else if (i2 == -1) {
                PersistentLog.getInstance(this).i("User accepted the VPN connection. It's ready to start", new Object[0]);
                MyVpnService.startService(this);
            }
        }
    }

    private void updateView(boolean z) {
        this.navigationView.getMenu().findItem(R.id.import_filters).setEnabled(!z);
        Menu menu = this.bottomNavigationView.getMenu();
        for (int i = 0; i < menu.size(); i++) {
            MenuItem item = menu.getItem(i);
            if (item.getItemId() != R.id.action_home) {
                item.setEnabled(!z);
            }
        }
    }

    static class MyAdapter extends FragmentPagerAdapter {
        @Override // androidx.viewpager.widget.PagerAdapter
        public int getCount() {
            return 5;
        }

        public MyAdapter(FragmentManager fragmentManager) {
            super(fragmentManager);
        }

        @Override // androidx.fragment.app.FragmentPagerAdapter
        public Fragment getItem(int i) {
            if (i == 0) {
                return new FragHome();
            }
            if (i == 1) {
                return new FragPendingListGrouped();
            }
            if (i == 2) {
                return new FragAllAppsList();
            }
            if (i == 3) {
                return FragGlobal.newInstance();
            }
            if (i == 4) {
                return new FragAccessLog();
            }
            throw new RuntimeException("invalid position");
        }
    }
}
