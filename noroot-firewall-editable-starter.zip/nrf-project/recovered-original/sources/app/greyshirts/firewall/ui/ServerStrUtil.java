package app.greyshirts.firewall.ui;

import android.text.TextUtils;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class ServerStrUtil {
    public final String str;
    public final int type;

    public static ServerStrUtil parse(String str) {
        return new ServerStrUtil(str);
    }

    private ServerStrUtil(String str) {
        this.str = str;
        if (TextUtils.isEmpty(str)) {
            this.type = 0;
            return;
        }
        String[] strArrSplit = str.split("\\.");
        if (checkAddressAsIp(str, strArrSplit)) {
            this.type = 1;
        } else if (checkAddressAsHost(str, strArrSplit)) {
            this.type = 2;
        } else {
            this.type = 0;
        }
    }

    public boolean isIp() {
        return this.type == 1;
    }

    public boolean isHostname() {
        return this.type == 2;
    }

    public boolean isValid() {
        return this.type != 0;
    }

    public ArrayList<String> makeIpWildcard() {
        if (!isIp()) {
            throw new RuntimeException("type mismatch. type=" + this.type);
        }
        ArrayList<String> arrayList = new ArrayList<>();
        _makeIpWildcard(arrayList, this.str);
        return arrayList;
    }

    private static void _makeIpWildcard(ArrayList<String> arrayList, String str) {
        if (!TextUtils.isEmpty(str)) {
            arrayList.add(str);
            String str2 = "";
            while (true) {
                int iLastIndexOf = str.lastIndexOf(".");
                if (iLastIndexOf < 1) {
                    break;
                }
                str = str.substring(0, iLastIndexOf);
                str2 = str2 + ".*";
                arrayList.add(str + str2);
            }
        }
        arrayList.add("*");
    }

    public ArrayList<String> makeHostnameWildcard() {
        if (!isHostname()) {
            throw new RuntimeException("type mismatch. type=" + this.type);
        }
        ArrayList<String> arrayList = new ArrayList<>();
        _makeHostnameWildcard(arrayList, this.str);
        return arrayList;
    }

    private static void _makeHostnameWildcard(ArrayList<String> arrayList, String str) {
        int iIndexOf;
        if (TextUtils.isEmpty(str)) {
            return;
        }
        arrayList.add(str);
        while (str.length() > 0 && (iIndexOf = str.indexOf(46)) >= 1) {
            str = str.substring(iIndexOf + 1);
            if (str.length() == 0) {
                return;
            }
            arrayList.add("*." + str);
        }
    }

    public static ArrayList<String> makeIpAndHostnameWildcard(String str, String str2) {
        ArrayList<String> arrayList = new ArrayList<>();
        _makeIpWildcard(arrayList, str);
        _makeHostnameWildcard(arrayList, str2);
        return arrayList;
    }

    private boolean checkAddressAsHost(String str, String[] strArr) {
        if (TextUtils.isEmpty(str) || strArr == null || str.startsWith(".") || str.endsWith(".")) {
            return false;
        }
        if (str.contains("*") && (!str.startsWith("*.") || str.substring(1).contains("*"))) {
            return false;
        }
        boolean z = true;
        for (String str2 : strArr) {
            if (TextUtils.isEmpty(str2)) {
                return false;
            }
            for (int i = 0; i < str2.length(); i++) {
                if (!Character.isDigit(str2.charAt(i))) {
                    z = false;
                    break;
                }
            }
        }
        return !z;
    }

    private boolean checkAddressAsIp(String str, String[] strArr) {
        if (TextUtils.isEmpty(str) || strArr == null) {
            return false;
        }
        if (str.equals("*")) {
            return true;
        }
        if (strArr.length != 4) {
            return false;
        }
        boolean z = false;
        for (int i = 0; i < 4; i++) {
            if ("*".equals(strArr[i])) {
                if (i == 0) {
                    return false;
                }
                z = true;
            } else {
                if (z) {
                    return false;
                }
                try {
                    int i2 = Integer.parseInt(strArr[i]);
                    if (i2 < 0 || i2 > 255) {
                        return false;
                    }
                } catch (Exception unused) {
                }
            }
        }
        return true;
    }
}
