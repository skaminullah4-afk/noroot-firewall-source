package app.greyshirts.firewall.ui;

import app.greyshirts.firewall.app.PackageNames;

/* JADX INFO: loaded from: classes.dex */
public class ModelPendingAccess {
    final long _id;
    final int appUid;
    final String leaderAppName;
    final PackageNames pkgs;
    final String serverHost;
    final String serverIp;
    final int serverPort;
    final long time;

    public ModelPendingAccess(long j, String str, String str2, int i, int i2, String str3, String str4, PackageNames packageNames, long j2) {
        this._id = j;
        this.serverIp = str;
        this.serverHost = str2;
        this.serverPort = i;
        this.appUid = i2;
        this.leaderAppName = str4;
        this.pkgs = packageNames;
        this.time = j2;
    }
}
