package app.greyshirts.firewall.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.fragment.app.Fragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.app.log.AccessLogEntry;
import app.greyshirts.firewall.app.log.AccessLogs;

/* JADX INFO: loaded from: classes.dex */
public class FragAccessLog extends Fragment {
    private AdapterAccessLog adapter;
    private final AdapterView.OnItemClickListener listItemClicked = new AdapterView.OnItemClickListener() { // from class: app.greyshirts.firewall.ui.FragAccessLog.1
        @Override // android.widget.AdapterView.OnItemClickListener
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            DiagFragOpenAccessLog.newInstance((AccessLogEntry) adapterView.getItemAtPosition(i)).show(FragAccessLog.this.getFragmentManager(), null);
        }
    };
    private ListView viewList;

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setHasOptionsMenu(true);
        this.adapter = new AdapterAccessLog(getActivity());
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_accesslog, (ViewGroup) null);
        this.viewList = (ListView) viewInflate.findViewById(R.id.list);
        this.viewList.setAdapter((ListAdapter) this.adapter);
        this.viewList.setOnItemClickListener(this.listItemClicked);
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.viewList.setAdapter((ListAdapter) null);
        this.viewList = null;
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.frag_accesslog, menu);
    }

    @Override // androidx.fragment.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId != R.id.add) {
            if (itemId != R.id.clear) {
                return false;
            }
            AccessLogs.getInstance().clear();
            return false;
        }
        AccessLogs.getInstance().add(AccessLogEntry.newTCPAccessLog(1, new byte[]{8, 8, 8, 8}, 80, (int) System.currentTimeMillis(), "all app name" + System.currentTimeMillis(), "leader app name", PackageNames.newInstanceFromCommaList("app.greyshirts.firewall")));
        return false;
    }
}
