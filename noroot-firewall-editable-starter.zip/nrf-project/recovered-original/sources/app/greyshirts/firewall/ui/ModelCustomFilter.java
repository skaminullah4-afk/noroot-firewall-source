package app.greyshirts.firewall.ui;

/* JADX INFO: loaded from: classes.dex */
public class ModelCustomFilter {
    final long filterRuleId;
    final int filterType0;
    final int filterType1;
    final int serverPort;
    final String serverStr;
    final int serverStrType;

    public ModelCustomFilter(long j, String str, int i, int i2, int i3, int i4) {
        this.filterRuleId = j;
        this.serverStr = str;
        this.serverStrType = i;
        this.serverPort = i2;
        this.filterType0 = i3;
        this.filterType1 = i4;
    }
}
