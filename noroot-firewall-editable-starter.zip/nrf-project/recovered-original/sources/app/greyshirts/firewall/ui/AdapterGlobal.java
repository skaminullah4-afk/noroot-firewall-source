package app.greyshirts.firewall.ui;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.db.FilterRuleContract;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;
import com.hb.views.PinnedSectionListView;

/* JADX INFO: loaded from: classes.dex */
class AdapterGlobal extends BaseAdapter implements PinnedSectionListView.PinnedSectionListAdapter {
    private int colFilterFilterRuleId;
    private int colFilterProfile0FilterType;
    private int colFilterProfile1FilterType;
    private int colFilterServerPort;
    private int colFilterServerStr;
    private int colFilterServerStrType;
    private final ContentResolver cr;
    private Cursor filterCursor;
    private final LayoutInflater inflater;
    private AdapterGlobalListener listener;
    private int numPostFilters;
    private int numPreFilters;
    private final Uri uri;
    private final View.OnClickListener preFilterOnClickListener = new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterGlobal.3
        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (AdapterGlobal.this.listener != null) {
                AdapterGlobal.this.listener.onPreFilterClicked(((ViewCustomFilter) view).getModel());
            }
        }
    };
    private final View.OnClickListener postFilterOnClickListener = new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterGlobal.4
        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (AdapterGlobal.this.listener != null) {
                AdapterGlobal.this.listener.onPostFilterClicked(((ViewCustomFilter) view).getModel());
            }
        }
    };
    private final ViewCustomFilter.Listener preFilterListener = new ViewCustomFilter.Listener() { // from class: app.greyshirts.firewall.ui.AdapterGlobal.5
        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onDeleteClicked(ModelCustomFilter modelCustomFilter) {
            if (modelCustomFilter != null) {
                AdapterGlobal.this.cr.delete(AdapterGlobal.this.uri, "_id=?", new String[]{String.valueOf(modelCustomFilter.filterRuleId)});
                if (AdapterGlobal.this.listener != null) {
                    AdapterGlobal.this.listener.onPreFilterDeleted();
                }
            }
        }

        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onWifiCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState) {
            if (AdapterGlobal.this.listener != null) {
                AdapterGlobal.this.listener.onPreFilterChanged(modelCustomFilter.filterRuleId, Filter.Profile.PROFILE_WIFI, checkState);
            }
        }

        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onMobileCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState) {
            if (AdapterGlobal.this.listener != null) {
                AdapterGlobal.this.listener.onPreFilterChanged(modelCustomFilter.filterRuleId, Filter.Profile.PROFILE_MOBILE, checkState);
            }
        }
    };
    private final ViewCustomFilter.Listener postFilterListener = new ViewCustomFilter.Listener() { // from class: app.greyshirts.firewall.ui.AdapterGlobal.6
        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onDeleteClicked(ModelCustomFilter modelCustomFilter) {
            if (modelCustomFilter != null) {
                AdapterGlobal.this.cr.delete(AdapterGlobal.this.uri, "_id=?", new String[]{String.valueOf(modelCustomFilter.filterRuleId)});
                if (AdapterGlobal.this.listener != null) {
                    AdapterGlobal.this.listener.onPostFilterDeleted();
                }
            }
        }

        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onWifiCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState) {
            if (AdapterGlobal.this.listener != null) {
                AdapterGlobal.this.listener.onPostFilterChanged(modelCustomFilter.filterRuleId, Filter.Profile.PROFILE_WIFI, checkState);
            }
        }

        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onMobileCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState) {
            if (AdapterGlobal.this.listener != null) {
                AdapterGlobal.this.listener.onPostFilterChanged(modelCustomFilter.filterRuleId, Filter.Profile.PROFILE_MOBILE, checkState);
            }
        }
    };

    public interface AdapterGlobalListener {
        void onNewPostFilterClicked();

        void onNewPreFilterClicked();

        void onPostFilterChanged(long j, Filter.Profile profile, AllowDenyCheckbox.CheckState checkState);

        void onPostFilterClicked(ModelCustomFilter modelCustomFilter);

        void onPostFilterDeleted();

        void onPreFilterChanged(long j, Filter.Profile profile, AllowDenyCheckbox.CheckState checkState);

        void onPreFilterClicked(ModelCustomFilter modelCustomFilter);

        void onPreFilterDeleted();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return 0L;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return 6;
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int i) {
        return false;
    }

    @Override // com.hb.views.PinnedSectionListView.PinnedSectionListAdapter
    public boolean isItemViewTypePinned(int i) {
        return i == 3 || i == 0;
    }

    public AdapterGlobal(Context context) {
        this.inflater = LayoutInflater.from(context);
        this.cr = context.getContentResolver();
        this.uri = FilterRuleContract.getInstance(context).getContentUri();
    }

    public void setListener(AdapterGlobalListener adapterGlobalListener) {
        this.listener = adapterGlobalListener;
    }

    public void changeCursor(Cursor cursor) {
        if (cursor != null) {
            this.colFilterServerStr = cursor.getColumnIndexOrThrow("serverIp");
            this.colFilterServerStrType = cursor.getColumnIndexOrThrow("serverStrType");
            this.colFilterServerPort = cursor.getColumnIndexOrThrow("serverPort");
            this.colFilterProfile0FilterType = cursor.getColumnIndexOrThrow("type");
            this.colFilterProfile1FilterType = cursor.getColumnIndexOrThrow("type1");
            this.colFilterFilterRuleId = cursor.getColumnIndexOrThrow("_id");
        }
        Cursor cursor2 = this.filterCursor;
        if (cursor2 != null && cursor2 != cursor) {
            cursor2.close();
        }
        this.filterCursor = cursor;
        Cursor cursor3 = this.filterCursor;
        if (cursor3 != null) {
            Bundle extras = cursor3.getExtras();
            this.numPreFilters = extras.getInt("pre", 0);
            this.numPostFilters = extras.getInt("post", 0);
        }
        notifyDataSetChanged();
    }

    @Override // android.widget.Adapter
    public int getCount() {
        Cursor cursor = this.filterCursor;
        return (cursor != null ? cursor.getCount() : 0) + 4;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int i) {
        int i2 = i - 1;
        if (i == 0) {
            return 0;
        }
        if (this.filterCursor != null) {
            int i3 = this.numPreFilters;
            if (i2 < i3) {
                return 1;
            }
            i2 -= i3;
        }
        int i4 = i2 - 1;
        if (i2 == 0) {
            return 2;
        }
        int i5 = i4 - 1;
        if (i4 == 0) {
            return 3;
        }
        return (this.filterCursor == null || i5 >= this.numPostFilters) ? 5 : 4;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewCustomFilter viewCustomFilter;
        ViewCustomFilter viewCustomFilter2;
        int itemViewType = getItemViewType(i);
        if (itemViewType == 0) {
            return this.inflater.inflate(R.layout.frag_global_header_prefilter, viewGroup, false);
        }
        if (itemViewType == 1) {
            if (view == null) {
                viewCustomFilter = (ViewCustomFilter) this.inflater.inflate(R.layout.view_listitem_custom_filter, (ViewGroup) null);
                viewCustomFilter.setListener(this.preFilterListener);
                viewCustomFilter.setOnClickListener(this.preFilterOnClickListener);
            } else {
                viewCustomFilter = (ViewCustomFilter) view;
            }
            this.filterCursor.moveToPosition(i - 1);
            bindViewPreFilter(viewCustomFilter, this.filterCursor);
            return viewCustomFilter;
        }
        if (itemViewType == 2) {
            if (view != null) {
                return view;
            }
            View viewInflate = this.inflater.inflate(R.layout.listitem_rule_add_pre_filter, (ViewGroup) null);
            viewInflate.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterGlobal.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (AdapterGlobal.this.listener != null) {
                        AdapterGlobal.this.listener.onNewPreFilterClicked();
                    }
                }
            });
            return viewInflate;
        }
        if (itemViewType == 3) {
            return this.inflater.inflate(R.layout.frag_global_header_postfilter, viewGroup, false);
        }
        if (itemViewType != 4) {
            if (itemViewType != 5) {
                throw new RuntimeException("unknown VIEW_TYPE");
            }
            if (view != null) {
                return view;
            }
            View viewInflate2 = this.inflater.inflate(R.layout.listitem_rule_add_post_filter, (ViewGroup) null);
            viewInflate2.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.AdapterGlobal.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view2) {
                    if (AdapterGlobal.this.listener != null) {
                        AdapterGlobal.this.listener.onNewPostFilterClicked();
                    }
                }
            });
            return viewInflate2;
        }
        if (view == null) {
            viewCustomFilter2 = (ViewCustomFilter) this.inflater.inflate(R.layout.view_listitem_custom_filter, (ViewGroup) null);
            viewCustomFilter2.setListener(this.postFilterListener);
            viewCustomFilter2.setOnClickListener(this.postFilterOnClickListener);
        } else {
            viewCustomFilter2 = (ViewCustomFilter) view;
        }
        this.filterCursor.moveToPosition(i - 3);
        bindViewPostFilter(viewCustomFilter2, this.filterCursor);
        return viewCustomFilter2;
    }

    public void bindViewPreFilter(ViewCustomFilter viewCustomFilter, Cursor cursor) {
        viewCustomFilter.setModel(new ModelCustomFilter(cursor.getLong(this.colFilterFilterRuleId), cursor.getString(this.colFilterServerStr), cursor.getInt(this.colFilterServerStrType), cursor.getInt(this.colFilterServerPort), cursor.getInt(this.colFilterProfile0FilterType), cursor.getInt(this.colFilterProfile1FilterType)));
    }

    public void bindViewPostFilter(ViewCustomFilter viewCustomFilter, Cursor cursor) {
        viewCustomFilter.setModel(new ModelCustomFilter(cursor.getLong(this.colFilterFilterRuleId), cursor.getString(this.colFilterServerStr), cursor.getInt(this.colFilterServerStrType), cursor.getInt(this.colFilterServerPort), cursor.getInt(this.colFilterProfile0FilterType), cursor.getInt(this.colFilterProfile1FilterType)));
    }
}
