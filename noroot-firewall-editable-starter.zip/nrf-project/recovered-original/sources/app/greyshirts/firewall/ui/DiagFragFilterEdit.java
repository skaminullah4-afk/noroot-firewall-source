package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.MyVpnService;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.app.log.AccessLogEntry;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public class DiagFragFilterEdit extends DialogFragment {
    private int appUid;
    private long filterId;
    private String leaderAppName;
    private AllowDenyCheckbox.CheckState mobileState;
    private long pendingId;
    private PackageNames pkgs;
    private int serverPort;
    private String serverStr;
    EditText viewAddress;
    View viewAddressDropdown;
    View viewAddressError;
    View viewCancel;
    AllowDenyCheckbox viewCheckMobile;
    AllowDenyCheckbox viewCheckWifi;
    View viewCreate;
    EditText viewPort;
    View viewPortDropdown;
    View viewPortError;
    TextView viewTitle;
    View viewTitleDropDown;
    private AllowDenyCheckbox.CheckState wifiState;
    private EditMode editMode = EditMode.MODE_NONE;
    private final ArrayList<EditMode> availableEditMode = new ArrayList<>();
    private final ArrayList<String> dropDownList = new ArrayList<>();
    private final View.OnClickListener onAddressDropdownClicked = new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.8
        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (DiagFragFilterEdit.this.dropDownList.size() == 0) {
                return;
            }
            PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
            Menu menu = popupMenu.getMenu();
            Iterator it = DiagFragFilterEdit.this.dropDownList.iterator();
            while (it.hasNext()) {
                menu.add(0, 0, 0, (String) it.next());
            }
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.8.1
                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                public boolean onMenuItemClick(MenuItem menuItem) {
                    DiagFragFilterEdit.this.viewAddress.setText(menuItem.getTitle().toString());
                    DiagFragFilterEdit.this.updateView();
                    return true;
                }
            });
            popupMenu.show();
        }
    };
    private final View.OnClickListener onPortDropdownClicked = new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.9
        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            PopupMenu popupMenu = new PopupMenu(view.getContext(), view);
            Menu menu = popupMenu.getMenu();
            if (DiagFragFilterEdit.this.serverPort != -1 && DiagFragFilterEdit.this.serverPort != 99999) {
                menu.add(0, 0, 0, String.valueOf(DiagFragFilterEdit.this.serverPort));
            }
            menu.add(0, 0, 0, "*");
            popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.9.1
                @Override // android.widget.PopupMenu.OnMenuItemClickListener
                public boolean onMenuItemClick(MenuItem menuItem) {
                    DiagFragFilterEdit.this.viewPort.setText(menuItem.getTitle().toString());
                    DiagFragFilterEdit.this.updateView();
                    return true;
                }
            });
            popupMenu.show();
        }
    };

    private enum EditMode {
        MODE_NONE,
        MODE_APP_CUSTOM_MODIFY,
        MODE_APP_CUSTOM_NEW,
        MODE_PRE_MODIFY,
        MODE_PRE_NEW,
        MODE_POST_MODIFY,
        MODE_POST_NEW
    }

    public static DiagFragFilterEdit newInstanceNewAppCustomFilter(ModelPendingAccess modelPendingAccess) {
        DiagFragFilterEdit diagFragFilterEdit = new DiagFragFilterEdit();
        EditMode editMode = EditMode.MODE_APP_CUSTOM_NEW;
        diagFragFilterEdit.editMode = editMode;
        diagFragFilterEdit.availableEditMode.add(editMode);
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_PRE_NEW);
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_POST_NEW);
        AllowDenyCheckbox.CheckState checkState = AllowDenyCheckbox.CheckState.CUSTOM;
        diagFragFilterEdit.wifiState = checkState;
        diagFragFilterEdit.mobileState = checkState;
        if (!TextUtils.isEmpty(modelPendingAccess.serverHost)) {
            diagFragFilterEdit.serverStr = modelPendingAccess.serverHost;
        } else {
            diagFragFilterEdit.serverStr = modelPendingAccess.serverIp;
        }
        diagFragFilterEdit.serverPort = modelPendingAccess.serverPort;
        diagFragFilterEdit.leaderAppName = modelPendingAccess.leaderAppName;
        diagFragFilterEdit.pkgs = modelPendingAccess.pkgs;
        diagFragFilterEdit.appUid = modelPendingAccess.appUid;
        diagFragFilterEdit.pendingId = modelPendingAccess._id;
        ServerStrUtil serverStrUtil = ServerStrUtil.parse(modelPendingAccess.serverHost);
        if (serverStrUtil.isValid() && serverStrUtil.isHostname()) {
            diagFragFilterEdit.dropDownList.addAll(serverStrUtil.makeHostnameWildcard());
        }
        ServerStrUtil serverStrUtil2 = ServerStrUtil.parse(modelPendingAccess.serverIp);
        if (serverStrUtil2.isValid() && serverStrUtil2.isIp()) {
            diagFragFilterEdit.dropDownList.addAll(serverStrUtil2.makeIpWildcard());
        }
        return diagFragFilterEdit;
    }

    public static DiagFragFilterEdit newInstanceNewAppCustomFilter(ModelGroup modelGroup) {
        DiagFragFilterEdit diagFragFilterEdit = new DiagFragFilterEdit();
        EditMode editMode = EditMode.MODE_APP_CUSTOM_NEW;
        diagFragFilterEdit.editMode = editMode;
        diagFragFilterEdit.availableEditMode.add(editMode);
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_PRE_NEW);
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_POST_NEW);
        AllowDenyCheckbox.CheckState checkState = AllowDenyCheckbox.CheckState.CUSTOM;
        diagFragFilterEdit.wifiState = checkState;
        diagFragFilterEdit.mobileState = checkState;
        diagFragFilterEdit.serverStr = "";
        diagFragFilterEdit.serverPort = 99999;
        diagFragFilterEdit.leaderAppName = modelGroup.leaderAppName;
        diagFragFilterEdit.pkgs = modelGroup.pkgs;
        diagFragFilterEdit.appUid = 0;
        diagFragFilterEdit.dropDownList.add("*");
        return diagFragFilterEdit;
    }

    public static DiagFragFilterEdit newInstanceNewPreFilter() {
        DiagFragFilterEdit diagFragFilterEdit = new DiagFragFilterEdit();
        EditMode editMode = EditMode.MODE_PRE_NEW;
        diagFragFilterEdit.editMode = editMode;
        diagFragFilterEdit.availableEditMode.add(editMode);
        AllowDenyCheckbox.CheckState checkState = AllowDenyCheckbox.CheckState.CUSTOM;
        diagFragFilterEdit.wifiState = checkState;
        diagFragFilterEdit.mobileState = checkState;
        diagFragFilterEdit.serverStr = "";
        diagFragFilterEdit.serverPort = 99999;
        diagFragFilterEdit.dropDownList.add("*");
        return diagFragFilterEdit;
    }

    public static DiagFragFilterEdit newInstanceNewPostFilter() {
        DiagFragFilterEdit diagFragFilterEdit = new DiagFragFilterEdit();
        EditMode editMode = EditMode.MODE_POST_NEW;
        diagFragFilterEdit.editMode = editMode;
        diagFragFilterEdit.availableEditMode.add(editMode);
        AllowDenyCheckbox.CheckState checkState = AllowDenyCheckbox.CheckState.CUSTOM;
        diagFragFilterEdit.wifiState = checkState;
        diagFragFilterEdit.mobileState = checkState;
        diagFragFilterEdit.serverStr = "";
        diagFragFilterEdit.serverPort = 99999;
        diagFragFilterEdit.dropDownList.add("*");
        return diagFragFilterEdit;
    }

    public static DiagFragFilterEdit newInstanceNewAppCustomFilter(AccessLogEntry accessLogEntry) {
        DiagFragFilterEdit diagFragFilterEdit = new DiagFragFilterEdit();
        EditMode editMode = EditMode.MODE_APP_CUSTOM_NEW;
        diagFragFilterEdit.editMode = editMode;
        diagFragFilterEdit.availableEditMode.add(editMode);
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_PRE_NEW);
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_POST_NEW);
        AllowDenyCheckbox.CheckState checkState = AllowDenyCheckbox.CheckState.CUSTOM;
        diagFragFilterEdit.wifiState = checkState;
        diagFragFilterEdit.mobileState = checkState;
        if (!TextUtils.isEmpty(accessLogEntry.getServerHost())) {
            diagFragFilterEdit.serverStr = accessLogEntry.getServerHost();
        } else {
            diagFragFilterEdit.serverStr = accessLogEntry.getServerIp();
        }
        diagFragFilterEdit.serverPort = accessLogEntry.getServerPort();
        diagFragFilterEdit.leaderAppName = accessLogEntry.getLeaderAppName();
        diagFragFilterEdit.pkgs = accessLogEntry.getPkgs();
        diagFragFilterEdit.appUid = accessLogEntry.getAppUid();
        ServerStrUtil serverStrUtil = ServerStrUtil.parse(accessLogEntry.getServerHost());
        if (serverStrUtil.isValid() && serverStrUtil.isHostname()) {
            diagFragFilterEdit.dropDownList.addAll(serverStrUtil.makeHostnameWildcard());
        }
        ServerStrUtil serverStrUtil2 = ServerStrUtil.parse(accessLogEntry.getServerIp());
        if (serverStrUtil2.isValid() && serverStrUtil2.isIp()) {
            diagFragFilterEdit.dropDownList.addAll(serverStrUtil2.makeIpWildcard());
        }
        return diagFragFilterEdit;
    }

    public static DiagFragFilterEdit newInstanceModifyAppCustomFilter(ModelCustomFilter modelCustomFilter) {
        return _newInstanceModifyFilterCommon(modelCustomFilter, EditMode.MODE_APP_CUSTOM_MODIFY);
    }

    public static DiagFragFilterEdit newInstanceModifyPreFilter(ModelCustomFilter modelCustomFilter) {
        return _newInstanceModifyFilterCommon(modelCustomFilter, EditMode.MODE_PRE_MODIFY);
    }

    public static DiagFragFilterEdit newInstanceModifyPostFilter(ModelCustomFilter modelCustomFilter) {
        return _newInstanceModifyFilterCommon(modelCustomFilter, EditMode.MODE_POST_MODIFY);
    }

    private static DiagFragFilterEdit _newInstanceModifyFilterCommon(ModelCustomFilter modelCustomFilter, EditMode editMode) {
        DiagFragFilterEdit diagFragFilterEdit = new DiagFragFilterEdit();
        diagFragFilterEdit.editMode = editMode;
        int i = AnonymousClass10.$SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[editMode.ordinal()];
        if (i == 1) {
            diagFragFilterEdit.availableEditMode.add(EditMode.MODE_APP_CUSTOM_MODIFY);
        } else if (i == 2) {
            diagFragFilterEdit.availableEditMode.add(EditMode.MODE_PRE_MODIFY);
        } else if (i == 3) {
            diagFragFilterEdit.availableEditMode.add(EditMode.MODE_POST_MODIFY);
        }
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_PRE_NEW);
        diagFragFilterEdit.availableEditMode.add(EditMode.MODE_POST_NEW);
        diagFragFilterEdit.wifiState = filterTypeToCheckState(modelCustomFilter.filterType0);
        diagFragFilterEdit.mobileState = filterTypeToCheckState(modelCustomFilter.filterType1);
        String str = modelCustomFilter.serverStr;
        diagFragFilterEdit.serverStr = str;
        diagFragFilterEdit.serverPort = modelCustomFilter.serverPort;
        diagFragFilterEdit.filterId = modelCustomFilter.filterRuleId;
        ServerStrUtil serverStrUtil = ServerStrUtil.parse(str);
        if (serverStrUtil.isValid()) {
            diagFragFilterEdit.dropDownList.add(serverStrUtil.str);
        }
        if (!diagFragFilterEdit.dropDownList.contains("*")) {
            diagFragFilterEdit.dropDownList.add("*");
        }
        return diagFragFilterEdit;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        if (this.editMode == EditMode.MODE_NONE) {
            return builder.create();
        }
        View viewNewView = newView();
        this.viewTitle = (TextView) viewNewView.findViewById(R.id.alertTitle);
        this.viewTitleDropDown = viewNewView.findViewById(R.id.titleDropDown);
        if (this.availableEditMode.size() > 1) {
            this.viewTitle.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.1
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    DiagFragFilterEdit.this.showEditModePopup();
                }
            });
            this.viewTitleDropDown.setVisibility(0);
            this.viewTitleDropDown.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.2
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    DiagFragFilterEdit.this.showEditModePopup();
                }
            });
        } else {
            this.viewTitleDropDown.setVisibility(8);
        }
        this.viewTitle.setText(editModeToStringRes(this.editMode));
        builder.setView(viewNewView);
        return builder.create();
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        if (this.editMode == EditMode.MODE_NONE) {
            dismiss();
        } else {
            updateView();
        }
    }

    private View newView() {
        View viewInflate = getActivity().getLayoutInflater().inflate(R.layout.diag_filter_edit, (ViewGroup) null);
        this.viewCheckWifi = (AllowDenyCheckbox) viewInflate.findViewById(R.id.checkWifi);
        this.viewCheckMobile = (AllowDenyCheckbox) viewInflate.findViewById(R.id.checkMobile);
        this.viewAddress = (EditText) viewInflate.findViewById(R.id.address);
        this.viewPort = (EditText) viewInflate.findViewById(R.id.port);
        this.viewAddressError = viewInflate.findViewById(R.id.addressError);
        this.viewPortError = viewInflate.findViewById(R.id.portError);
        this.viewAddressDropdown = viewInflate.findViewById(R.id.addressDropDown);
        this.viewPortDropdown = viewInflate.findViewById(R.id.portDropDown);
        this.viewCancel = viewInflate.findViewById(R.id.cancel);
        this.viewCreate = viewInflate.findViewById(R.id.create);
        this.viewCheckWifi.bindData(this.wifiState, false, false);
        this.viewCheckMobile.bindData(this.mobileState, false, false);
        this.viewAddress.setText(this.serverStr);
        int i = this.serverPort;
        if (i == -1) {
            this.viewPort.setText("*");
        } else if (i == 99999) {
            this.viewPort.setText("");
        } else {
            this.viewPort.setText(String.valueOf(i));
        }
        this.viewAddress.addTextChangedListener(new TextWatcher() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.3
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                DiagFragFilterEdit.this.updateView();
            }
        });
        this.viewPort.addTextChangedListener(new TextWatcher() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.4
            @Override // android.text.TextWatcher
            public void beforeTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override // android.text.TextWatcher
            public void onTextChanged(CharSequence charSequence, int i2, int i3, int i4) {
            }

            @Override // android.text.TextWatcher
            public void afterTextChanged(Editable editable) {
                DiagFragFilterEdit.this.updateView();
            }
        });
        this.viewAddressDropdown.setOnClickListener(this.onAddressDropdownClicked);
        this.viewPortDropdown.setOnClickListener(this.onPortDropdownClicked);
        this.viewCancel.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DiagFragFilterEdit.this.dismiss();
            }
        });
        this.viewCreate.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DiagFragFilterEdit.this.setFilterToDb();
                DiagFragFilterEdit.this.dismiss();
            }
        });
        return viewInflate;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showEditModePopup() {
        PopupMenu popupMenu = new PopupMenu(getActivity(), this.viewTitle);
        Menu menu = popupMenu.getMenu();
        for (int i = 0; i < this.availableEditMode.size(); i++) {
            menu.add(0, 0, i, editModeToStringRes(this.availableEditMode.get(i)));
        }
        popupMenu.show();
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragFilterEdit.7
            @Override // android.widget.PopupMenu.OnMenuItemClickListener
            public boolean onMenuItemClick(MenuItem menuItem) {
                int order = menuItem.getOrder();
                DiagFragFilterEdit diagFragFilterEdit = DiagFragFilterEdit.this;
                diagFragFilterEdit.editMode = (EditMode) diagFragFilterEdit.availableEditMode.get(order);
                DiagFragFilterEdit diagFragFilterEdit2 = DiagFragFilterEdit.this;
                diagFragFilterEdit2.viewTitle.setText(diagFragFilterEdit2.editModeToStringRes(diagFragFilterEdit2.editMode));
                return true;
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int editModeToStringRes(EditMode editMode) {
        switch (AnonymousClass10.$SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[editMode.ordinal()]) {
            case 1:
                return R.string.filter_edit_title_custom_filter_modify;
            case 2:
                return R.string.filter_edit_title_pre_filter_modify;
            case 3:
                return R.string.filter_edit_title_post_filter_modify;
            case 4:
                return R.string.filter_edit_title_custom_filter_new;
            case 5:
                return R.string.filter_edit_title_pre_filter_new;
            case 6:
                return R.string.filter_edit_title_post_filter_new;
            default:
                throw new RuntimeException("unknown edit mode");
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public boolean updateView() {
        boolean z;
        if (ServerStrUtil.parse(this.viewAddress.getText().toString()).isValid()) {
            this.viewAddressError.setVisibility(4);
            z = true;
        } else {
            if (TextUtils.isEmpty(this.viewAddress.getText().toString())) {
                this.viewAddressError.setVisibility(4);
            } else {
                this.viewAddressError.setVisibility(0);
            }
            z = false;
        }
        if (checkPort(this.viewPort.getText().toString())) {
            this.viewPortError.setVisibility(4);
        } else {
            if (TextUtils.isEmpty(this.viewPort.getText().toString())) {
                this.viewPortError.setVisibility(4);
            } else {
                this.viewPortError.setVisibility(0);
            }
            z = false;
        }
        this.viewCreate.setEnabled(z);
        return z;
    }

    private boolean checkPort(String str) {
        if (TextUtils.isEmpty(str)) {
            return false;
        }
        if (str.equals("*")) {
            return true;
        }
        try {
            int iIntValue = Integer.valueOf(str).intValue();
            return iIntValue >= 0 && iIntValue <= 65535;
        } catch (Exception unused) {
            return false;
        }
    }

    private int getPort(String str) {
        if ("*".equals(str)) {
            return -1;
        }
        try {
            int iIntValue = Integer.valueOf(str).intValue();
            if (iIntValue < 0 || iIntValue > 65535) {
                return 0;
            }
            return iIntValue;
        } catch (Exception unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void setFilterToDb() {
        if (updateView()) {
            ServerStrUtil serverStrUtil = ServerStrUtil.parse(this.viewAddress.getText().toString());
            if (serverStrUtil.isValid()) {
                switch (AnonymousClass10.$SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[this.editMode.ordinal()]) {
                    case 1:
                    case 2:
                    case 3:
                        if (this.filterId > 0) {
                            Filter.getInstance(getActivity()).updateCustomFilter(this.filterId, checkStateToFilterType(this.viewCheckWifi.getCheckState()), checkStateToFilterType(this.viewCheckMobile.getCheckState()), serverStrUtil.str, !serverStrUtil.isIp() ? 1 : 0, getPort(this.viewPort.getText().toString()));
                        }
                        break;
                    case 4:
                        Filter.getInstance(getActivity()).addCustomFilter(checkStateToFilterType(this.viewCheckWifi.getCheckState()), checkStateToFilterType(this.viewCheckMobile.getCheckState()), serverStrUtil.str, !serverStrUtil.isIp() ? 1 : 0, getPort(this.viewPort.getText().toString()), this.leaderAppName, this.pkgs, this.appUid);
                        break;
                    case 5:
                        Filter.getInstance(getActivity()).addPreFilter(checkStateToFilterType(this.viewCheckWifi.getCheckState()), checkStateToFilterType(this.viewCheckMobile.getCheckState()), serverStrUtil.str, !serverStrUtil.isIp() ? 1 : 0, getPort(this.viewPort.getText().toString()));
                        break;
                    case 6:
                        Filter.getInstance(getActivity()).addPostFilter(checkStateToFilterType(this.viewCheckWifi.getCheckState()), checkStateToFilterType(this.viewCheckMobile.getCheckState()), serverStrUtil.str, !serverStrUtil.isIp() ? 1 : 0, getPort(this.viewPort.getText().toString()));
                        break;
                }
                if (this.pendingId > 0) {
                    Filter.getInstance(getActivity()).removePending(this.pendingId);
                }
                MyVpnService.notifyBlockingRuleChange(getActivity());
            }
        }
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.DiagFragFilterEdit$10, reason: invalid class name */
    static /* synthetic */ class AnonymousClass10 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode;
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState = new int[AllowDenyCheckbox.CheckState.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.ALLOW.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.DENY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode = new int[EditMode.values().length];
            try {
                $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[EditMode.MODE_APP_CUSTOM_MODIFY.ordinal()] = 1;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[EditMode.MODE_PRE_MODIFY.ordinal()] = 2;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[EditMode.MODE_POST_MODIFY.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[EditMode.MODE_APP_CUSTOM_NEW.ordinal()] = 4;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[EditMode.MODE_PRE_NEW.ordinal()] = 5;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$DiagFragFilterEdit$EditMode[EditMode.MODE_POST_NEW.ordinal()] = 6;
            } catch (NoSuchFieldError unused9) {
            }
        }
    }

    private static int checkStateToFilterType(AllowDenyCheckbox.CheckState checkState) {
        int i = AnonymousClass10.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[checkState.ordinal()];
        int i2 = 1;
        if (i != 1) {
            i2 = 2;
            if (i != 2) {
                return 0;
            }
        }
        return i2;
    }

    private static AllowDenyCheckbox.CheckState filterTypeToCheckState(int i) {
        if (i == 1) {
            return AllowDenyCheckbox.CheckState.ALLOW;
        }
        if (i == 2) {
            return AllowDenyCheckbox.CheckState.DENY;
        }
        return AllowDenyCheckbox.CheckState.CUSTOM;
    }
}
