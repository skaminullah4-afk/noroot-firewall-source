package app.greyshirts.firewall.ui;

import app.greyshirts.firewall.app.PackageNames;

/* JADX INFO: loaded from: classes.dex */
public class ModelGroup {
    public final String groupName;
    public final boolean hasAllow0;
    public final boolean hasAllow1;
    public final boolean hasDeny0;
    public final boolean hasDeny1;
    public final int install;
    public final String leaderAppName;
    public final String leaderPkgName;
    public final PackageNames pkgs;
    public final int policy0;
    public final int policy1;

    public ModelGroup(String str, String str2, PackageNames packageNames, String str3, int i, boolean z, boolean z2, int i2, boolean z3, boolean z4, int i3) {
        this.groupName = str;
        this.leaderAppName = str2;
        this.pkgs = packageNames;
        this.leaderPkgName = str3;
        this.install = i;
        this.hasAllow0 = z;
        this.hasDeny0 = z2;
        this.policy0 = i2;
        this.hasAllow1 = z3;
        this.hasDeny1 = z4;
        this.policy1 = i3;
    }
}
