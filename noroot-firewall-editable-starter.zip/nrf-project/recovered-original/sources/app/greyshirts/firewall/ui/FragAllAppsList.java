package app.greyshirts.firewall.ui;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.ListView;
import androidx.fragment.app.Fragment;
import androidx.loader.app.LoaderManager;
import androidx.loader.content.CursorLoader;
import androidx.loader.content.Loader;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.AppInfo;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.MyVpnService;
import app.greyshirts.firewall.db.CombinedDataContract;
import app.greyshirts.firewall.db.UidGroupList;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;

/* JADX INFO: loaded from: classes.dex */
public class FragAllAppsList extends Fragment {
    private AdapterAllApps adapter;
    private Filter filter;
    private final LoaderManager.LoaderCallbacks<Cursor> loaderCallbacks = new LoaderManager.LoaderCallbacks<Cursor>() { // from class: app.greyshirts.firewall.ui.FragAllAppsList.1
        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public Loader<Cursor> onCreateLoader(int i, Bundle bundle) {
            return new CursorLoader(FragAllAppsList.this.getActivity(), CombinedDataContract.getInstance(FragAllAppsList.this.getActivity()).getContentUri(), null, null, null, null);
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoadFinished(Loader<Cursor> loader, Cursor cursor) {
            FragAllAppsList.this.adapter.changeCursor(cursor);
            FragAllAppsList.this.updateView();
        }

        @Override // androidx.loader.app.LoaderManager.LoaderCallbacks
        public void onLoaderReset(Loader<Cursor> loader) {
            FragAllAppsList.this.adapter.changeCursor(null);
            FragAllAppsList.this.updateView();
        }
    };
    private final AdapterAllApps.OnGroupClickedListener onGroupClicked = new AdapterAllApps.OnGroupClickedListener() { // from class: app.greyshirts.firewall.ui.FragAllAppsList.2
        @Override // app.greyshirts.firewall.ui.AdapterAllApps.OnGroupClickedListener
        public void onGroupClicked(ModelGroup modelGroup) {
            Intent intent = new Intent(FragAllAppsList.this.getActivity(), (Class<?>) ActivityAppDetail.class);
            intent.putExtra("extra.pkgs", modelGroup.pkgs.getCommaJoinedString());
            intent.putExtra("extra.leaderName", modelGroup.leaderAppName);
            FragAllAppsList.this.startActivity(intent);
        }
    };
    private final AdapterAllApps.OnPolicyClickedListener onPolicyClicked = new AdapterAllApps.OnPolicyClickedListener() { // from class: app.greyshirts.firewall.ui.FragAllAppsList.3
        @Override // app.greyshirts.firewall.ui.AdapterAllApps.OnPolicyClickedListener
        public void onPolicyClicked(Filter.Profile profile, ModelGroup modelGroup, AllowDenyCheckbox.CheckState checkState) {
            Filter.Type type;
            int i = AnonymousClass4.$SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[checkState.ordinal()];
            if (i == 1) {
                type = Filter.Type.POLICY_ALLOW;
            } else if (i == 2) {
                type = Filter.Type.POLICY_DENY;
            } else {
                type = Filter.Type.POLICY_CUSTOM;
            }
            FragAllAppsList.this.filter.setPolicyRule(profile, modelGroup.leaderAppName, modelGroup.pkgs, type);
            MyVpnService.notifyBlockingRuleChange(FragAllAppsList.this.getActivity());
        }
    };
    private ListView viewList;
    private View viewProgress;

    @Override // androidx.fragment.app.Fragment
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setHasOptionsMenu(true);
        this.adapter = new AdapterAllApps(getActivity());
        this.adapter.setOnGroupClickedListener(this.onGroupClicked);
        this.adapter.setOnPolicyClickedListener(this.onPolicyClicked);
        this.filter = Filter.getInstance(getActivity());
    }

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_filterlist, viewGroup, false);
        this.viewProgress = viewInflate.findViewById(R.id.progressBar);
        this.viewList = (ListView) viewInflate.findViewById(R.id.list);
        this.viewList.setAdapter((ListAdapter) this.adapter);
        this.viewList.setDivider(null);
        return viewInflate;
    }

    @Override // androidx.fragment.app.Fragment
    public void onDestroyView() {
        super.onDestroyView();
        this.viewList.setAdapter((ListAdapter) null);
        this.viewList = null;
    }

    @Override // androidx.fragment.app.Fragment
    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        getLoaderManager().initLoader(0, null, this.loaderCallbacks);
    }

    @Override // androidx.fragment.app.Fragment
    public void onResume() {
        super.onResume();
        updateView();
    }

    @Override // androidx.fragment.app.Fragment
    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        menuInflater.inflate(R.menu.frag_filter, menu);
    }

    @Override // androidx.fragment.app.Fragment
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == R.id.clear) {
            getActivity().getContentResolver().call(CombinedDataContract.getInstance(getActivity()).getContentUri(), "deleteUninstalled", (String) null, (Bundle) null);
        } else if (itemId == R.id.refresh) {
            UidGroupList.clearPackageCache();
            AppInfo.clearIconCache();
            this.adapter.changeCursor(null);
            updateView();
            getLoaderManager().restartLoader(0, null, this.loaderCallbacks);
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void updateView() {
        if (this.adapter.getCount() == 0) {
            this.viewProgress.setVisibility(0);
        } else {
            this.viewProgress.setVisibility(8);
        }
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.ui.FragAllAppsList$4, reason: invalid class name */
    static /* synthetic */ class AnonymousClass4 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState = new int[AllowDenyCheckbox.CheckState.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.ALLOW.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.DENY.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$ui$widget$AllowDenyCheckbox$CheckState[AllowDenyCheckbox.CheckState.CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
        }
    }
}
