package app.greyshirts.firewall.ui;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.db.FilterRuleContract;
import app.greyshirts.firewall.ui.widget.AllowDenyCheckbox;
import java.util.ArrayList;
import java.util.HashSet;

/* JADX INFO: loaded from: classes.dex */
class AdapterAppDetail extends BaseAdapter {
    private int colFilterFilterRuleId;
    private int colFilterProfile0FilterType;
    private int colFilterProfile1FilterType;
    private int colFilterServerPort;
    private int colFilterServerStr;
    private int colFilterServerStrType;
    private int colPendingAllAppName;
    private int colPendingAppUid;
    private int colPendingCreatedDate;
    private int colPendingId;
    private int colPendingLeaderAppName;
    private int colPendingPkg1;
    private int colPendingPkg2;
    private int colPendingPkg3;
    private int colPendingServerIp;
    private int colPendingServerPort;
    private int colPendingSeverHost;
    private final ContentResolver cr;
    private final Context ctx;
    private Cursor customFilterCursor;
    private final LayoutInflater inflater;
    private OnCustomFilterCheckStateChangedListener onCustomFilterCheckStateChangedListener;
    private OnRuleDeletedListener onRuleDeletedListener;
    private Cursor pendingAccessCursor;
    private final Uri uri;
    private HashSet<Long> selectedFilterIds = new HashSet<>();
    private HashSet<Long> selectedPendingIds = new HashSet<>();
    private final ViewCustomFilter.Listener customFilterListener = new ViewCustomFilter.Listener() { // from class: app.greyshirts.firewall.ui.AdapterAppDetail.1
        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onDeleteClicked(ModelCustomFilter modelCustomFilter) {
            if (modelCustomFilter != null) {
                AdapterAppDetail.this.cr.delete(AdapterAppDetail.this.uri, "_id=?", new String[]{String.valueOf(modelCustomFilter.filterRuleId)});
                AdapterAppDetail.this.onRuleDeletedListener.onRuleDeleted();
            }
        }

        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onWifiCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState) {
            if (AdapterAppDetail.this.onCustomFilterCheckStateChangedListener == null) {
                return;
            }
            AdapterAppDetail.this.onCustomFilterCheckStateChangedListener.onCustomFilterChanged(modelCustomFilter.filterRuleId, Filter.Profile.PROFILE_WIFI, checkState);
        }

        @Override // app.greyshirts.firewall.ui.ViewCustomFilter.Listener
        public void onMobileCheckStateChanged(ModelCustomFilter modelCustomFilter, AllowDenyCheckbox.CheckState checkState) {
            if (AdapterAppDetail.this.onCustomFilterCheckStateChangedListener == null) {
                return;
            }
            AdapterAppDetail.this.onCustomFilterCheckStateChangedListener.onCustomFilterChanged(modelCustomFilter.filterRuleId, Filter.Profile.PROFILE_MOBILE, checkState);
        }
    };
    private final ViewPendingAccess.Listener pendingAccessListener = new ViewPendingAccess.Listener() { // from class: app.greyshirts.firewall.ui.AdapterAppDetail.2
        @Override // app.greyshirts.firewall.ui.ViewPendingAccess.Listener
        public void onDeleteClicked(ModelPendingAccess modelPendingAccess) {
            Filter.getInstance(AdapterAppDetail.this.ctx).removePending(modelPendingAccess._id);
        }
    };

    public interface OnCustomFilterCheckStateChangedListener {
        void onCustomFilterChanged(long j, Filter.Profile profile, AllowDenyCheckbox.CheckState checkState);
    }

    public interface OnRuleDeletedListener {
        void onRuleDeleted();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return null;
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return 0L;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return 2;
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int i) {
        return true;
    }

    public AdapterAppDetail(Context context) {
        this.ctx = context.getApplicationContext();
        this.inflater = LayoutInflater.from(context);
        this.cr = context.getContentResolver();
        this.uri = FilterRuleContract.getInstance(context).getContentUri();
    }

    public void setOnCustomFilterCheckStateChangedListener(OnCustomFilterCheckStateChangedListener onCustomFilterCheckStateChangedListener) {
        this.onCustomFilterCheckStateChangedListener = onCustomFilterCheckStateChangedListener;
    }

    public void setOnRuleDeletedListener(OnRuleDeletedListener onRuleDeletedListener) {
        this.onRuleDeletedListener = onRuleDeletedListener;
    }

    public Cursor swapCustomFilterCursor(Cursor cursor) {
        if (cursor != null) {
            this.colFilterServerStr = cursor.getColumnIndexOrThrow("serverStr");
            this.colFilterServerStrType = cursor.getColumnIndexOrThrow("serverStrType");
            this.colFilterServerPort = cursor.getColumnIndexOrThrow("serverPort");
            this.colFilterProfile0FilterType = cursor.getColumnIndexOrThrow("type0");
            this.colFilterProfile1FilterType = cursor.getColumnIndexOrThrow("type1");
            this.colFilterFilterRuleId = cursor.getColumnIndexOrThrow("filterRuleId");
        }
        Cursor cursor2 = this.customFilterCursor;
        if (cursor2 != null && cursor2 != cursor) {
            cursor2.close();
        }
        this.customFilterCursor = cursor;
        notifyDataSetChanged();
        return this.customFilterCursor;
    }

    public Cursor swapPendingAccessCursor(Cursor cursor) {
        if (cursor != null) {
            this.colPendingId = cursor.getColumnIndexOrThrow("_id");
            this.colPendingServerIp = cursor.getColumnIndexOrThrow("serverIp");
            this.colPendingSeverHost = cursor.getColumnIndexOrThrow("serverHost");
            this.colPendingServerPort = cursor.getColumnIndexOrThrow("serverPort");
            this.colPendingAppUid = cursor.getColumnIndexOrThrow("appUid");
            this.colPendingAllAppName = cursor.getColumnIndexOrThrow("allAppName");
            this.colPendingLeaderAppName = cursor.getColumnIndexOrThrow("appName");
            this.colPendingCreatedDate = cursor.getColumnIndexOrThrow("createdData");
            this.colPendingPkg1 = cursor.getColumnIndexOrThrow("pkgName");
            this.colPendingPkg2 = cursor.getColumnIndexOrThrow("pkg2Name");
            this.colPendingPkg3 = cursor.getColumnIndexOrThrow("pkg3Name");
        }
        Cursor cursor2 = this.pendingAccessCursor;
        if (cursor2 != null && cursor2 != cursor) {
            cursor2.close();
        }
        this.pendingAccessCursor = cursor;
        notifyDataSetChanged();
        return this.pendingAccessCursor;
    }

    public void setSelectedIds(HashSet<Long> hashSet, HashSet<Long> hashSet2) {
        this.selectedFilterIds = hashSet;
        this.selectedPendingIds = hashSet2;
        notifyDataSetChanged();
    }

    private boolean isInSelectionMode() {
        HashSet<Long> hashSet = this.selectedFilterIds;
        if (hashSet != null && hashSet.size() != 0) {
            return true;
        }
        HashSet<Long> hashSet2 = this.selectedPendingIds;
        return (hashSet2 == null || hashSet2.size() == 0) ? false : true;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        Cursor cursor = this.customFilterCursor;
        int count = (cursor != null ? cursor.getCount() : 0) + 0;
        Cursor cursor2 = this.pendingAccessCursor;
        return count + (cursor2 != null ? cursor2.getCount() : 0);
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int i) {
        Cursor cursor = this.customFilterCursor;
        return (cursor == null || i < cursor.getCount()) ? 0 : 1;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewPendingAccess viewPendingAccess;
        ViewCustomFilter viewCustomFilter;
        if (getItemViewType(i) == 0) {
            if (view == null) {
                viewCustomFilter = (ViewCustomFilter) this.inflater.inflate(R.layout.view_listitem_custom_filter, (ViewGroup) null);
                viewCustomFilter.setListener(this.customFilterListener);
            } else {
                viewCustomFilter = (ViewCustomFilter) view;
            }
            this.customFilterCursor.moveToPosition(i);
            bindViewCustomFilter(viewCustomFilter, this.customFilterCursor);
            return viewCustomFilter;
        }
        if (view == null) {
            viewPendingAccess = (ViewPendingAccess) this.inflater.inflate(R.layout.view_listitem_pending, (ViewGroup) null);
            viewPendingAccess.setListener(this.pendingAccessListener);
        } else {
            viewPendingAccess = (ViewPendingAccess) view;
        }
        Cursor cursor = this.pendingAccessCursor;
        Cursor cursor2 = this.customFilterCursor;
        cursor.moveToPosition(i - (cursor2 != null ? cursor2.getCount() : 0));
        bindViewPendingAccess(viewPendingAccess, this.pendingAccessCursor);
        return viewPendingAccess;
    }

    public void bindViewCustomFilter(ViewCustomFilter viewCustomFilter, Cursor cursor) {
        String string = cursor.getString(this.colFilterServerStr);
        int i = cursor.getInt(this.colFilterServerStrType);
        int i2 = cursor.getInt(this.colFilterServerPort);
        int i3 = cursor.getInt(this.colFilterProfile0FilterType);
        int i4 = cursor.getInt(this.colFilterProfile1FilterType);
        long j = cursor.getLong(this.colFilterFilterRuleId);
        viewCustomFilter.setModel(new ModelCustomFilter(j, string, i, i2, i3, i4));
        if (isInSelectionMode() && this.selectedFilterIds.contains(Long.valueOf(j))) {
            viewCustomFilter.setActivated(true);
        } else {
            viewCustomFilter.setActivated(false);
        }
    }

    public void bindViewPendingAccess(ViewPendingAccess viewPendingAccess, Cursor cursor) {
        long j = cursor.getLong(this.colPendingId);
        String string = cursor.getString(this.colPendingServerIp);
        String string2 = cursor.getString(this.colPendingSeverHost);
        int i = cursor.getInt(this.colPendingServerPort);
        int i2 = cursor.getInt(this.colPendingAppUid);
        String string3 = cursor.getString(this.colPendingAllAppName);
        String string4 = cursor.getString(this.colPendingLeaderAppName);
        long j2 = cursor.getLong(this.colPendingCreatedDate);
        ArrayList arrayList = new ArrayList();
        String string5 = cursor.getString(this.colPendingPkg1);
        if (!TextUtils.isEmpty(string5)) {
            arrayList.add(string5);
        }
        String string6 = cursor.getString(this.colPendingPkg2);
        if (!TextUtils.isEmpty(string6)) {
            arrayList.add(string6);
        }
        String string7 = cursor.getString(this.colPendingPkg3);
        if (!TextUtils.isEmpty(string7)) {
            arrayList.add(string7);
        }
        String[] strArr = new String[arrayList.size()];
        arrayList.toArray(strArr);
        viewPendingAccess.bindModel(new ModelPendingAccess(j, string, string2, i, i2, string3, string4, PackageNames.newInstance(strArr), j2));
        if (isInSelectionMode() && this.selectedPendingIds.contains(Long.valueOf(j))) {
            viewPendingAccess.setActivated(true);
        } else {
            viewPendingAccess.setActivated(false);
        }
    }
}
