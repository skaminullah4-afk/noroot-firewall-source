package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import app.greyshirts.firewall.R;

/* JADX INFO: loaded from: classes.dex */
public class DialogGlobalHelp extends DialogFragment {
    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        View viewInflate = LayoutInflater.from(getActivity()).inflate(R.layout.diag_global_help, (ViewGroup) null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(R.string.global_filters);
        builder.setIcon(R.drawable.global);
        builder.setView(viewInflate);
        builder.setPositiveButton("OK", (DialogInterface.OnClickListener) null);
        return builder.create();
    }
}
