package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.lock.LockManager;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.BuildersKt__Builders_commonKt;
import kotlinx.coroutines.CoroutineScope;
import kotlinx.coroutines.DelayKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.GlobalScope;

/* JADX INFO: compiled from: DiagFragPassCode.kt */
/* JADX INFO: loaded from: classes.dex */
public final class DiagFragPassCode extends DialogFragment {
    public LockManager lockManager;

    public final LockManager getLockManager() {
        LockManager lockManager = this.lockManager;
        if (lockManager != null) {
            return lockManager;
        }
        Intrinsics.throwUninitializedPropertyAccessException("lockManager");
        throw null;
    }

    @Override // androidx.fragment.app.DialogFragment
    public Dialog onCreateDialog(Bundle bundle) {
        LockManager.Companion companion = LockManager.Companion;
        Context context = getContext();
        if (context == null) {
            Intrinsics.throwNpe();
            throw null;
        }
        Intrinsics.checkExpressionValueIsNotNull(context, "context!!");
        this.lockManager = companion.getInstance(context);
        LockManager lockManager = this.lockManager;
        if (lockManager == null) {
            Intrinsics.throwUninitializedPropertyAccessException("lockManager");
            throw null;
        }
        boolean zIsLocked = lockManager.isLocked();
        View viewInflate = LayoutInflater.from(getContext()).inflate(R.layout.passcode, (ViewGroup) null);
        Context context2 = getContext();
        if (context2 != null) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context2);
            builder.setTitle(zIsLocked ? R.string.passcode_dialog_unlock_title : R.string.passcode_dialog_lock_title);
            builder.setView(viewInflate);
            builder.setCancelable(false);
            AlertDialog alertDialogCreate = builder.create();
            Intrinsics.checkExpressionValueIsNotNull(alertDialogCreate, "builder.create()");
            alertDialogCreate.setCanceledOnTouchOutside(false);
            alertDialogCreate.setCancelable(false);
            Window window = alertDialogCreate.getWindow();
            if (window != null) {
                window.setSoftInputMode(4);
            }
            View viewFindViewById = viewInflate.findViewById(R.id.passcode);
            if (viewFindViewById == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            final TextView textView = (TextView) viewFindViewById;
            View viewFindViewById2 = viewInflate.findViewById(R.id.lockButton);
            if (viewFindViewById2 == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            final Button button = (Button) viewFindViewById2;
            View viewFindViewById3 = viewInflate.findViewById(R.id.unlockButton);
            if (viewFindViewById3 == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            final Button button2 = (Button) viewFindViewById3;
            View viewFindViewById4 = viewInflate.findViewById(R.id.cancelButton);
            if (viewFindViewById4 == null) {
                Intrinsics.throwNpe();
                throw null;
            }
            final Button button3 = (Button) viewFindViewById4;
            button.setEnabled(false);
            textView.addTextChangedListener(new TextWatcher() { // from class: app.greyshirts.firewall.ui.DiagFragPassCode.onCreateDialog.1
                @Override // android.text.TextWatcher
                public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
                }

                @Override // android.text.TextWatcher
                public void afterTextChanged(Editable editable) {
                    button.setEnabled(textView.getText().length() != 0);
                }
            });
            if (zIsLocked) {
                button.setVisibility(8);
                button2.setVisibility(0);
            } else {
                button.setVisibility(0);
                button2.setVisibility(8);
            }
            button2.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragPassCode.onCreateDialog.2
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    if (DiagFragPassCode.this.getLockManager().isPassCodeValid(textView.getText().toString())) {
                        DiagFragPassCode.this.getLockManager().unlock();
                        DiagFragPassCode.this.dismiss();
                    } else {
                        button2.setEnabled(false);
                        button3.setEnabled(false);
                        BuildersKt__Builders_commonKt.launch$default(GlobalScope.INSTANCE, Dispatchers.getMain(), null, new AnonymousClass1(null), 2, null);
                    }
                }

                /* JADX INFO: renamed from: app.greyshirts.firewall.ui.DiagFragPassCode$onCreateDialog$2$1, reason: invalid class name */
                /* JADX INFO: compiled from: DiagFragPassCode.kt */
                @DebugMetadata(c = "app.greyshirts.firewall.ui.DiagFragPassCode$onCreateDialog$2$1", f = "DiagFragPassCode.kt", l = {82}, m = "invokeSuspend")
                static final class AnonymousClass1 extends SuspendLambda implements Function2<CoroutineScope, Continuation<? super Unit>, Object> {
                    Object L$0;
                    int label;
                    private CoroutineScope p$;

                    AnonymousClass1(Continuation continuation) {
                        super(2, continuation);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Continuation<Unit> create(Object obj, Continuation<?> completion) {
                        Intrinsics.checkParameterIsNotNull(completion, "completion");
                        AnonymousClass1 anonymousClass1 = AnonymousClass2.this.new AnonymousClass1(completion);
                        anonymousClass1.p$ = (CoroutineScope) obj;
                        return anonymousClass1;
                    }

                    @Override // kotlin.jvm.functions.Function2
                    public final Object invoke(CoroutineScope coroutineScope, Continuation<? super Unit> continuation) {
                        return ((AnonymousClass1) create(coroutineScope, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    @Override // kotlin.coroutines.jvm.internal.BaseContinuationImpl
                    public final Object invokeSuspend(Object obj) throws Throwable {
                        Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                        int i = this.label;
                        if (i == 0) {
                            ResultKt.throwOnFailure(obj);
                            this.L$0 = this.p$;
                            this.label = 1;
                            if (DelayKt.delay(2000L, this) == coroutine_suspended) {
                                return coroutine_suspended;
                            }
                        } else {
                            if (i != 1) {
                                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            }
                            ResultKt.throwOnFailure(obj);
                        }
                        TextView textView = textView;
                        TranslateAnimation translateAnimation = new TranslateAnimation(0.0f, 0.0f, 0.0f, 20.0f);
                        translateAnimation.setDuration(1000L);
                        translateAnimation.setInterpolator(new CycleInterpolator(7.0f));
                        textView.startAnimation(translateAnimation);
                        button2.setEnabled(false);
                        button3.setEnabled(true);
                        textView.setText("");
                        return Unit.INSTANCE;
                    }
                }
            });
            button.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragPassCode.onCreateDialog.3
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    String string = textView.getText().toString();
                    if (string.length() == 0) {
                        return;
                    }
                    DiagFragPassCode.this.getLockManager().lock(string);
                    DiagFragPassCode.this.dismiss();
                }
            });
            button3.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DiagFragPassCode.onCreateDialog.4
                @Override // android.view.View.OnClickListener
                public final void onClick(View view) {
                    DiagFragPassCode.this.dismiss();
                }
            });
            return alertDialogCreate;
        }
        Intrinsics.throwNpe();
        throw null;
    }
}
