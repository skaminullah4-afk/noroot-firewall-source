package app.greyshirts.firewall.ui.debug;

import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.fragment.app.Fragment;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.proxy.ProxyWorker;
import java.io.File;

/* JADX INFO: loaded from: classes.dex */
public class FragProxyWorker extends Fragment {
    private View viewLoggingDump;
    private View viewLoggingOff;
    private View viewLoggingOnLogcat;
    private View viewLoggingOnMemory;

    @Override // androidx.fragment.app.Fragment
    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View viewInflate = layoutInflater.inflate(R.layout.frag_proxy_worker, (ViewGroup) null);
        this.viewLoggingOff = viewInflate.findViewById(R.id.loggingOff);
        this.viewLoggingOnLogcat = viewInflate.findViewById(R.id.loggingOnLogcat);
        this.viewLoggingOnMemory = viewInflate.findViewById(R.id.loggingOnMemory);
        this.viewLoggingDump = viewInflate.findViewById(R.id.loggingDumpMemory);
        this.viewLoggingOff.setOnClickListener(new View.OnClickListener(this) { // from class: app.greyshirts.firewall.ui.debug.FragProxyWorker.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ProxyWorker.getInstance().setLogging(ProxyWorker.Logging.LOGGING_QUIET);
            }
        });
        this.viewLoggingOnLogcat.setOnClickListener(new View.OnClickListener(this) { // from class: app.greyshirts.firewall.ui.debug.FragProxyWorker.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ProxyWorker.getInstance().setLogging(ProxyWorker.Logging.LOGGING_LOGCAT);
            }
        });
        this.viewLoggingOnMemory.setOnClickListener(new View.OnClickListener(this) { // from class: app.greyshirts.firewall.ui.debug.FragProxyWorker.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ProxyWorker.getInstance().setLogging(ProxyWorker.Logging.LOGGING_MEMORY);
            }
        });
        this.viewLoggingDump.setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.debug.FragProxyWorker.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "dump.txt");
                ProxyWorker.getInstance().dumpMemoryLog(file.getAbsolutePath());
                Toast.makeText(FragProxyWorker.this.getActivity(), "log saved as " + file.getAbsolutePath(), 1).show();
            }
        });
        return viewInflate;
    }
}
