package app.greyshirts.firewall.ui;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.ui.widget.ActivityOpensource;

/* JADX INFO: loaded from: classes.dex */
public class DialogAbout {
    public static Dialog createAboutDialog(final Context context) {
        String str;
        View viewInflate = ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(R.layout.about, (ViewGroup) null);
        final String packageName = context.getPackageName();
        try {
            PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 128);
            str = packageInfo.versionName + " (build " + packageInfo.versionCode + ")";
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
            str = "unknown";
        }
        ((TextView) viewInflate.findViewById(R.id.version)).setText(str);
        viewInflate.findViewById(R.id.opensource).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DialogAbout.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                context.startActivity(new Intent(context, (Class<?>) ActivityOpensource.class));
            }
        });
        TextView textView = (TextView) viewInflate.findViewById(R.id.qartdecoLink);
        textView.setText(Html.fromHtml("Created by <a href=\"market://details?id=com.outlook.greyshirts.qr\">QArt Deco</a>"));
        textView.setMovementMethod(LinkMovementMethod.getInstance());
        viewInflate.findViewById(R.id.qr).setOnClickListener(new View.OnClickListener() { // from class: app.greyshirts.firewall.ui.DialogAbout.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + packageName));
                intent.setFlags(268435456);
                context.startActivity(intent);
            }
        });
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(R.string.app_name);
        builder.setIcon(R.drawable.launcher);
        builder.setView(viewInflate);
        builder.setPositiveButton(context.getString(R.string.about_dialog_share_button), new DialogInterface.OnClickListener() { // from class: app.greyshirts.firewall.ui.DialogAbout.3
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent("android.intent.action.SEND");
                intent.setType("text/plain");
                String string = context.getString(R.string.app_name);
                String str2 = "https://play.google.com/store/apps/details?id=" + packageName;
                intent.putExtra("android.intent.extra.SUBJECT", string);
                intent.putExtra("android.intent.extra.TEXT", string + "\r\n" + str2);
                context.startActivity(intent);
            }
        });
        builder.setNegativeButton(context.getString(R.string.about_dialog_rate_me_button), new DialogInterface.OnClickListener() { // from class: app.greyshirts.firewall.ui.DialogAbout.4
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse("market://details?id=" + packageName));
                context.startActivity(intent);
            }
        });
        return builder.create();
    }
}
