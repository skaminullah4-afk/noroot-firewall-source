package app.greyshirts.firewall.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;
import app.greyshirts.firewall.db.CombinedDataContract;
import app.greyshirts.firewall.db.UidGroupList;

/* JADX INFO: loaded from: classes.dex */
public class PackageInstallReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (TextUtils.isEmpty(action)) {
            return;
        }
        Log.i("NRFW", "package installed receiver. action=" + action);
        if (action.equals("android.intent.action.PACKAGE_REMOVED") && intent.getBooleanExtra("android.intent.extra.REPLACING", false)) {
            Log.i("NRFW", "replacing. ignore");
            return;
        }
        UidGroupList.clearPackageCache();
        AppInfo.clearIconCache();
        context.getContentResolver().notifyChange(CombinedDataContract.getInstance(context).getContentUri(), null);
    }
}
