package app.greyshirts.firewall.app;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.widget.ImageView;
import java.lang.ref.WeakReference;

/* JADX INFO: loaded from: classes.dex */
public class AsyncImageDrawable {

    public interface ImageLoader {
        boolean isSameTask(Object obj, Object obj2);

        Drawable loadDrawable(Object obj);
    }

    public static void loadBitmap(ImageView imageView, Bitmap bitmap, ImageLoader imageLoader, Object obj) {
        if (cancelPotentialWork(obj, imageView, imageLoader)) {
            BitmapWorkerTask bitmapWorkerTask = new BitmapWorkerTask(imageView, imageLoader);
            imageView.getResources();
            imageView.setImageDrawable(new AsyncDrawable(imageView.getResources(), bitmap, bitmapWorkerTask));
            bitmapWorkerTask.execute(obj);
        }
    }

    private static boolean cancelPotentialWork(Object obj, ImageView imageView, ImageLoader imageLoader) {
        BitmapWorkerTask bitmapWorkerTask = getBitmapWorkerTask(imageView);
        if (bitmapWorkerTask != null) {
            if (imageLoader.isSameTask(obj, bitmapWorkerTask.arg)) {
                return false;
            }
            bitmapWorkerTask.cancel(true);
        }
        return true;
    }

    static class BitmapWorkerTask extends AsyncTask<Object, Void, Drawable> {
        private Object arg = null;
        private final WeakReference<ImageView> imageViewReference;
        private final ImageLoader loader;

        public BitmapWorkerTask(ImageView imageView, ImageLoader imageLoader) {
            this.imageViewReference = new WeakReference<>(imageView);
            this.loader = imageLoader;
        }

        /* JADX INFO: Access modifiers changed from: protected */
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.AsyncTask
        public Drawable doInBackground(Object... objArr) {
            this.arg = objArr[0];
            return this.loader.loadDrawable(this.arg);
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(Drawable drawable) {
            ImageView imageView;
            if (isCancelled()) {
                drawable = null;
            }
            WeakReference<ImageView> weakReference = this.imageViewReference;
            if (weakReference == null || drawable == null || (imageView = weakReference.get()) == null || this != AsyncImageDrawable.getBitmapWorkerTask(imageView)) {
                return;
            }
            imageView.setImageDrawable(drawable);
        }
    }

    static class AsyncDrawable extends BitmapDrawable {
        private final WeakReference<BitmapWorkerTask> bitmapWorkerTaskReference;

        public AsyncDrawable(Resources resources, Bitmap bitmap, BitmapWorkerTask bitmapWorkerTask) {
            super(resources, bitmap);
            this.bitmapWorkerTaskReference = new WeakReference<>(bitmapWorkerTask);
        }

        public BitmapWorkerTask getBitmapWorkerTask() {
            return this.bitmapWorkerTaskReference.get();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static BitmapWorkerTask getBitmapWorkerTask(ImageView imageView) {
        if (imageView == null) {
            return null;
        }
        Drawable drawable = imageView.getDrawable();
        if (drawable instanceof AsyncDrawable) {
            return ((AsyncDrawable) drawable).getBitmapWorkerTask();
        }
        return null;
    }
}
