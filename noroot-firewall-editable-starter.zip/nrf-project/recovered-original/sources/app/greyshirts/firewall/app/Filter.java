package app.greyshirts.firewall.app;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import app.greyshirts.firewall.cache.AddressCache;
import app.greyshirts.firewall.cache.DnsCache;
import app.greyshirts.firewall.db.FilterRuleContract;
import app.greyshirts.firewall.db.PendingConnectionContract;
import app.greyshirts.firewall.ui.ServerStrUtil;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class Filter {
    static final String[] PROJECTION_GET_RULE = {"type", "type1", "serverStrType", "serverIp"};
    private static Filter instance;
    private final ContentResolver cr;
    private final Uri filterUri;
    private final Uri filterUriNoObserver;
    private final Uri pendingUri;

    public enum FilterRule {
        SHOULD_ALLOW,
        SHOULD_DENY,
        NO_RULE_NO_PENDING_ENTRY,
        NO_RULE_DUPLICATE_PENDING_ENTRY,
        WAIT_DNS
    }

    public enum Profile {
        PROFILE_ALL,
        PROFILE_WIFI,
        PROFILE_MOBILE
    }

    public enum Type {
        POLICY_ALLOW,
        POLICY_DENY,
        POLICY_CUSTOM
    }

    public static synchronized Filter getInstance(Context context) {
        if (instance == null) {
            instance = new Filter(context);
        }
        return instance;
    }

    private Filter(Context context) {
        this.cr = context.getContentResolver();
        this.filterUri = FilterRuleContract.getInstance(context).getContentUri();
        this.filterUriNoObserver = FilterRuleContract.getInstance(context).getContentUriNoObserver();
        this.pendingUri = PendingConnectionContract.getInstance(context).getContentUri();
    }

    public void setPolicyRule(Profile profile, String str, PackageNames packageNames, Type type) {
        int i;
        String str2 = "(isPolicy=1) AND(" + makeWhereForInClause("pkgName", "pkg2Name", "pkg3Name", packageNames) + ")";
        ArrayList<String> arrayListMakeWhereArgsForInClause = makeWhereArgsForInClause(3, packageNames);
        int i2 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$Type[type.ordinal()];
        if (i2 == 1) {
            i = 1;
        } else if (i2 == 2) {
            i = 2;
        } else if (i2 != 3) {
            return;
        } else {
            i = 0;
        }
        ContentValues contentValues = new ContentValues();
        int i3 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$Profile[profile.ordinal()];
        if (i3 == 1) {
            contentValues.put("type", Integer.valueOf(i));
            contentValues.put("type1", Integer.valueOf(i));
        } else if (i3 == 2) {
            contentValues.put("type", Integer.valueOf(i));
        } else if (i3 == 3) {
            contentValues.put("type1", Integer.valueOf(i));
        }
        contentValues.put("serverIp", "*");
        contentValues.put("serverStrType", (Integer) 0);
        contentValues.put("serverPort", (Integer) (-1));
        contentValues.put("protocol", (Integer) 0);
        contentValues.put("isPolicy", (Integer) 1);
        contentValues.put("appUid", (Integer) 0);
        if (this.cr.update(this.filterUri, contentValues, str2, toStringList(arrayListMakeWhereArgsForInClause)) == 0) {
            contentValues.put("createdData", Long.valueOf(System.currentTimeMillis()));
            contentValues.put("appName", str);
            contentValues.put("pkgName", packageNames.getAt(0));
            contentValues.put("pkg2Name", packageNames.getAt(1));
            contentValues.put("pkg3Name", packageNames.getAt(2));
            this.cr.insert(this.filterUri, contentValues);
        }
    }

    public void addCustomFilter(int i, int i2, String str, int i3, int i4, String str2, PackageNames packageNames, int i5) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("type", Integer.valueOf(i));
        contentValues.put("type1", Integer.valueOf(i2));
        contentValues.put("serverIp", str);
        contentValues.put("serverStrType", Integer.valueOf(i3));
        contentValues.put("serverPort", Integer.valueOf(i4));
        contentValues.put("protocol", (Integer) 0);
        contentValues.put("createdData", Long.valueOf(System.currentTimeMillis()));
        contentValues.put("appName", str2);
        contentValues.put("pkgName", packageNames.getAt(0));
        contentValues.put("pkg2Name", packageNames.getAt(1));
        contentValues.put("pkg3Name", packageNames.getAt(2));
        contentValues.put("isPolicy", (Integer) 0);
        contentValues.put("appUid", Integer.valueOf(i5));
        this.cr.insert(this.filterUri, contentValues);
    }

    public void addPreFilter(int i, int i2, String str, int i3, int i4) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("type", Integer.valueOf(i));
        contentValues.put("type1", Integer.valueOf(i2));
        contentValues.put("serverIp", str);
        contentValues.put("serverStrType", Integer.valueOf(i3));
        contentValues.put("serverPort", Integer.valueOf(i4));
        contentValues.put("protocol", (Integer) 0);
        contentValues.put("createdData", Long.valueOf(System.currentTimeMillis()));
        contentValues.put("pkgName", "*");
        contentValues.put("isPolicy", (Integer) 0);
        contentValues.put("priority", (Integer) (-10));
        contentValues.put("appUid", (Integer) 0);
        this.cr.insert(this.filterUri, contentValues);
    }

    public void addPostFilter(int i, int i2, String str, int i3, int i4) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("type", Integer.valueOf(i));
        contentValues.put("type1", Integer.valueOf(i2));
        contentValues.put("serverIp", str);
        contentValues.put("serverStrType", Integer.valueOf(i3));
        contentValues.put("serverPort", Integer.valueOf(i4));
        contentValues.put("protocol", (Integer) 0);
        contentValues.put("createdData", Long.valueOf(System.currentTimeMillis()));
        contentValues.put("pkgName", "*");
        contentValues.put("isPolicy", (Integer) 0);
        contentValues.put("priority", (Integer) 10);
        contentValues.put("appUid", (Integer) 0);
        this.cr.insert(this.filterUri, contentValues);
    }

    public void updateCustomFilter(long j, int i, int i2, String str, int i3, int i4) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("type", Integer.valueOf(i));
        contentValues.put("type1", Integer.valueOf(i2));
        contentValues.put("serverIp", str);
        contentValues.put("serverStrType", Integer.valueOf(i3));
        contentValues.put("serverPort", Integer.valueOf(i4));
        contentValues.put("protocol", (Integer) 0);
        this.cr.update(this.filterUri, contentValues, "_id=?", new String[]{String.valueOf(j)});
    }

    public void updateCustomFilter(long j, Profile profile, int i) {
        ContentValues contentValues = new ContentValues();
        int i2 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$Profile[profile.ordinal()];
        if (i2 == 1) {
            contentValues.put("type", Integer.valueOf(i));
            contentValues.put("type1", Integer.valueOf(i));
        } else if (i2 == 2) {
            contentValues.put("type", Integer.valueOf(i));
        } else if (i2 == 3) {
            contentValues.put("type1", Integer.valueOf(i));
        }
        this.cr.update(this.filterUri, contentValues, "_id=?", new String[]{String.valueOf(j)});
    }

    public void deletePolicyAndFilter(PackageNames packageNames) {
        this.cr.delete(this.filterUri, makeWhereForInClause("pkgName", "pkg2Name", "pkg3Name", packageNames), toStringList(makeWhereArgsForInClause(3, packageNames)));
    }

    public void addPending(int i, AppInfo appInfo, byte[] bArr, int i2, byte[] bArr2, int i3) {
        String str = String.format("%d.%d.%d.%d", Integer.valueOf(bArr[0] & 255), Integer.valueOf(bArr[1] & 255), Integer.valueOf(bArr[2] & 255), Integer.valueOf(bArr[3] & 255));
        AddressCache.AddressCacheEntry addressCacheEntryResolveNameFromIpPeek = DnsCache.getInstance().resolveNameFromIpPeek(str);
        String str2 = (addressCacheEntryResolveNameFromIpPeek == null || addressCacheEntryResolveNameFromIpPeek.type != AddressCache.EntryType.VALID || TextUtils.isEmpty(addressCacheEntryResolveNameFromIpPeek.hostname)) ? null : addressCacheEntryResolveNameFromIpPeek.hostname;
        ContentValues contentValues = new ContentValues();
        contentValues.put("serverIp", str);
        contentValues.put("serverPort", Integer.valueOf(i2));
        contentValues.put("serverHost", str2);
        contentValues.put("localIp", String.format("%d.%d.%d.%d", Integer.valueOf(bArr2[0] & 255), Integer.valueOf(bArr2[1] & 255), Integer.valueOf(bArr2[2] & 255), Integer.valueOf(bArr2[3] & 255)));
        contentValues.put("localPort", Integer.valueOf(i3));
        contentValues.put("protocol", (Integer) 0);
        contentValues.put("serverName", "");
        contentValues.put("createdData", Long.valueOf(System.currentTimeMillis()));
        contentValues.put("appName", appInfo.leaderAppName);
        contentValues.put("allAppName", appInfo.allAppName);
        contentValues.put("pkgName", appInfo.pkgs.getAt(0));
        contentValues.put("pkg2Name", appInfo.pkgs.getAt(1));
        contentValues.put("pkg3Name", appInfo.pkgs.getAt(2));
        contentValues.put("appUid", Integer.valueOf(i));
        Uri uriInsert = this.cr.insert(this.pendingUri, contentValues);
        if (str2 == null) {
            final String lastPathSegment = uriInsert.getLastPathSegment();
            DnsCache.getInstance().startResolver(str, new DnsCache.ResolveNameResult() { // from class: app.greyshirts.firewall.app.Filter.1
                @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
                public void onFinish(String str3, String str4) {
                    if (TextUtils.isEmpty(str4)) {
                        return;
                    }
                    ContentValues contentValues2 = new ContentValues();
                    contentValues2.put("serverHost", str4);
                    Filter.this.cr.update(Filter.this.pendingUri, contentValues2, String.format("(%s=?) AND (%s IS NULL OR %s='')", "_id", "serverHost", "serverHost"), new String[]{lastPathSegment});
                }
            });
        }
    }

    public void setPendingServerHost(long j, String str) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("serverHost", str);
        this.cr.update(this.pendingUri, contentValues, "_id=?", new String[]{String.valueOf(j)});
    }

    public void removePendingMatching(PackageNames packageNames) {
        this.cr.delete(this.pendingUri, makeWhereForInClause("pkgName", "pkg2Name", "pkg3Name", packageNames), toStringList(makeWhereArgsForInClause(3, packageNames)));
    }

    public void removePending(long j) {
        this.cr.delete(this.pendingUri, "_id=?", new String[]{String.valueOf(j)});
    }

    public void deleteAllPendingList() {
        this.cr.delete(this.pendingUri, null, null);
    }

    public FilterRule getRuleForConnection(Profile profile, byte[] bArr, int i, PackageNames packageNames) throws Throwable {
        ArrayList<String> arrayListMakeIpAndHostnameWildcard;
        String str;
        int i2;
        Cursor cursorQuery;
        Cursor cursorQuery2;
        StringBuilder sb = new StringBuilder(16);
        sb.append(bArr[0] & 255);
        sb.append('.');
        sb.append(bArr[1] & 255);
        sb.append('.');
        sb.append(bArr[2] & 255);
        sb.append('.');
        sb.append(bArr[3] & 255);
        String string = sb.toString();
        AddressCache.AddressCacheEntry addressCacheEntryResolveNameFromIpPeek = DnsCache.getInstance().resolveNameFromIpPeek(string);
        if (addressCacheEntryResolveNameFromIpPeek == null) {
            arrayListMakeIpAndHostnameWildcard = ServerStrUtil.makeIpAndHostnameWildcard(string, null);
            str = "((serverStrType=1) OR (serverStrType=0) AND (serverIp IN (" + new String(new char[arrayListMakeIpAndHostnameWildcard.size() - 1]).replace("\u0000", "?,") + "?)))";
        } else {
            int i3 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$cache$AddressCache$EntryType[addressCacheEntryResolveNameFromIpPeek.type.ordinal()];
            if (i3 == 1) {
                arrayListMakeIpAndHostnameWildcard = ServerStrUtil.makeIpAndHostnameWildcard(string, addressCacheEntryResolveNameFromIpPeek.hostname);
                str = "serverIp IN (" + new String(new char[arrayListMakeIpAndHostnameWildcard.size() - 1]).replace("\u0000", "?,") + "?)";
            } else if (i3 != 2) {
                arrayListMakeIpAndHostnameWildcard = ServerStrUtil.makeIpAndHostnameWildcard(string, null);
                str = "((serverStrType=1) OR (serverStrType=0) AND (serverIp IN (" + new String(new char[arrayListMakeIpAndHostnameWildcard.size() - 1]).replace("\u0000", "?,") + "?)))";
            } else {
                arrayListMakeIpAndHostnameWildcard = ServerStrUtil.makeIpAndHostnameWildcard(string, null);
                str = "((serverStrType=0) AND (serverIp IN (" + new String(new char[arrayListMakeIpAndHostnameWildcard.size() - 1]).replace("\u0000", "?,") + "?)))";
            }
        }
        StringBuilder sb2 = new StringBuilder();
        sb2.append("((");
        sb2.append("pkgName");
        sb2.append("='*')");
        sb2.append("OR (");
        sb2.append(makeWhereForInClause("pkgName", "pkg2Name", "pkg3Name", packageNames));
        sb2.append("))");
        sb2.append("AND (");
        int i4 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$Profile[profile.ordinal()];
        if (i4 == 2) {
            sb2.append("type");
            i2 = 0;
        } else {
            if (i4 != 3) {
                throw new RuntimeException("profile is PROFILE_ALL");
            }
            sb2.append("type1");
            i2 = 1;
        }
        sb2.append(" IN (1,2))");
        sb2.append("AND (");
        sb2.append("serverPort=-1 OR serverPort=?)");
        sb2.append("AND (");
        sb2.append(str);
        sb2.append(")");
        ArrayList<String> arrayListMakeWhereArgsForInClause = makeWhereArgsForInClause(3, packageNames);
        arrayListMakeWhereArgsForInClause.add(String.valueOf(i));
        arrayListMakeWhereArgsForInClause.addAll(arrayListMakeIpAndHostnameWildcard);
        try {
            cursorQuery = this.cr.query(this.filterUriNoObserver, PROJECTION_GET_RULE, sb2.toString(), toStringList(arrayListMakeWhereArgsForInClause), "priority ASC,isPolicy DESC,_id ASC LIMIT 1");
            try {
                if (cursorQuery == null) {
                    StringBuilder sb3 = new StringBuilder();
                    for (String str2 : arrayListMakeWhereArgsForInClause) {
                        if (str2 != null) {
                            sb3.append(str2);
                        } else {
                            sb3.append("(null)");
                        }
                        sb3.append(" ");
                    }
                    throw new RuntimeException("filter query failed. select=" + sb2.toString() + " args=" + sb3.toString());
                }
                cursorQuery.moveToFirst();
                if (!cursorQuery.isAfterLast()) {
                    if (cursorQuery.getInt(2) == 1) {
                        if (addressCacheEntryResolveNameFromIpPeek == null) {
                            FilterRule filterRule = FilterRule.WAIT_DNS;
                            if (cursorQuery != null) {
                                cursorQuery.close();
                            }
                            return filterRule;
                        }
                        int i5 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$cache$AddressCache$EntryType[addressCacheEntryResolveNameFromIpPeek.type.ordinal()];
                        if (i5 != 1) {
                            if (i5 == 2) {
                                throw new RuntimeException("query returned hostname record even though NXDOMAIN");
                            }
                            if (i5 == 3) {
                                FilterRule filterRule2 = FilterRule.SHOULD_DENY;
                                if (cursorQuery != null) {
                                    cursorQuery.close();
                                }
                                return filterRule2;
                            }
                        }
                    }
                    if (cursorQuery.getInt(i2) != 1) {
                        FilterRule filterRule3 = FilterRule.SHOULD_DENY;
                        if (cursorQuery != null) {
                            cursorQuery.close();
                        }
                        return filterRule3;
                    }
                    FilterRule filterRule4 = FilterRule.SHOULD_ALLOW;
                    if (cursorQuery != null) {
                        cursorQuery.close();
                    }
                    return filterRule4;
                }
                if (cursorQuery != null) {
                    cursorQuery.close();
                }
                ArrayList<String> arrayListMakeWhereArgsForInClause2 = makeWhereArgsForInClause(3, packageNames);
                arrayListMakeWhereArgsForInClause2.add(string);
                arrayListMakeWhereArgsForInClause2.add(String.valueOf(i));
                try {
                    cursorQuery2 = this.cr.query(this.pendingUri, null, "(" + makeWhereForInClause("pkgName", "pkg2Name", "pkg3Name", packageNames) + ") AND (serverIp=?) AND (serverPort=?)", toStringList(arrayListMakeWhereArgsForInClause2), "_id ASC");
                    try {
                        cursorQuery2.moveToFirst();
                        if (cursorQuery2.isAfterLast()) {
                            FilterRule filterRule5 = FilterRule.NO_RULE_NO_PENDING_ENTRY;
                            if (cursorQuery2 != null) {
                                cursorQuery2.close();
                            }
                            return filterRule5;
                        }
                        FilterRule filterRule6 = FilterRule.NO_RULE_DUPLICATE_PENDING_ENTRY;
                        if (cursorQuery2 != null) {
                            cursorQuery2.close();
                        }
                        return filterRule6;
                    } catch (Throwable th) {
                        th = th;
                        if (cursorQuery2 != null) {
                            cursorQuery2.close();
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    th = th2;
                    cursorQuery2 = null;
                }
            } catch (Throwable th3) {
                th = th3;
                if (cursorQuery != null) {
                    cursorQuery.close();
                }
                throw th;
            }
        } catch (Throwable th4) {
            th = th4;
            cursorQuery = null;
        }
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.app.Filter$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$app$Filter$Profile;
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$app$Filter$Type;
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$cache$AddressCache$EntryType = new int[AddressCache.EntryType.values().length];

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$cache$AddressCache$EntryType[AddressCache.EntryType.VALID.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$cache$AddressCache$EntryType[AddressCache.EntryType.NXDOMAIN.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$cache$AddressCache$EntryType[AddressCache.EntryType.ERROR.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            $SwitchMap$app$greyshirts$firewall$app$Filter$Profile = new int[Profile.values().length];
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Profile[Profile.PROFILE_ALL.ordinal()] = 1;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Profile[Profile.PROFILE_WIFI.ordinal()] = 2;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Profile[Profile.PROFILE_MOBILE.ordinal()] = 3;
            } catch (NoSuchFieldError unused6) {
            }
            $SwitchMap$app$greyshirts$firewall$app$Filter$Type = new int[Type.values().length];
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Type[Type.POLICY_ALLOW.ordinal()] = 1;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Type[Type.POLICY_DENY.ordinal()] = 2;
            } catch (NoSuchFieldError unused8) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$Type[Type.POLICY_CUSTOM.ordinal()] = 3;
            } catch (NoSuchFieldError unused9) {
            }
        }
    }

    public static String makeWhereForInClause(String str, String str2, String str3, PackageNames packageNames) {
        if (packageNames == null || packageNames.getPkgs() == null || packageNames.getPkgs().length == 0) {
            return "(1=0)";
        }
        String str4 = new String(new char[packageNames.length() - 1]).replace("\u0000", "?,") + "?";
        return ((("((" + str + " IN (" + str4 + ")) OR ") + "(" + str2 + " IN (" + str4 + ")) OR ") + "(" + str3 + " IN (" + str4 + "))") + ")";
    }

    public static ArrayList<String> makeWhereArgsForInClause(int i, PackageNames packageNames) {
        ArrayList<String> arrayList = new ArrayList<>();
        for (int i2 = 0; i2 < i; i2++) {
            for (int i3 = 0; i3 < packageNames.length(); i3++) {
                arrayList.add(packageNames.getAt(i3));
            }
        }
        return arrayList;
    }

    public static String[] toStringList(ArrayList<String> arrayList) {
        String[] strArr = new String[arrayList.size()];
        arrayList.toArray(strArr);
        return strArr;
    }
}
