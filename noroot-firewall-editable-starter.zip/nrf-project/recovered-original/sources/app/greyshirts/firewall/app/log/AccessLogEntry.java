package app.greyshirts.firewall.app.log;

import app.greyshirts.firewall.app.PackageNames;

/* JADX INFO: loaded from: classes.dex */
public class AccessLogEntry {
    final String allAppName;
    final int appUid;
    final String leaderAppName;
    final PackageNames pkgs;
    String serverHost = null;
    final byte[] serverIp;
    final int serverPort;
    final long time;
    final int type;

    private AccessLogEntry(int i, byte[] bArr, int i2, int i3, int i4, String str, String str2, PackageNames packageNames, long j) {
        this.type = i;
        this.serverIp = bArr;
        this.serverPort = i2;
        this.appUid = i4;
        this.allAppName = str;
        this.leaderAppName = str2;
        this.pkgs = packageNames;
        this.time = j;
    }

    public static AccessLogEntry newTCPAccessLog(int i, byte[] bArr, int i2, int i3, String str, String str2, PackageNames packageNames) {
        return new AccessLogEntry(i, bArr, i2, 0, i3, str, str2, packageNames, System.currentTimeMillis());
    }

    public String getServerIp() {
        return String.format("%d.%d.%d.%d", Integer.valueOf(this.serverIp[0] & 255), Integer.valueOf(this.serverIp[1] & 255), Integer.valueOf(this.serverIp[2] & 255), Integer.valueOf(this.serverIp[3] & 255));
    }

    public byte[] getServerIpBytes() {
        return this.serverIp;
    }

    public String getServerHost() {
        return this.serverHost;
    }

    public void setServerHost(String str) {
        this.serverHost = str;
    }

    public int getServerPort() {
        return this.serverPort;
    }

    public int getAppUid() {
        return this.appUid;
    }

    public String getAllAppName() {
        return this.allAppName;
    }

    public String getLeaderAppName() {
        return this.leaderAppName;
    }

    public PackageNames getPkgs() {
        return this.pkgs;
    }

    public int getType() {
        return this.type;
    }

    public long getTime() {
        return this.time;
    }
}
