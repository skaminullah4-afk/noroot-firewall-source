package app.greyshirts.firewall.app;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import app.greyshirts.firewall.R;
import app.greyshirts.firewall.db.PendingConnectionContract;
import app.greyshirts.firewall.ui.ActivityPager;
import java.util.ArrayList;

/* JADX INFO: loaded from: classes.dex */
public class PendingNotification {
    public static void resume() {
    }

    public static void suspend() {
    }

    public static void initChannel(Context context) {
        if (Build.VERSION.SDK_INT >= 26) {
            ArrayList arrayList = new ArrayList();
            NotificationChannel notificationChannel = new NotificationChannel("channel_id", "Notification", 3);
            notificationChannel.enableVibration(true);
            notificationChannel.enableLights(true);
            notificationChannel.setShowBadge(false);
            notificationChannel.setDescription("");
            arrayList.add(notificationChannel);
            NotificationChannel notificationChannel2 = new NotificationChannel("foreground_channel_id", "Service", 3);
            notificationChannel2.enableVibration(false);
            notificationChannel2.enableLights(false);
            notificationChannel2.setShowBadge(false);
            notificationChannel2.setDescription("");
            arrayList.add(notificationChannel2);
            ((NotificationManager) context.getSystemService(NotificationManager.class)).createNotificationChannels(arrayList);
        }
    }

    public static void showNotificationForAllApps(Context context, AppInfo appInfo) {
        int i;
        String string;
        Cursor cursorQuery = context.getContentResolver().query(PendingConnectionContract.getInstance(context).getContentGroupedByLeaderAppNameUri(), new String[]{"appName"}, null, null, null);
        StringBuilder sb = new StringBuilder();
        try {
            cursorQuery.moveToFirst();
            int columnIndex = cursorQuery.getColumnIndex("appName");
            i = 0;
            for (int i2 = 0; i2 < 5 && !cursorQuery.isAfterLast(); i2++) {
                if (i2 != 0) {
                    sb.append(", ");
                }
                sb.append(cursorQuery.getString(columnIndex));
                i++;
                cursorQuery.moveToNext();
            }
            if (!cursorQuery.isAfterLast()) {
                sb.append(",...");
            }
            if (cursorQuery != null) {
                cursorQuery.close();
            }
        } catch (Exception unused) {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            i = 0;
        } catch (Throwable th) {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            throw th;
        }
        if (i == 0) {
            string = appInfo.leaderAppName;
        } else {
            string = sb.toString();
        }
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "channel_id");
        builder.setSmallIcon(R.drawable.notification_fire);
        builder.setContentTitle(context.getString(R.string.notification_internet_access_detected_title));
        builder.setContentText(string);
        builder.setTicker(appInfo.leaderAppName);
        builder.setAutoCancel(true);
        builder.setColor(Color.parseColor("#ff2331"));
        builder.setContentIntent(PendingIntent.getActivity(context, 0, ActivityPager.getStartIntentFromBlockNotification(context), 134217728));
        Intent intent = new Intent(context, (Class<?>) MyVpnService.class);
        intent.putExtra("cmd", 4);
        builder.setDeleteIntent(PendingIntent.getService(context, 0, intent, 134217728));
        NotificationManager notificationManager = (NotificationManager) context.getSystemService("notification");
        try {
            notificationManager.notify(0, builder.getNotification());
        } catch (Exception unused2) {
            builder.setDefaults(5);
            notificationManager.notify(0, builder.getNotification());
        }
    }

    public static void clearNotification(Context context) {
        ((NotificationManager) context.getSystemService("notification")).cancelAll();
    }
}
