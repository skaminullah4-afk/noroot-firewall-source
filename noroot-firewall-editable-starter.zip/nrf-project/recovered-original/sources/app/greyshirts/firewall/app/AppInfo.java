package app.greyshirts.firewall.app;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.Log;
import android.util.LruCache;
import app.greyshirts.firewall.R;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/* JADX INFO: loaded from: classes.dex */
public class AppInfo {
    private static Drawable defaultIcon;
    private static final LruCache<String, IconInfo> iconCache = new LruCache<>(50);
    public final String allAppName;
    public final int appType;
    public final String leaderAppName;
    public final PackageNames pkgs;

    public static native String getNameFromUid(int i);

    static class Entry {
        final String appName;
        final String pkgName;

        public Entry(String str, String str2) {
            this.appName = str;
            this.pkgName = str2;
        }
    }

    private AppInfo(String str, String str2, String[] strArr, int i) {
        this.leaderAppName = str;
        this.allAppName = str2;
        this.pkgs = PackageNames.newInstance(strArr);
        this.appType = i;
    }

    public static AppInfo createFromUid(Context context, int i) {
        int i2;
        PackageManager packageManager = context.getPackageManager();
        ArrayList arrayList = new ArrayList();
        if (i > 0) {
            try {
                String[] packagesForUid = packageManager.getPackagesForUid(i);
                if (packagesForUid != null && packagesForUid.length > 0) {
                    for (String str : packagesForUid) {
                        if (str != null) {
                            try {
                                PackageInfo packageInfo = packageManager.getPackageInfo(str, 0);
                                String string = packageInfo != null ? packageInfo.applicationInfo.loadLabel(packageManager).toString() : null;
                                if (string == null || string.equals("")) {
                                    string = str;
                                }
                                arrayList.add(new Entry(string, str));
                            } catch (PackageManager.NameNotFoundException unused) {
                                arrayList.add(new Entry(str, str));
                            }
                        }
                    }
                    i2 = 0;
                } else {
                    String nameFromUid = getNameFromUid(i);
                    if (nameFromUid != null && !nameFromUid.equals("")) {
                        arrayList.add(new Entry(nameFromUid, "nonpkg." + nameFromUid));
                    } else {
                        arrayList.add(new Entry("System", "nonpkg.noname"));
                    }
                    i2 = 1;
                }
            } catch (RuntimeException unused2) {
                Log.i("NRFW", "error getPackagesForUid(). package manager has died");
                return null;
            }
        } else {
            arrayList.add(new Entry("System", "root.uid=0"));
            i2 = 2;
        }
        Collections.sort(arrayList, new Comparator<Entry>() { // from class: app.greyshirts.firewall.app.AppInfo.1
            @Override // java.util.Comparator
            public int compare(Entry entry, Entry entry2) {
                int iCompareToIgnoreCase = entry.appName.compareToIgnoreCase(entry2.appName);
                return iCompareToIgnoreCase == 0 ? entry.pkgName.compareToIgnoreCase(entry2.pkgName) : iCompareToIgnoreCase;
            }
        });
        String[] strArr = new String[arrayList.size()];
        String[] strArr2 = new String[arrayList.size()];
        for (int i3 = 0; i3 < arrayList.size(); i3++) {
            strArr[i3] = ((Entry) arrayList.get(i3)).pkgName;
            strArr2[i3] = ((Entry) arrayList.get(i3)).appName;
        }
        return new AppInfo(strArr2[0], TextUtils.join(",", strArr2), strArr, i2);
    }

    static class IconInfo {
        long date;
        Drawable icon;

        IconInfo() {
        }
    }

    static {
        System.loadLibrary("core");
    }

    public static synchronized void clearIconCache() {
        iconCache.evictAll();
    }

    public static Drawable getIcon(Context context, String str) {
        return getIcon(context, str, false);
    }

    public static synchronized Drawable getIcon(Context context, String str, boolean z) {
        PackageInfo packageInfo;
        if (defaultIcon == null) {
            defaultIcon = context.getResources().getDrawable(R.drawable.sym_def_app_icon);
        }
        PackageManager packageManager = context.getPackageManager();
        try {
            packageInfo = packageManager.getPackageInfo(str, 0);
            try {
                long j = packageInfo.lastUpdateTime;
                IconInfo iconInfo = iconCache.get(str);
                if (iconInfo != null && iconInfo.date == j && iconInfo.icon != null) {
                    return iconInfo.icon;
                }
            } catch (PackageManager.NameNotFoundException unused) {
            }
        } catch (PackageManager.NameNotFoundException unused2) {
            packageInfo = null;
        }
        if (packageInfo == null) {
            iconCache.remove(str);
            return defaultIcon;
        }
        if (z) {
            return null;
        }
        Drawable drawableLoadIcon = packageInfo.applicationInfo.loadIcon(packageManager);
        IconInfo iconInfo2 = new IconInfo();
        iconInfo2.date = packageInfo.lastUpdateTime;
        iconInfo2.icon = drawableLoadIcon;
        iconCache.put(str, iconInfo2);
        return drawableLoadIcon;
    }
}
