package app.greyshirts.firewall.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/* JADX INFO: loaded from: classes.dex */
public class NetworkStateChangeReceiver extends BroadcastReceiver {
    static Filter.Profile previousProfile = Filter.Profile.PROFILE_WIFI;

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Log.i("NRFW", "network changed. change profile");
        MyVpnService.notifyNetworkStateChange(context);
    }

    public static Filter.Profile getCurrentProfile(Context context) {
        int status = NetUtil.getInstance(context).getStatus();
        if (status == 1) {
            Log.i("NRFW", "profile=wifi");
            Filter.Profile profile = Filter.Profile.PROFILE_WIFI;
            previousProfile = profile;
            return profile;
        }
        if (status == 2) {
            Log.i("NRFW", "profile=mobile");
            Filter.Profile profile2 = Filter.Profile.PROFILE_MOBILE;
            previousProfile = profile2;
            return profile2;
        }
        Log.i("NRFW", "not connected. don't change profile");
        return previousProfile;
    }
}
