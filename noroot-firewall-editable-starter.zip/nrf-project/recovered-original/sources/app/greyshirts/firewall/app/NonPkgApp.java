package app.greyshirts.firewall.app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import app.greyshirts.firewall.db.AppContract;
import java.util.ArrayList;
import java.util.Iterator;

/* JADX INFO: loaded from: classes.dex */
public class NonPkgApp {
    private static ArrayList<NonPkgApp> cache;
    private final String appName;
    private final String pkgName;

    public static synchronized void addIfNotExist(Context context, AppInfo appInfo) {
        if (cache == null) {
            cache = loadDb(context);
        }
        String str = appInfo.leaderAppName;
        String at = appInfo.pkgs.getAt(0);
        for (NonPkgApp nonPkgApp : cache) {
            if (nonPkgApp.pkgName.equals(at) && nonPkgApp.appName.equals(str)) {
                return;
            }
        }
        ContentValues contentValues = new ContentValues();
        contentValues.put("appName", str);
        contentValues.put("pkg1Name", at);
        contentValues.put("appType", (Integer) 1);
        context.getContentResolver().insert(AppContract.getInstance(context).getContentUri(), contentValues);
        cache.add(new NonPkgApp(str, at));
    }

    /* JADX WARN: Code duplicated, block: B:16:0x004d A[PHI: r1
      0x004d: PHI (r1v3 android.database.Cursor) = (r1v2 android.database.Cursor), (r1v4 android.database.Cursor) binds: [B:15:0x004b, B:8:0x0040] A[DONT_GENERATE, DONT_INLINE]] */
    public static ArrayList<NonPkgApp> loadDb(Context context) {
        ArrayList<NonPkgApp> arrayList = new ArrayList<>();
        Cursor cursorQuery = null;
        try {
            cursorQuery = context.getContentResolver().query(AppContract.getInstance(context).getContentUri(), null, null, null, null);
            while (!cursorQuery.isAfterLast()) {
                arrayList.add(new NonPkgApp(cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("appName")), cursorQuery.getString(cursorQuery.getColumnIndexOrThrow("pkg1Name"))));
                cursorQuery.moveToNext();
            }
            if (cursorQuery != null) {
                cursorQuery.close();
            }
        } catch (Exception unused) {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
        } catch (Throwable th) {
            if (cursorQuery != null) {
                cursorQuery.close();
            }
            throw th;
        }
        return arrayList;
    }

    public static synchronized Iterator<NonPkgApp> getIterator(Context context) {
        if (cache == null) {
            cache = loadDb(context);
        }
        return cache.iterator();
    }

    private NonPkgApp(String str, String str2) {
        this.appName = str;
        this.pkgName = str2;
    }

    public String getPkgName() {
        return this.pkgName;
    }

    public String getAppName() {
        return this.appName;
    }
}
