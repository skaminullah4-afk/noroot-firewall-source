package app.greyshirts.firewall.app.log;

/* JADX INFO: loaded from: classes.dex */
public class RingBuffer<E> {
    final E[] array;
    final int arraySize;
    int head;
    int headSeqno;
    int tail;
    int tailSeqno;

    public RingBuffer(int i) {
        this.array = (E[]) new Object[i];
        this.arraySize = i;
    }

    public RingBuffer<E> makeClone() {
        RingBuffer<E> ringBuffer = new RingBuffer<>(this.arraySize);
        System.arraycopy(this.array, 0, ringBuffer.array, 0, this.arraySize);
        ringBuffer.headSeqno = this.headSeqno;
        ringBuffer.tailSeqno = this.tailSeqno;
        ringBuffer.head = this.head;
        ringBuffer.tail = this.tail;
        return ringBuffer;
    }

    public void add(E e) {
        int i = this.headSeqno;
        int i2 = this.tailSeqno;
        int i3 = i - i2;
        int i4 = this.arraySize;
        if (i3 >= i4) {
            this.tailSeqno = i2 + 1;
            this.tail++;
            if (this.tail == i4) {
                this.tail = 0;
            }
        }
        E[] eArr = this.array;
        int i5 = this.head;
        eArr[i5] = e;
        this.headSeqno++;
        this.head = i5 + 1;
        if (this.head == this.arraySize) {
            this.head = 0;
        }
    }

    public int count() {
        return this.headSeqno - this.tailSeqno;
    }

    public E get(int i) {
        if (i < 0 || i >= count()) {
            throw new RuntimeException("index out of range");
        }
        int i2 = this.tail + i;
        int i3 = this.arraySize;
        if (i2 >= i3) {
            i2 -= i3;
        }
        return this.array[i2];
    }

    public void clear() {
        this.tailSeqno = 0;
        this.headSeqno = 0;
        this.head = 0;
        this.tail = 0;
    }
}
