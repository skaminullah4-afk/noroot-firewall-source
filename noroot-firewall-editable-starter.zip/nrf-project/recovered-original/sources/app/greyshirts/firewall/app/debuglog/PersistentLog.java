package app.greyshirts.firewall.app.debuglog;

import android.content.Context;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/* JADX INFO: loaded from: classes.dex */
public class PersistentLog {
    private static PersistentLog instance;
    private File mFile;
    private SimpleDateFormat mSdf = new SimpleDateFormat("MM/dd HH:mm:ss.SSS");

    public static synchronized PersistentLog getInstance(Context context) {
        if (instance == null) {
            instance = new PersistentLog(context);
            instance.i("PersistentLog: created. (first time? process killed?)", new Object[0]);
        }
        return instance;
    }

    public PersistentLog(Context context) {
        this.mFile = new File(context.getFilesDir(), "persistentlog.txt");
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x008e, code lost:
    
        if (r1 != null) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public synchronized void i(String str, Object... objArr) {
        FileInputStream fileInputStream;
        FileOutputStream fileOutputStream;
        String str2 = this.mSdf.format(new Date()) + " " + String.format(str, objArr) + "\n";
        FileOutputStream fileOutputStream2 = null;
        try {
            if (this.mFile.length() > 3145728) {
                byte[] bArr = new byte[2097152];
                try {
                    fileInputStream = new FileInputStream(this.mFile);
                    try {
                        fileInputStream.skip(this.mFile.length() - ((long) bArr.length));
                        fileInputStream.read(bArr);
                        fileInputStream.close();
                    } catch (Exception unused) {
                        if (fileInputStream != null) {
                        }
                        fileOutputStream = new FileOutputStream(this.mFile, false);
                        try {
                            fileOutputStream.write(bArr);
                            fileOutputStream.write(str2.getBytes());
                            fileOutputStream.close();
                        } catch (Exception unused2) {
                        } catch (Throwable th) {
                            th = th;
                            if (fileOutputStream != null) {
                                try {
                                    fileOutputStream.close();
                                } catch (IOException unused3) {
                                }
                            }
                            throw th;
                        }
                        fileOutputStream.close();
                    } catch (Throwable th2) {
                        th = th2;
                        if (fileInputStream != null) {
                            try {
                                fileInputStream.close();
                            } catch (IOException unused4) {
                            }
                        }
                        throw th;
                    }
                } catch (Exception unused5) {
                    fileInputStream = null;
                } catch (Throwable th3) {
                    th = th3;
                    fileInputStream = null;
                }
                try {
                    fileInputStream.close();
                } catch (IOException unused6) {
                }
                try {
                    fileOutputStream = new FileOutputStream(this.mFile, false);
                    fileOutputStream.write(bArr);
                    fileOutputStream.write(str2.getBytes());
                    fileOutputStream.close();
                } catch (Exception unused7) {
                    fileOutputStream = null;
                } catch (Throwable th4) {
                    th = th4;
                    fileOutputStream = null;
                }
                fileOutputStream.close();
            } else {
                try {
                    FileOutputStream fileOutputStream3 = new FileOutputStream(this.mFile, true);
                    try {
                        fileOutputStream3.write(str2.getBytes());
                        fileOutputStream3.close();
                        fileOutputStream3.close();
                    } catch (Exception unused8) {
                        fileOutputStream2 = fileOutputStream3;
                        if (fileOutputStream2 != null) {
                            fileOutputStream2.close();
                        }
                    } catch (Throwable th5) {
                        th = th5;
                        fileOutputStream2 = fileOutputStream3;
                        if (fileOutputStream2 != null) {
                            try {
                                fileOutputStream2.close();
                            } catch (IOException unused9) {
                            }
                        }
                        throw th;
                    }
                } catch (Exception unused10) {
                } catch (Throwable th6) {
                    th = th6;
                }
            }
        } catch (IOException unused11) {
        }
    }

    public synchronized String get() {
        byte[] bArr = new byte[(int) this.mFile.length()];
        FileInputStream fileInputStream = null;
        try {
            FileInputStream fileInputStream2 = new FileInputStream(this.mFile);
            try {
                fileInputStream2.read(bArr);
                fileInputStream2.close();
                try {
                    fileInputStream2.close();
                } catch (IOException unused) {
                }
                return new String(bArr);
            } catch (Exception unused2) {
                fileInputStream = fileInputStream2;
                if (fileInputStream != null) {
                    try {
                        fileInputStream.close();
                    } catch (IOException unused3) {
                    }
                }
                return "";
            } catch (Throwable th) {
                th = th;
                fileInputStream = fileInputStream2;
                if (fileInputStream != null) {
                    try {
                        fileInputStream.close();
                    } catch (IOException unused4) {
                    }
                }
                throw th;
            }
        } catch (Exception unused5) {
        } catch (Throwable th2) {
            th = th2;
        }
    }

    public synchronized void clear() {
        this.mFile.delete();
    }
}
