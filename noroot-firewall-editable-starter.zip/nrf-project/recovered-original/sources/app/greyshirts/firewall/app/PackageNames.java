package app.greyshirts.firewall.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

/* JADX INFO: loaded from: classes.dex */
public class PackageNames implements Parcelable {
    public static final Parcelable.Creator<PackageNames> CREATOR = new Parcelable.Creator<PackageNames>() { // from class: app.greyshirts.firewall.app.PackageNames.1
        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PackageNames createFromParcel(Parcel parcel) {
            return new PackageNames(parcel);
        }

        /* JADX WARN: Can't rename method to resolve collision */
        @Override // android.os.Parcelable.Creator
        public PackageNames[] newArray(int i) {
            return new PackageNames[i];
        }
    };
    private final String[] pkgs;

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    public static PackageNames newInstance(String[] strArr) {
        return new PackageNames(strArr);
    }

    public static PackageNames newInstanceFromCommaList(String str) {
        return newInstance(str.split(","));
    }

    public String getAt(int i) {
        String[] strArr = this.pkgs;
        if (strArr.length > i) {
            return strArr[i];
        }
        return null;
    }

    public int length() {
        return this.pkgs.length;
    }

    public String getCommaJoinedString() {
        return TextUtils.join(",", this.pkgs);
    }

    public String[] getPkgs() {
        return this.pkgs;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.pkgs.length);
        parcel.writeStringArray(this.pkgs);
    }

    protected PackageNames(String[] strArr) {
        this.pkgs = strArr;
    }

    protected PackageNames(Parcel parcel) {
        this.pkgs = new String[parcel.readInt()];
        parcel.readStringArray(this.pkgs);
    }
}
