package app.greyshirts.firewall.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import app.greyshirts.firewall.ui.ActivityPager;
import app.greyshirts.firewall.ui.FragHome;
import java.util.Random;

/* JADX INFO: loaded from: classes.dex */
public class BootReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        if ("android.intent.action.BOOT_COMPLETED".equals(intent.getAction()) && FragHome.getAutoStart(context)) {
            try {
                Thread.sleep(6000L);
            } catch (InterruptedException unused) {
            }
            Intent intent2 = new Intent(context, (Class<?>) ActivityPager.class);
            intent2.setFlags(268435456);
            intent2.setAction("autoStart");
            intent2.putExtra("RANDOMID", new Random().nextLong());
            context.startActivity(intent2);
        }
    }
}
