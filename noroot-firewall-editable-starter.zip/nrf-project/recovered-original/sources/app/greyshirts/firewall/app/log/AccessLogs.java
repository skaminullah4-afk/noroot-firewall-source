package app.greyshirts.firewall.app.log;

import java.util.Arrays;
import java.util.Iterator;
import java.util.WeakHashMap;

/* JADX INFO: loaded from: classes.dex */
public class AccessLogs {
    private static final AccessLogs instance = new AccessLogs();
    private RingBuffer<AccessLogEntry> logs = new RingBuffer<>(500);
    private final Object lock = new Object();
    private final WeakHashMap<Observer, Boolean> observers = new WeakHashMap<>();

    public interface Observer {
        void onRingBufferChanged();
    }

    public static AccessLogs getInstance() {
        return instance;
    }

    private AccessLogs() {
    }

    public void addObserver(Observer observer) {
        synchronized (this.lock) {
            this.observers.put(observer, true);
        }
    }

    public AccessLogs makeCopy() {
        AccessLogs accessLogs;
        synchronized (this.lock) {
            accessLogs = new AccessLogs();
            accessLogs.logs = this.logs.makeClone();
        }
        return accessLogs;
    }

    public void add(AccessLogEntry accessLogEntry) {
        synchronized (this.lock) {
            int iCount = this.logs.count() - 1;
            for (int i = 0; iCount >= 0 && i < 10; i++) {
                AccessLogEntry accessLogEntry2 = this.logs.get(iCount);
                if (accessLogEntry.getTime() - accessLogEntry2.getTime() > 180000) {
                    break;
                }
                if (accessLogEntry2.getAppUid() == accessLogEntry.getAppUid() && Arrays.equals(accessLogEntry2.getServerIpBytes(), accessLogEntry.getServerIpBytes()) && accessLogEntry2.getServerPort() == accessLogEntry.getServerPort() && accessLogEntry2.getType() == accessLogEntry.getType()) {
                    return;
                }
                iCount--;
            }
            this.logs.add(accessLogEntry);
            Iterator<Observer> it = this.observers.keySet().iterator();
            while (it.hasNext()) {
                it.next().onRingBufferChanged();
            }
        }
    }

    public void clear() {
        synchronized (this.lock) {
            this.logs.clear();
            Iterator<Observer> it = this.observers.keySet().iterator();
            while (it.hasNext()) {
                it.next().onRingBufferChanged();
            }
        }
    }

    public int count() {
        int iCount;
        synchronized (this.lock) {
            iCount = this.logs.count();
        }
        return iCount;
    }

    public AccessLogEntry get(int i) {
        AccessLogEntry accessLogEntry;
        synchronized (this.lock) {
            accessLogEntry = this.logs.get(i);
        }
        return accessLogEntry;
    }
}
