package app.greyshirts.firewall.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

/* JADX INFO: loaded from: classes.dex */
public class NetUtil {
    private static NetUtil instance;
    private final ConnectivityManager cm;

    public static synchronized NetUtil getInstance(Context context) {
        if (instance == null) {
            instance = new NetUtil(context);
        }
        return instance;
    }

    public NetUtil(Context context) {
        this.cm = (ConnectivityManager) context.getSystemService("connectivity");
    }

    int getStatus() {
        NetworkInfo activeNetworkInfo = this.cm.getActiveNetworkInfo();
        if (activeNetworkInfo == null) {
            return 0;
        }
        if (activeNetworkInfo.getType() == 1) {
            return 1;
        }
        return activeNetworkInfo.getType() == 0 ? 2 : 0;
    }
}
