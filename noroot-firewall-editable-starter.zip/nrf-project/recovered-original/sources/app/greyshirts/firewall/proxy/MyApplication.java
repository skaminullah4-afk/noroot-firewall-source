package app.greyshirts.firewall.proxy;

import android.app.Application;
import app.greyshirts.firewall.app.PendingNotification;
import app.greyshirts.firewall.app.debuglog.PersistentLog;
import app.greyshirts.firewall.db.InitialAutoImporter;
import com.crashlytics.android.Crashlytics;
import com.crashlytics.android.ndk.CrashlyticsNdk;
import io.fabric.sdk.android.Fabric;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public class MyApplication extends Application {
    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        Locale.setDefault(Locale.ENGLISH);
        Fabric.with(this, new Crashlytics(), new CrashlyticsNdk());
        CrashDumper.getInstance(this).install();
        PersistentLog.getInstance(this).i("Application started", new Object[0]);
        PendingNotification.initChannel(this);
        new InitialAutoImporter(this, "filters.json").tryImport();
    }
}
