package app.greyshirts.firewall.proxy;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;

/* JADX INFO: loaded from: classes.dex */
public class CrashDumper {
    private static CrashDumper instance;
    private File mFile;
    private boolean mIsInstalled = false;

    native void jniInstall(String str);

    public static CrashDumper getInstance(Context context) {
        if (instance == null) {
            instance = new CrashDumper(context);
        }
        return instance;
    }

    public CrashDumper(Context context) {
        File filesDir = context.getFilesDir();
        if (filesDir != null) {
            this.mFile = new File(filesDir, "dump.txt");
        }
    }

    public boolean hasCrashDump() {
        File file = this.mFile;
        if (file == null) {
            return false;
        }
        return file.exists();
    }

    public void removeFile() {
        File file = this.mFile;
        if (file != null) {
            file.delete();
        }
    }

    public String readCrashDump() {
        File file = this.mFile;
        if (file == null) {
            return "";
        }
        try {
            FileInputStream fileInputStream = new FileInputStream(file);
            byte[] bArr = new byte[8192];
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            while (true) {
                int i = fileInputStream.read(bArr);
                if (i != -1) {
                    byteArrayOutputStream.write(bArr, 0, i);
                } else {
                    fileInputStream.close();
                    return new String(byteArrayOutputStream.toByteArray());
                }
            }
        } catch (Exception e) {
            return "cannot load crash dump. e=" + e;
        }
    }

    void install() {
        if (this.mIsInstalled) {
            return;
        }
        jniInstall(this.mFile.getAbsolutePath());
        this.mIsInstalled = true;
    }

    static {
        System.loadLibrary("core");
    }
}
