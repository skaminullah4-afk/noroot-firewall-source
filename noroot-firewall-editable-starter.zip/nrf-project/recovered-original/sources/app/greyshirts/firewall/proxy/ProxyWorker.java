package app.greyshirts.firewall.proxy;

import android.net.ConnectivityManager;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.system.OsConstants;
import android.util.Log;
import app.greyshirts.firewall.app.AppInfo;
import app.greyshirts.firewall.app.Filter;
import app.greyshirts.firewall.app.NetworkStateChangeReceiver;
import app.greyshirts.firewall.app.NonPkgApp;
import app.greyshirts.firewall.app.PackageNames;
import app.greyshirts.firewall.app.PendingNotification;
import app.greyshirts.firewall.app.log.AccessLogEntry;
import app.greyshirts.firewall.app.log.AccessLogs;
import app.greyshirts.firewall.cache.DnsCache;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public class ProxyWorker {
    public static final int ACTION_ALLOW_CONNECTION = 1;
    public static final int ACTION_CREATE_CLIENT_AND_CONNECT = 2;
    public static final int ACTION_CREATE_CLIENT_AND_PEND = 3;
    public static final int ACTION_DENY_CONNECTION = 2;
    public static final int ACTION_DO_NOTHING = 3;
    public static final int ACTION_IGNORE_PACKET = 1;
    static final String TAG = "NRFW";
    private static final ProxyWorker instance = new ProxyWorker();
    private ConnectivityManager connManager;
    private Filter.Profile curProfile;
    private final DnsCache.ResolveNameResult dnsListener = new DnsCache.ResolveNameResult() { // from class: app.greyshirts.firewall.proxy.ProxyWorker.1
        @Override // app.greyshirts.firewall.cache.DnsCache.ResolveNameResult
        public void onFinish(String str, String str2) {
            ProxyWorker.this.nativeNotifyDnsResolved(str, str2);
        }
    };
    private VpnService vpn;

    public static class ActionAndPkgs {
        public int action;
        public Object pkgs;
    }

    public enum Logging {
        LOGGING_QUIET,
        LOGGING_LOGCAT,
        LOGGING_MEMORY
    }

    private native void nativeDumpMemoryLogging(String str);

    private native boolean nativeIsRunning();

    /* JADX INFO: Access modifiers changed from: private */
    public native boolean nativeNotifyDnsResolved(String str, String str2);

    private native boolean nativeNotifyNeedToRequeryBlockingRule();

    private native String nativeProbe(String str);

    private native void nativeSetLogging(int i);

    private native void nativeStart(int i);

    private native void nativeStop();

    static {
        System.loadLibrary("core");
    }

    public static synchronized ProxyWorker getInstance() {
        return instance;
    }

    public synchronized boolean notifyBlockingRuleChanged() {
        Log.i(TAG, "blocking rule changed. notify");
        return nativeNotifyNeedToRequeryBlockingRule();
    }

    public synchronized boolean notifyNetworkStateChanged() {
        if (this.vpn != null && this.curProfile != null) {
            Filter.Profile currentProfile = NetworkStateChangeReceiver.getCurrentProfile(this.vpn.getApplicationContext());
            if (this.curProfile != null && this.curProfile != currentProfile) {
                Log.i(TAG, "profile change detected in ProxyWorker");
                this.curProfile = currentProfile;
                return nativeNotifyNeedToRequeryBlockingRule();
            }
            return nativeIsRunning();
        }
        return false;
    }

    public synchronized void start(VpnService vpnService, ParcelFileDescriptor parcelFileDescriptor) {
        nativeStop();
        this.vpn = vpnService;
        this.connManager = (ConnectivityManager) vpnService.getApplicationContext().getSystemService("connectivity");
        this.curProfile = NetworkStateChangeReceiver.getCurrentProfile(vpnService.getApplicationContext());
        nativeStart(parcelFileDescriptor.detachFd());
    }

    public synchronized void stop() {
        nativeStop();
    }

    public synchronized boolean isRunning() {
        return nativeIsRunning();
    }

    public synchronized void setLogging(Logging logging) {
        int i = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$proxy$ProxyWorker$Logging[logging.ordinal()];
        if (i == 1) {
            nativeSetLogging(0);
        } else if (i == 2) {
            nativeSetLogging(1);
        } else if (i == 3) {
            nativeSetLogging(3);
        }
    }

    public synchronized void dumpMemoryLog(String str) {
        nativeDumpMemoryLogging(str);
    }

    public String getEventJson() {
        return nativeProbe("event");
    }

    public void causeCrash(boolean z) {
        if (z) {
            nativeProbe("crash me");
        } else {
            nativeProbe("crash newthread");
        }
    }

    public void pollNetworkStateChange() {
        notifyNetworkStateChanged();
    }

    public ActionAndPkgs queryActionForNewTCPConnection(int i, byte[] bArr, int i2, byte[] bArr2, int i3) {
        int connectionOwnerUid;
        if (Build.VERSION.SDK_INT >= 29) {
            ConnectivityManager connectivityManager = this.connManager;
            if (connectivityManager == null) {
                return null;
            }
            try {
                try {
                    connectionOwnerUid = connectivityManager.getConnectionOwnerUid(OsConstants.IPPROTO_TCP, new InetSocketAddress(InetAddress.getByAddress(bArr2), i3), new InetSocketAddress(InetAddress.getByAddress(bArr), i2));
                } catch (UnknownHostException unused) {
                    connectionOwnerUid = -1;
                }
            } catch (UnknownHostException unused2) {
            }
        } else {
            connectionOwnerUid = i;
        }
        AppInfo appInfoCreateFromUid = AppInfo.createFromUid(this.vpn.getApplicationContext(), connectionOwnerUid);
        if (appInfoCreateFromUid == null) {
            return null;
        }
        int i4 = 1;
        if (appInfoCreateFromUid.appType == 1) {
            NonPkgApp.addIfNotExist(this.vpn.getApplicationContext(), appInfoCreateFromUid);
        }
        Filter filter = Filter.getInstance(this.vpn.getApplicationContext());
        int i5 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[filter.getRuleForConnection(this.curProfile, bArr, i2, appInfoCreateFromUid.pkgs).ordinal()];
        if (i5 != 2) {
            if (i5 == 3) {
                filter.addPending(connectionOwnerUid, appInfoCreateFromUid, bArr, i2, bArr2, i3);
                PendingNotification.showNotificationForAllApps(this.vpn.getApplicationContext(), appInfoCreateFromUid);
                AccessLogs.getInstance().add(AccessLogEntry.newTCPAccessLog(0, bArr, i2, connectionOwnerUid, appInfoCreateFromUid.allAppName, appInfoCreateFromUid.leaderAppName, appInfoCreateFromUid.pkgs));
            } else if (i5 == 4) {
                AccessLogs.getInstance().add(AccessLogEntry.newTCPAccessLog(0, bArr, i2, connectionOwnerUid, appInfoCreateFromUid.allAppName, appInfoCreateFromUid.leaderAppName, appInfoCreateFromUid.pkgs));
            } else if (i5 != 5) {
                AccessLogs.getInstance().add(AccessLogEntry.newTCPAccessLog(2, bArr, i2, connectionOwnerUid, appInfoCreateFromUid.allAppName, appInfoCreateFromUid.leaderAppName, appInfoCreateFromUid.pkgs));
            } else {
                DnsCache.getInstance().startResolver(String.format("%d.%d.%d.%d", Integer.valueOf(bArr[0] & 255), Integer.valueOf(bArr[1] & 255), Integer.valueOf(bArr[2] & 255), Integer.valueOf(bArr[3] & 255)), this.dnsListener);
            }
            i4 = 3;
        } else {
            AccessLogs.getInstance().add(AccessLogEntry.newTCPAccessLog(1, bArr, i2, connectionOwnerUid, appInfoCreateFromUid.allAppName, appInfoCreateFromUid.leaderAppName, appInfoCreateFromUid.pkgs));
            i4 = 2;
        }
        ActionAndPkgs actionAndPkgs = new ActionAndPkgs();
        actionAndPkgs.action = i4;
        actionAndPkgs.pkgs = appInfoCreateFromUid.pkgs;
        return actionAndPkgs;
    }

    /* JADX INFO: renamed from: app.greyshirts.firewall.proxy.ProxyWorker$2, reason: invalid class name */
    static /* synthetic */ class AnonymousClass2 {
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule = new int[Filter.FilterRule.values().length];
        static final /* synthetic */ int[] $SwitchMap$app$greyshirts$firewall$proxy$ProxyWorker$Logging;

        static {
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.SHOULD_DENY.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.SHOULD_ALLOW.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.NO_RULE_NO_PENDING_ENTRY.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.NO_RULE_DUPLICATE_PENDING_ENTRY.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.WAIT_DNS.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            $SwitchMap$app$greyshirts$firewall$proxy$ProxyWorker$Logging = new int[Logging.values().length];
            try {
                $SwitchMap$app$greyshirts$firewall$proxy$ProxyWorker$Logging[Logging.LOGGING_QUIET.ordinal()] = 1;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$proxy$ProxyWorker$Logging[Logging.LOGGING_LOGCAT.ordinal()] = 2;
            } catch (NoSuchFieldError unused7) {
            }
            try {
                $SwitchMap$app$greyshirts$firewall$proxy$ProxyWorker$Logging[Logging.LOGGING_MEMORY.ordinal()] = 3;
            } catch (NoSuchFieldError unused8) {
            }
        }
    }

    public ActionAndPkgs queryActionForNewUDPConnection(int i, byte[] bArr, int i2, byte[] bArr2, int i3) {
        PackageNames packageNamesNewInstanceFromCommaList;
        int i4 = 1;
        String.format(Locale.US, "%d.%d.%d.%d", Integer.valueOf(bArr[0] & 255), Integer.valueOf(bArr[1] & 255), Integer.valueOf(bArr[2] & 255), Integer.valueOf(bArr[3] & 255));
        if (Build.VERSION.SDK_INT >= 29) {
            ConnectivityManager connectivityManager = this.connManager;
            if (connectivityManager == null) {
                return null;
            }
            try {
                i = connectivityManager.getConnectionOwnerUid(OsConstants.IPPROTO_UDP, new InetSocketAddress(InetAddress.getByAddress(bArr2), i3), new InetSocketAddress(InetAddress.getByAddress(bArr), i2));
            } catch (UnknownHostException unused) {
                i = -1;
            }
        }
        if (i == -1) {
            packageNamesNewInstanceFromCommaList = PackageNames.newInstanceFromCommaList("unknown");
        } else {
            AppInfo appInfoCreateFromUid = AppInfo.createFromUid(this.vpn.getApplicationContext(), i);
            if (appInfoCreateFromUid == null) {
                Log.i(TAG, "no Package info for UDP packet");
                packageNamesNewInstanceFromCommaList = PackageNames.newInstanceFromCommaList("unknown");
            } else {
                if (appInfoCreateFromUid.appType == 1) {
                    NonPkgApp.addIfNotExist(this.vpn.getApplicationContext(), appInfoCreateFromUid);
                }
                String str = appInfoCreateFromUid.allAppName;
                String str2 = appInfoCreateFromUid.leaderAppName;
                packageNamesNewInstanceFromCommaList = appInfoCreateFromUid.pkgs;
            }
        }
        Filter.getInstance(this.vpn.getApplicationContext());
        int i5 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[Filter.FilterRule.SHOULD_ALLOW.ordinal()];
        if (i5 == 2) {
            i4 = 2;
        } else if (i5 == 3 || i5 == 4) {
            i4 = 3;
        }
        ActionAndPkgs actionAndPkgs = new ActionAndPkgs();
        actionAndPkgs.action = i4;
        actionAndPkgs.pkgs = packageNamesNewInstanceFromCommaList;
        return actionAndPkgs;
    }

    public boolean isConnectionAlive(byte[] bArr, int i, byte[] bArr2, int i2, int i3) {
        ConnectivityManager connectivityManager;
        if (Build.VERSION.SDK_INT < 29 || (connectivityManager = this.connManager) == null) {
            return false;
        }
        try {
            return connectivityManager.getConnectionOwnerUid(i3, new InetSocketAddress(InetAddress.getByAddress(bArr2), i2), new InetSocketAddress(InetAddress.getByAddress(bArr), i)) > 0;
        } catch (Exception unused) {
        }
    }

    public int queryActionForTCP(byte[] bArr, int i, Object obj, boolean z) throws Throwable {
        Filter.FilterRule ruleForConnection = Filter.getInstance(this.vpn.getApplicationContext()).getRuleForConnection(this.curProfile, bArr, i, (PackageNames) obj);
        if (z) {
            int i2 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[ruleForConnection.ordinal()];
            if (i2 != 1) {
                if (i2 == 2) {
                    return 1;
                }
                if (i2 != 3) {
                    if (i2 != 4) {
                        if (i2 == 5) {
                            DnsCache.getInstance().startResolver(String.format("%d.%d.%d.%d", Integer.valueOf(bArr[0] & 255), Integer.valueOf(bArr[1] & 255), Integer.valueOf(bArr[2] & 255), Integer.valueOf(bArr[3] & 255)), this.dnsListener);
                        }
                    }
                    return 3;
                }
            }
            return 2;
        }
        int i3 = AnonymousClass2.$SwitchMap$app$greyshirts$firewall$app$Filter$FilterRule[ruleForConnection.ordinal()];
        if (i3 == 1) {
            return 2;
        }
        if (i3 == 2) {
            return 3;
        }
        if (i3 != 3 && i3 != 4 && i3 == 5) {
            DnsCache.getInstance().startResolver(String.format("%d.%d.%d.%d", Integer.valueOf(bArr[0] & 255), Integer.valueOf(bArr[1] & 255), Integer.valueOf(bArr[2] & 255), Integer.valueOf(bArr[3] & 255)), this.dnsListener);
            return 3;
        }
        return 2;
    }

    public boolean protect(int i) {
        return this.vpn.protect(i);
    }

    public synchronized String toString() {
        return nativeIsRunning() ? "worker running" : "worker not running";
    }
}
