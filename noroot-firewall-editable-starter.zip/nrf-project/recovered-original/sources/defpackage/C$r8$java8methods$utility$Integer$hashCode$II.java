package defpackage;

/* JADX INFO: renamed from: $r8$java8methods$utility$Integer$hashCode$II, reason: invalid class name */
/* JADX INFO: loaded from: classes.dex */
public /* synthetic */ class C$r8$java8methods$utility$Integer$hashCode$II {
}
