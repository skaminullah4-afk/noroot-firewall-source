package com.google.gson;

/* JADX INFO: loaded from: classes.dex */
public class JsonParseException extends RuntimeException {
    public JsonParseException(String str) {
        super(str);
    }

    public JsonParseException(String str, Throwable th) {
        super(str, th);
    }

    public JsonParseException(Throwable th) {
        super(th);
    }
}
