package com.google.android.material.animation;

/* JADX INFO: loaded from: classes.dex */
public class Positioning {
    public final int gravity;
    public final float xAdjustment;
    public final float yAdjustment;

    public Positioning(int i, float f, float f2) {
        this.gravity = i;
        this.xAdjustment = f;
        this.yAdjustment = f2;
    }
}
