package com.google.android.material.expandable;

/* JADX INFO: loaded from: classes.dex */
public interface ExpandableTransformationWidget extends ExpandableWidget {
}
