package com.google.android.material.shape;

/* JADX INFO: loaded from: classes.dex */
public class EdgeTreatment {
}
