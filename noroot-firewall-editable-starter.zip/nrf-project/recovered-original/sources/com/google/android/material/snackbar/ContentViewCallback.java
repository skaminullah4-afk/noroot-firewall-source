package com.google.android.material.snackbar;

/* JADX INFO: loaded from: classes.dex */
public interface ContentViewCallback {
}
