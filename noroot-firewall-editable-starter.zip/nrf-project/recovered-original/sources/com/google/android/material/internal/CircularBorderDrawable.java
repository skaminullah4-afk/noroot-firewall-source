package com.google.android.material.internal;

import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;

/* JADX INFO: loaded from: classes.dex */
public class CircularBorderDrawable extends Drawable {
    public void setBorderTint(ColorStateList colorStateList) {
        throw null;
    }

    public final void setRotation(float f) {
        throw null;
    }
}
