package com.google.android.material.shadow;

import android.graphics.Rect;
import androidx.appcompat.graphics.drawable.DrawableWrapper;

/* JADX INFO: loaded from: classes.dex */
public class ShadowDrawableWrapper extends DrawableWrapper {
    static final double COS_45 = Math.cos(Math.toRadians(45.0d));

    @Override // androidx.appcompat.graphics.drawable.DrawableWrapper, android.graphics.drawable.Drawable
    public boolean getPadding(Rect rect) {
        throw null;
    }

    public float getShadowSize() {
        throw null;
    }

    public final void setRotation(float f) {
        throw null;
    }

    public void setShadowSize(float f) {
        throw null;
    }

    public void setShadowSize(float f, float f2) {
        throw null;
    }

    public static float calculateVerticalPadding(float f, float f2, boolean z) {
        return z ? (float) (((double) (f * 1.5f)) + ((1.0d - COS_45) * ((double) f2))) : f * 1.5f;
    }

    public static float calculateHorizontalPadding(float f, float f2, boolean z) {
        return z ? (float) (((double) f) + ((1.0d - COS_45) * ((double) f2))) : f;
    }
}
