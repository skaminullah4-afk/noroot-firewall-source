package com.google.android.material.bottomappbar;

import com.google.android.material.shape.EdgeTreatment;

/* JADX INFO: loaded from: classes.dex */
public class BottomAppBarTopEdgeTreatment extends EdgeTreatment {
    float getCradleVerticalOffset() {
        throw null;
    }

    float getFabCradleMargin() {
        throw null;
    }

    float getFabCradleRoundedCornerRadius() {
        throw null;
    }

    float getFabDiameter() {
        throw null;
    }

    float getHorizontalOffset() {
        throw null;
    }

    void setCradleVerticalOffset(float f) {
        throw null;
    }

    void setFabCradleMargin(float f) {
        throw null;
    }

    void setFabCradleRoundedCornerRadius(float f) {
        throw null;
    }

    void setHorizontalOffset(float f) {
        throw null;
    }
}
