package com.google.android.material.circularreveal;

import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Build;

/* JADX INFO: loaded from: classes.dex */
public class CircularRevealHelper {
    public static final int STRATEGY;

    interface Delegate {
    }

    public void buildCircularRevealCache() {
        throw null;
    }

    public void destroyCircularRevealCache() {
        throw null;
    }

    public void draw(Canvas canvas) {
        throw null;
    }

    public Drawable getCircularRevealOverlayDrawable() {
        throw null;
    }

    public int getCircularRevealScrimColor() {
        throw null;
    }

    public CircularRevealWidget.RevealInfo getRevealInfo() {
        throw null;
    }

    public boolean isOpaque() {
        throw null;
    }

    public void setCircularRevealOverlayDrawable(Drawable drawable) {
        throw null;
    }

    public void setCircularRevealScrimColor(int i) {
        throw null;
    }

    public void setRevealInfo(CircularRevealWidget.RevealInfo revealInfo) {
        throw null;
    }

    static {
        int i = Build.VERSION.SDK_INT;
        if (i >= 21) {
            STRATEGY = 2;
        } else if (i >= 18) {
            STRATEGY = 1;
        } else {
            STRATEGY = 0;
        }
    }
}
