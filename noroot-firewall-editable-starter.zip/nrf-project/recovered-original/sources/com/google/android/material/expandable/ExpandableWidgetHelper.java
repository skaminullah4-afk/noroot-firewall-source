package com.google.android.material.expandable;

import android.os.Bundle;

/* JADX INFO: loaded from: classes.dex */
public final class ExpandableWidgetHelper {
    public int getExpandedComponentIdHint() {
        throw null;
    }

    public boolean isExpanded() {
        throw null;
    }

    public void onRestoreInstanceState(Bundle bundle) {
        throw null;
    }

    public Bundle onSaveInstanceState() {
        throw null;
    }

    public void setExpandedComponentIdHint(int i) {
        throw null;
    }
}
