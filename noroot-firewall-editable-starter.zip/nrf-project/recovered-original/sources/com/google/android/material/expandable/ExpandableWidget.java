package com.google.android.material.expandable;

/* JADX INFO: loaded from: classes.dex */
public interface ExpandableWidget {
    boolean isExpanded();
}
