package com.google.android.material.snackbar;

import android.view.View;

/* JADX INFO: loaded from: classes.dex */
public interface BaseTransientBottomBar$OnLayoutChangeListener {
    void onLayoutChange(View view, int i, int i2, int i3, int i4);
}
