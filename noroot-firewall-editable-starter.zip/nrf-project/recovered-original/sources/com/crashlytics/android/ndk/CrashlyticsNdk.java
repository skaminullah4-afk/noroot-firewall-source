package com.crashlytics.android.ndk;

/* JADX INFO: loaded from: classes.dex */
public class CrashlyticsNdk {
}
