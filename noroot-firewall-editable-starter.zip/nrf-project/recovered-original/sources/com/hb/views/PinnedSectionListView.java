package com.hb.views;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SectionIndexer;

/* JADX INFO: loaded from: classes.dex */
public class PinnedSectionListView extends ListView {
    private final DataSetObserver mDataSetObserver;
    AbsListView.OnScrollListener mDelegateOnScrollListener;
    private final AbsListView.OnScrollListener mOnScrollListener;
    PinnedViewShadow mPinnedShadow;
    PinnedViewShadow mRecycleShadow;
    int mTranslateY;

    public interface PinnedSectionListAdapter extends ListAdapter {
        boolean isItemViewTypePinned(int i);
    }

    static class PinnedViewShadow {
        public int position;
        public View view;

        PinnedViewShadow() {
        }
    }

    public PinnedSectionListView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mDataSetObserver = new DataSetObserver() { // from class: com.hb.views.PinnedSectionListView.1
            @Override // android.database.DataSetObserver
            public void onChanged() {
                PinnedSectionListView.this.destroyPinnedShadow();
            }

            @Override // android.database.DataSetObserver
            public void onInvalidated() {
                PinnedSectionListView.this.destroyPinnedShadow();
            }
        };
        this.mOnScrollListener = new AbsListView.OnScrollListener() { // from class: com.hb.views.PinnedSectionListView.2
            @Override // android.widget.AbsListView.OnScrollListener
            public void onScrollStateChanged(AbsListView absListView, int i) {
                AbsListView.OnScrollListener onScrollListener = PinnedSectionListView.this.mDelegateOnScrollListener;
                if (onScrollListener != null) {
                    onScrollListener.onScrollStateChanged(absListView, i);
                }
            }

            @Override // android.widget.AbsListView.OnScrollListener
            public void onScroll(AbsListView absListView, int i, int i2, int i3) {
                AbsListView.OnScrollListener onScrollListener = PinnedSectionListView.this.mDelegateOnScrollListener;
                if (onScrollListener != null) {
                    onScrollListener.onScroll(absListView, i, i2, i3);
                }
                if (((PinnedSectionListAdapter) absListView.getAdapter()) == null || i2 == 0) {
                    return;
                }
                int iFindFirstVisibleSectionPosition = PinnedSectionListView.this.findFirstVisibleSectionPosition(i, i2);
                if (iFindFirstVisibleSectionPosition == -1) {
                    int iFindCurrentSectionPosition = PinnedSectionListView.this.findCurrentSectionPosition(i);
                    if (iFindCurrentSectionPosition == -1) {
                        return;
                    }
                    PinnedSectionListView pinnedSectionListView = PinnedSectionListView.this;
                    PinnedViewShadow pinnedViewShadow = pinnedSectionListView.mPinnedShadow;
                    if (pinnedViewShadow != null) {
                        if (pinnedViewShadow.position != iFindCurrentSectionPosition) {
                            pinnedSectionListView.destroyPinnedShadow();
                        } else {
                            pinnedSectionListView.mTranslateY = 0;
                            return;
                        }
                    }
                    PinnedSectionListView.this.createPinnedShadow(iFindCurrentSectionPosition);
                    return;
                }
                int top = absListView.getChildAt(iFindFirstVisibleSectionPosition - i).getTop();
                int listPaddingTop = PinnedSectionListView.this.getListPaddingTop();
                PinnedSectionListView pinnedSectionListView2 = PinnedSectionListView.this;
                PinnedViewShadow pinnedViewShadow2 = pinnedSectionListView2.mPinnedShadow;
                if (pinnedViewShadow2 == null) {
                    if (top < listPaddingTop) {
                        pinnedSectionListView2.createPinnedShadow(iFindFirstVisibleSectionPosition);
                        return;
                    }
                    return;
                }
                if (iFindFirstVisibleSectionPosition != pinnedViewShadow2.position) {
                    int height = pinnedViewShadow2.view.getHeight() + listPaddingTop;
                    if (top >= height) {
                        PinnedSectionListView.this.mTranslateY = 0;
                        return;
                    } else if (top < listPaddingTop) {
                        PinnedSectionListView.this.destroyPinnedShadow();
                        PinnedSectionListView.this.createPinnedShadow(iFindFirstVisibleSectionPosition);
                        return;
                    } else {
                        PinnedSectionListView.this.mTranslateY = top - height;
                        return;
                    }
                }
                if (top > listPaddingTop) {
                    pinnedSectionListView2.destroyPinnedShadow();
                    int iFindCurrentSectionPosition2 = PinnedSectionListView.this.findCurrentSectionPosition(iFindFirstVisibleSectionPosition - 1);
                    if (iFindCurrentSectionPosition2 > -1) {
                        PinnedSectionListView.this.createPinnedShadow(iFindCurrentSectionPosition2);
                        int height2 = (top - listPaddingTop) - PinnedSectionListView.this.mPinnedShadow.view.getHeight();
                        if (height2 > 0) {
                            height2 = 0;
                        }
                        PinnedSectionListView.this.mTranslateY = height2;
                    }
                }
            }
        };
        initView();
    }

    public PinnedSectionListView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mDataSetObserver = new DataSetObserver() { // from class: com.hb.views.PinnedSectionListView.1
            @Override // android.database.DataSetObserver
            public void onChanged() {
                PinnedSectionListView.this.destroyPinnedShadow();
            }

            @Override // android.database.DataSetObserver
            public void onInvalidated() {
                PinnedSectionListView.this.destroyPinnedShadow();
            }
        };
        this.mOnScrollListener = new AbsListView.OnScrollListener() { // from class: com.hb.views.PinnedSectionListView.2
            @Override // android.widget.AbsListView.OnScrollListener
            public void onScrollStateChanged(AbsListView absListView, int i2) {
                AbsListView.OnScrollListener onScrollListener = PinnedSectionListView.this.mDelegateOnScrollListener;
                if (onScrollListener != null) {
                    onScrollListener.onScrollStateChanged(absListView, i2);
                }
            }

            @Override // android.widget.AbsListView.OnScrollListener
            public void onScroll(AbsListView absListView, int i2, int i3, int i4) {
                AbsListView.OnScrollListener onScrollListener = PinnedSectionListView.this.mDelegateOnScrollListener;
                if (onScrollListener != null) {
                    onScrollListener.onScroll(absListView, i2, i3, i4);
                }
                if (((PinnedSectionListAdapter) absListView.getAdapter()) == null || i3 == 0) {
                    return;
                }
                int iFindFirstVisibleSectionPosition = PinnedSectionListView.this.findFirstVisibleSectionPosition(i2, i3);
                if (iFindFirstVisibleSectionPosition == -1) {
                    int iFindCurrentSectionPosition = PinnedSectionListView.this.findCurrentSectionPosition(i2);
                    if (iFindCurrentSectionPosition == -1) {
                        return;
                    }
                    PinnedSectionListView pinnedSectionListView = PinnedSectionListView.this;
                    PinnedViewShadow pinnedViewShadow = pinnedSectionListView.mPinnedShadow;
                    if (pinnedViewShadow != null) {
                        if (pinnedViewShadow.position != iFindCurrentSectionPosition) {
                            pinnedSectionListView.destroyPinnedShadow();
                        } else {
                            pinnedSectionListView.mTranslateY = 0;
                            return;
                        }
                    }
                    PinnedSectionListView.this.createPinnedShadow(iFindCurrentSectionPosition);
                    return;
                }
                int top = absListView.getChildAt(iFindFirstVisibleSectionPosition - i2).getTop();
                int listPaddingTop = PinnedSectionListView.this.getListPaddingTop();
                PinnedSectionListView pinnedSectionListView2 = PinnedSectionListView.this;
                PinnedViewShadow pinnedViewShadow2 = pinnedSectionListView2.mPinnedShadow;
                if (pinnedViewShadow2 == null) {
                    if (top < listPaddingTop) {
                        pinnedSectionListView2.createPinnedShadow(iFindFirstVisibleSectionPosition);
                        return;
                    }
                    return;
                }
                if (iFindFirstVisibleSectionPosition != pinnedViewShadow2.position) {
                    int height = pinnedViewShadow2.view.getHeight() + listPaddingTop;
                    if (top >= height) {
                        PinnedSectionListView.this.mTranslateY = 0;
                        return;
                    } else if (top < listPaddingTop) {
                        PinnedSectionListView.this.destroyPinnedShadow();
                        PinnedSectionListView.this.createPinnedShadow(iFindFirstVisibleSectionPosition);
                        return;
                    } else {
                        PinnedSectionListView.this.mTranslateY = top - height;
                        return;
                    }
                }
                if (top > listPaddingTop) {
                    pinnedSectionListView2.destroyPinnedShadow();
                    int iFindCurrentSectionPosition2 = PinnedSectionListView.this.findCurrentSectionPosition(iFindFirstVisibleSectionPosition - 1);
                    if (iFindCurrentSectionPosition2 > -1) {
                        PinnedSectionListView.this.createPinnedShadow(iFindCurrentSectionPosition2);
                        int height2 = (top - listPaddingTop) - PinnedSectionListView.this.mPinnedShadow.view.getHeight();
                        if (height2 > 0) {
                            height2 = 0;
                        }
                        PinnedSectionListView.this.mTranslateY = height2;
                    }
                }
            }
        };
        initView();
    }

    private void initView() {
        setOnScrollListener(this.mOnScrollListener);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void createPinnedShadow(int i) {
        int size;
        int i2;
        PinnedViewShadow pinnedViewShadow = this.mRecycleShadow;
        this.mRecycleShadow = null;
        if (pinnedViewShadow == null) {
            pinnedViewShadow = new PinnedViewShadow();
        }
        View view = getAdapter().getView(i, pinnedViewShadow.view, this);
        AbsListView.LayoutParams layoutParams = (AbsListView.LayoutParams) view.getLayoutParams();
        if (layoutParams == null) {
            i2 = Integer.MIN_VALUE;
            size = getHeight();
        } else {
            int mode = View.MeasureSpec.getMode(layoutParams.height);
            size = View.MeasureSpec.getSize(layoutParams.height);
            i2 = mode;
        }
        if (i2 == 0) {
            i2 = 1073741824;
        }
        int height = (getHeight() - getListPaddingTop()) - getListPaddingBottom();
        if (size > height) {
            size = height;
        }
        view.measure(View.MeasureSpec.makeMeasureSpec((getWidth() - getListPaddingLeft()) - getListPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec(size, i2));
        view.layout(0, 0, view.getMeasuredWidth(), view.getMeasuredHeight());
        this.mTranslateY = 0;
        pinnedViewShadow.position = i;
        pinnedViewShadow.view = view;
        this.mPinnedShadow = pinnedViewShadow;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void destroyPinnedShadow() {
        this.mRecycleShadow = this.mPinnedShadow;
        this.mPinnedShadow = null;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int findFirstVisibleSectionPosition(int i, int i2) {
        PinnedSectionListAdapter pinnedSectionListAdapter = (PinnedSectionListAdapter) getAdapter();
        for (int i3 = 0; i3 < i2; i3++) {
            int i4 = i + i3;
            if (pinnedSectionListAdapter.isItemViewTypePinned(pinnedSectionListAdapter.getItemViewType(i4))) {
                return i4;
            }
        }
        return -1;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public int findCurrentSectionPosition(int i) {
        PinnedSectionListAdapter pinnedSectionListAdapter = (PinnedSectionListAdapter) getAdapter();
        if (pinnedSectionListAdapter instanceof SectionIndexer) {
            SectionIndexer sectionIndexer = (SectionIndexer) pinnedSectionListAdapter;
            int positionForSection = sectionIndexer.getPositionForSection(sectionIndexer.getSectionForPosition(i));
            if (pinnedSectionListAdapter.isItemViewTypePinned(pinnedSectionListAdapter.getItemViewType(positionForSection))) {
                return positionForSection;
            }
        }
        while (i >= 0) {
            if (pinnedSectionListAdapter.isItemViewTypePinned(pinnedSectionListAdapter.getItemViewType(i))) {
                return i;
            }
            i--;
        }
        return -1;
    }

    @Override // android.widget.AbsListView
    public void setOnScrollListener(AbsListView.OnScrollListener onScrollListener) {
        if (onScrollListener == this.mOnScrollListener) {
            super.setOnScrollListener(onScrollListener);
        } else {
            this.mDelegateOnScrollListener = onScrollListener;
        }
    }

    @Override // android.widget.AbsListView, android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState(parcelable);
        post(new Runnable() { // from class: com.hb.views.PinnedSectionListView.3
            @Override // java.lang.Runnable
            public void run() {
                if (PinnedSectionListView.this.getAdapter() == null) {
                    return;
                }
                int firstVisiblePosition = PinnedSectionListView.this.getFirstVisiblePosition();
                int iFindCurrentSectionPosition = PinnedSectionListView.this.findCurrentSectionPosition(firstVisiblePosition);
                if (iFindCurrentSectionPosition == -1) {
                    return;
                }
                if (firstVisiblePosition == iFindCurrentSectionPosition) {
                    PinnedSectionListView.this.createPinnedShadow(firstVisiblePosition);
                    View childAt = PinnedSectionListView.this.getChildAt(firstVisiblePosition);
                    PinnedSectionListView.this.mTranslateY = childAt == null ? 0 : -childAt.getTop();
                    return;
                }
                PinnedSectionListView.this.createPinnedShadow(iFindCurrentSectionPosition);
            }
        });
    }

    @Override // android.widget.AdapterView
    public void setAdapter(ListAdapter listAdapter) {
        if (listAdapter != null) {
            if (!(listAdapter instanceof PinnedSectionListAdapter)) {
                throw new IllegalArgumentException("Does your adapter implement PinnedSectionListAdapter?");
            }
            if (listAdapter.getViewTypeCount() < 2) {
                throw new IllegalArgumentException("Does your adapter handle at least two types of views - items and sections?");
            }
        }
        ListAdapter adapter = getAdapter();
        if (adapter != null) {
            adapter.unregisterDataSetObserver(this.mDataSetObserver);
        }
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.mDataSetObserver);
        }
        if (adapter != listAdapter) {
            destroyPinnedShadow();
        }
        super.setAdapter(listAdapter);
    }

    @Override // android.widget.ListView, android.widget.AbsListView, android.view.ViewGroup, android.view.View
    protected void dispatchDraw(Canvas canvas) {
        super.dispatchDraw(canvas);
        if (this.mPinnedShadow != null) {
            int listPaddingLeft = getListPaddingLeft();
            int listPaddingTop = getListPaddingTop();
            View view = this.mPinnedShadow.view;
            canvas.save();
            canvas.clipRect(listPaddingLeft, listPaddingTop, view.getWidth() + listPaddingLeft, view.getHeight() + listPaddingTop);
            canvas.translate(listPaddingLeft, listPaddingTop + this.mTranslateY);
            drawChild(canvas, this.mPinnedShadow.view, getDrawingTime());
            canvas.restore();
        }
    }
}
